/**
 * SHE-SHIELD BOT CLIENT SERVICE
 * 
 * Communicates with the rule-based FAQ system.
 */

export interface ChatMessage {
  role: 'user' | 'model';
  parts: { text: string }[];
}

export async function sendMessageToBot(message: string, history: ChatMessage[], language?: string): Promise<string> {
  const input = message.toLowerCase();

  const faq = [
    { keywords: ['hi', 'hello', 'hey', 'greetings'], response: "👋 Hello! Welcome to SheShield AI. I'm your AI Safety Assistant, here to help you stay informed and protected.\n\nI can assist you with:\n\n- 🛡️ Women's safety guidance\n- 🚨 SOS and emergency support\n- 📍 Location and safety tips\n- 👥 Trusted contacts\n- ❓ Information about SheShield AI features\n\nHow can I help you today? Your safety is my priority." },
    { keywords: ['sos'], response: "Tap the SOS button on the Home screen to instantly notify your emergency contacts with your current location." },
    { keywords: ['live location', 'share'], response: "Open Live Journey Guardian and start sharing your live location with your trusted contacts throughout your journey." },
    { keywords: ['zero fir'], response: "A Zero FIR is a First Information Report that can be filed at any police station, regardless of where the incident occurred." },
    { keywords: ['unsafe'], response: "Stay calm, move to a safe public place, contact a trusted person, and use the SOS feature if immediate assistance is required." },
    { keywords: ['report', 'harassment'], response: "Open the Report section in SheShield, fill in the incident details, and submit your report." },
    { keywords: ['emergency numbers'], response: "Go to the Emergency Contacts section to call emergency services or your saved emergency contacts." },
    { keywords: ['add', 'emergency contact'], response: "Open Profile → Emergency Contacts → Add Contact, then save the people you trust." },
    { keywords: ['self-defense', 'tips'], response: "Open the Safety Tips section to access self-defense techniques, awareness tips, and emergency guidance." },
    
    // New FAQs
    { keywords: ['what is sheshield', 'what is sheshield ai'], response: "SheShield AI is an AI-powered women's safety application that provides emergency assistance, SOS alerts, trusted contacts, live location sharing, and an AI chatbot to improve personal safety." },
    { keywords: ['why develop', 'purpose of project'], response: "We developed this project to enhance women's safety by providing quick emergency support and intelligent assistance using AI and cloud technologies." },
    { keywords: ['purpose of chatbot', 'chatbot purpose'], response: "The AI chatbot guides users, answers safety-related questions, explains app features, and provides emergency guidance." },
    { keywords: ['technologies used'], response: "The application is built using Google AI Studio, Firebase Authentication, Cloud Firestore, and Location Services." },
    { keywords: ['why firebase'], response: "Firebase provides secure authentication, cloud storage, real-time database support, and easy integration for modern applications." },
    { keywords: ['login system', 'how login'], response: "Users register using their email and password. Firebase Authentication verifies their identity before allowing access." },
    { keywords: ['what is cloud firestore', 'what is firestore'], response: "Cloud Firestore is a NoSQL cloud database used to securely store user profiles, emergency contacts, and application data." },
    { keywords: ['sos feature', 'how sos works'], response: "The SOS feature sends emergency alerts and the user's current location to trusted contacts during emergencies." },
    { keywords: ['live location', 'how location obtained'], response: "The application uses the device's GPS with the user's permission to fetch the current location." },
    { keywords: ['is data secure', 'user data secure'], response: "Yes. User authentication is handled by Firebase Authentication, and data is securely stored in Cloud Firestore with security rules." },
    { keywords: ['multiple users'], response: "Yes. Each user has a separate account, and their data is stored independently in Firebase." },
    { keywords: ['how chatbot works', 'ai chatbot'], response: "The chatbot uses Google's AI model to understand the user's question and generate relevant responses." },
    { keywords: ['safety percentage', 'real-time safety'], response: "The current version displays a sample value. In future versions, it can be calculated using live location and nearby safety data." },
    { keywords: ['challenges'], response: "The main challenges were integrating Firebase Authentication, configuring Firestore permissions, and implementing real-time features." },
    { keywords: ['future enhancements', 'future improvements'], response: "Future improvements include real-time crime analysis, voice-activated SOS, offline emergency mode, wearable device integration, and multilingual AI support." },
    { keywords: ['why ai'], response: "AI improves user interaction by providing intelligent assistance, answering safety-related questions, and offering instant guidance." },
    { keywords: ['difference', 'what makes different'], response: "It combines AI assistance, emergency SOS, live location sharing, and secure cloud services into one women's safety platform." },
    { keywords: ['emergency contact feature', 'how contact work'], response: "Users add trusted contacts, and during an emergency the app can notify them along with the user's live location." },
    { keywords: ['internet unavailable', 'offline'], response: "Some cloud-based features may not work, but future versions can include offline SOS using SMS and local emergency services." },
    { keywords: ['why use', 'why should use'], response: "SheShield AI provides quick emergency support, intelligent assistance, and safety tools that help users feel more secure in daily life." },
  ];

  // Simple rule-based matching
  for (const item of faq) {
    if (item.keywords.some(keyword => input.includes(keyword))) {
      return item.response;
    }
  }

  return "I'm sorry, I don't have an answer for that yet. Please try asking about SOS, Live Location, Emergency Contacts, Zero FIR, Harassment Reporting, or Safety Tips.";
}
