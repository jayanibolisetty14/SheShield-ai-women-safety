import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  signInWithPopup,
  updateProfile,
  User as FirebaseUser,
  signInWithPhoneNumber,
  RecaptchaVerifier,
  ConfirmationResult
} from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { auth, db, googleProvider } from './firebase';
import { handleFirestoreError, OperationType } from './firestoreErrorHandler';

export interface UserProfile {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
  createdAt: string;
  safetyStatus: 'safe' | 'danger' | 'tracking' | 'unknown';
  lastLocation: { lat: number; lng: number; timestamp: string } | null;
}

// Helper to create user doc in Firestore during signup
export async function createUserDoc(user: FirebaseUser, name: string): Promise<UserProfile> {
  const userRef = doc(db, 'users', user.uid);
  const profile: UserProfile = {
    uid: user.uid,
    email: user.email,
    displayName: name || user.displayName || user.email?.split('@')[0] || '',
    photoURL: user.photoURL || `https://api.dicebear.com/7.x/adventurer/svg?seed=${user.uid}`,
    createdAt: new Date().toISOString(),
    safetyStatus: 'safe',
    lastLocation: null
  };
  try {
    await setDoc(userRef, profile);
    return profile;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `users/${user.uid}`);
    throw error;
  }
}

// Helper to fetch user doc in Firestore during login
export async function getUserDoc(uid: string): Promise<UserProfile | null> {
  const userRef = doc(db, 'users', uid);
  try {
    const snap = await getDoc(userRef);
    if (snap.exists()) {
      return snap.data() as UserProfile;
    }
    return null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `users/${uid}`);
    return null;
  }
}

// Register
export async function registerWithEmail(email: string, pass: string, name: string): Promise<UserProfile> {
  console.log("Attempting registration for:", email);
  try {
    const credentials = await createUserWithEmailAndPassword(auth, email, pass);
    console.log("Registration successful for:", credentials.user.uid);
    await updateProfile(credentials.user, { displayName: name });
    console.log("Profile updated");
    return await createUserDoc(credentials.user, name);
  } catch (error) {
    console.error("Registration failed:", error);
    throw error;
  }
}

// Login
export async function loginWithEmail(email: string, pass: string): Promise<UserProfile> {
  console.log("Attempting login for:", email);
  try {
    const credentials = await signInWithEmailAndPassword(auth, email, pass);
    console.log("Login successful for:", credentials.user.uid);
    let profile = await getUserDoc(credentials.user.uid);
    
    // If profile doesn't exist, create it
    if (!profile) {
      console.log("Profile not found, creating for:", credentials.user.uid);
      profile = await createUserDoc(credentials.user, credentials.user.displayName || '');
    }
    return profile;
  } catch (error) {
    console.error("Login failed:", error);
    throw error;
  }
}

// Google Sign-In
export async function loginWithGoogle(): Promise<UserProfile> {
  const credentials = await signInWithPopup(auth, googleProvider);
  let profile = await getUserDoc(credentials.user.uid);
  
  // If profile doesn't exist, create it
  if (!profile) {
    profile = await createUserDoc(credentials.user, credentials.user.displayName || '');
  }
  return profile;
}

// Phone Sign-In
export async function setupRecaptcha(containerId: string): Promise<RecaptchaVerifier> {
  return new RecaptchaVerifier(auth, containerId, {
    'size': 'invisible',
  });
}

export async function loginWithPhone(phoneNumber: string, appVerifier: RecaptchaVerifier): Promise<ConfirmationResult> {
  return await signInWithPhoneNumber(auth, phoneNumber, appVerifier);
}

// Logout
export async function logoutUser(): Promise<void> {
  await signOut(auth);
}

// Password Reset
export async function resetPassword(email: string): Promise<void> {
  await sendPasswordResetEmail(auth, email);
}

// Update User Safety Status
export async function updateUserSafetyStatus(uid: string, status: 'safe' | 'danger' | 'tracking'): Promise<void> {
  if (uid === 'demo_user') {
    const mockProfile = JSON.parse(localStorage.getItem('demo_profile') || '{}');
    mockProfile.safetyStatus = status;
    localStorage.setItem('demo_profile', JSON.stringify(mockProfile));
    window.dispatchEvent(new Event('storage'));
    return;
  }

  const userRef = doc(db, 'users', uid);
  try {
    await setDoc(userRef, { safetyStatus: status }, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `users/${uid}`);
  }
}

// Update User Last Location
export async function updateUserLastLocation(uid: string, lat: number, lng: number): Promise<void> {
  if (uid === 'demo_user') {
    const mockProfile = JSON.parse(localStorage.getItem('demo_profile') || '{}');
    mockProfile.lastLocation = {
      lat,
      lng,
      timestamp: new Date().toISOString()
    };
    localStorage.setItem('demo_profile', JSON.stringify(mockProfile));
    window.dispatchEvent(new Event('storage'));
    return;
  }

  const userRef = doc(db, 'users', uid);
  try {
    await setDoc(userRef, {
      lastLocation: {
        lat,
        lng,
        timestamp: new Date().toISOString()
      }
    }, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `users/${uid}`);
  }
}
