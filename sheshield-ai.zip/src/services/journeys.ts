import {
  collection,
  doc,
  setDoc,
  updateDoc,
  getDoc,
  getDocs,
  query,
  where,
  orderBy,
  onSnapshot,
  arrayUnion
} from 'firebase/firestore';
import { db } from './firebase';
import { handleFirestoreError, OperationType } from './firestoreErrorHandler';

export interface RoutePoint {
  lat: number;
  lng: number;
  timestamp: string;
}

export interface RideDetails {
  driverName: string;
  vehicleNumber: string;
  vehicleType: 'Auto' | 'Cab' | 'Bike' | 'Other';
  driverPhone?: string;
  addedAt: string;
}

export interface Journey {
  id: string;
  userId: string;
  startTime: string;
  endTime?: string;
  route: RoutePoint[];
  status: 'active' | 'completed' | 'abandoned';
  destination?: string;
  eta?: string;
  safetyScore: number;
  riskLevel: 'low' | 'medium' | 'high';
  rideDetails?: RideDetails;
}

const JOURNEYS_COL = 'journeys';

// Start Journey
export async function startNewJourney(
  userId: string,
  destination: string,
  initialPoint: RoutePoint,
  initialSafetyScore = 100,
  initialRiskLevel: 'low' | 'medium' | 'high' = 'low',
  rideDetails?: RideDetails
): Promise<string> {
  const journeyId = 'journey_' + Math.random().toString(36).substr(2, 9);
  const newJourney: Journey = {
    id: journeyId,
    userId,
    startTime: new Date().toISOString(),
    route: [initialPoint],
    status: 'active',
    destination: destination || 'Unnamed Destination',
    safetyScore: initialSafetyScore,
    riskLevel: initialRiskLevel,
  };

  if (rideDetails) {
    newJourney.rideDetails = rideDetails;
  }

  if (userId === 'demo_user') {
    const mockJourneys = JSON.parse(localStorage.getItem('demo_journeys') || '[]');
    mockJourneys.push(newJourney);
    localStorage.setItem('demo_journeys', JSON.stringify(mockJourneys));
    window.dispatchEvent(new Event('storage'));
    return journeyId;
  }

  try {
    await setDoc(doc(db, JOURNEYS_COL, journeyId), newJourney);
    return journeyId;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `${JOURNEYS_COL}/${journeyId}`);
  }
}

// Add Point & Update Safety details
export async function updateJourneyRoute(
  journeyId: string,
  point: RoutePoint,
  safetyScore: number,
  riskLevel: 'low' | 'medium' | 'high',
  etaEstimate?: string
): Promise<void> {
  if (journeyId.startsWith('journey_')) {
    const mockJourneys = JSON.parse(localStorage.getItem('demo_journeys') || '[]');
    const index = mockJourneys.findIndex((j: any) => j.id === journeyId);
    if (index !== -1) {
      mockJourneys[index].route.push(point);
      mockJourneys[index].safetyScore = safetyScore;
      mockJourneys[index].riskLevel = riskLevel;
      if (etaEstimate !== undefined) {
        mockJourneys[index].eta = etaEstimate;
      }
      localStorage.setItem('demo_journeys', JSON.stringify(mockJourneys));
      window.dispatchEvent(new Event('storage'));
    }
    return;
  }

  const docRef = doc(db, JOURNEYS_COL, journeyId);
  const updates: any = {
    route: arrayUnion(point),
    safetyScore,
    riskLevel
  };
  if (etaEstimate !== undefined) {
    updates.eta = etaEstimate;
  }
  try {
    await updateDoc(docRef, updates);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `${JOURNEYS_COL}/${journeyId}`);
  }
}

// Complete Journey
export async function stopJourney(journeyId: string, finalStatus: 'completed' | 'abandoned' = 'completed'): Promise<void> {
  if (journeyId.startsWith('journey_')) {
    const mockJourneys = JSON.parse(localStorage.getItem('demo_journeys') || '[]');
    const index = mockJourneys.findIndex((j: any) => j.id === journeyId);
    if (index !== -1) {
      mockJourneys[index].status = finalStatus;
      mockJourneys[index].endTime = new Date().toISOString();
      localStorage.setItem('demo_journeys', JSON.stringify(mockJourneys));
      window.dispatchEvent(new Event('storage'));
    }
    return;
  }

  const docRef = doc(db, JOURNEYS_COL, journeyId);
  try {
    await updateDoc(docRef, {
      status: finalStatus,
      endTime: new Date().toISOString()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `${JOURNEYS_COL}/${journeyId}`);
  }
}

// Update Ride Details mid-journey
export async function updateRideDetails(journeyId: string, rideDetails: RideDetails): Promise<void> {
  if (journeyId.startsWith('journey_')) {
    const mockJourneys = JSON.parse(localStorage.getItem('demo_journeys') || '[]');
    const index = mockJourneys.findIndex((j: any) => j.id === journeyId);
    if (index !== -1) {
      mockJourneys[index].rideDetails = rideDetails;
      localStorage.setItem('demo_journeys', JSON.stringify(mockJourneys));
      window.dispatchEvent(new Event('storage'));
    }
    return;
  }

  const docRef = doc(db, JOURNEYS_COL, journeyId);
  try {
    await updateDoc(docRef, { rideDetails });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `${JOURNEYS_COL}/${journeyId}`);
  }
}

// Get Journey Details
export async function getJourney(journeyId: string): Promise<Journey | null> {
  if (journeyId.startsWith('journey_')) {
    const mockJourneys = JSON.parse(localStorage.getItem('demo_journeys') || '[]');
    return mockJourneys.find((j: any) => j.id === journeyId) || null;
  }

  const docRef = doc(db, JOURNEYS_COL, journeyId);
  try {
    const snap = await getDoc(docRef);
    return snap.exists() ? (snap.data() as Journey) : null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `${JOURNEYS_COL}/${journeyId}`);
  }
}

// Subscribe to Journey in Real-time (for sharing link)
export function subscribeJourney(journeyId: string, callback: (journey: Journey | null) => void) {
  if (journeyId.startsWith('journey_')) {
    const updateDemoJourney = () => {
      const mockJourneys = JSON.parse(localStorage.getItem('demo_journeys') || '[]');
      const found = mockJourneys.find((j: any) => j.id === journeyId) || null;
      callback(found);
    };
    updateDemoJourney();
    window.addEventListener('storage', updateDemoJourney);
    return () => {
      window.removeEventListener('storage', updateDemoJourney);
    };
  }

  const docRef = doc(db, JOURNEYS_COL, journeyId);
  return onSnapshot(docRef, (snap) => {
    if (snap.exists()) {
      callback(snap.data() as Journey);
    } else {
      callback(null);
    }
  }, (err) => {
    handleFirestoreError(err, OperationType.GET, `${JOURNEYS_COL}/${journeyId}`);
  });
}

// Get Past Journeys for a User
export async function getUserJourneys(userId: string): Promise<Journey[]> {
  if (userId === 'demo_user') {
    return JSON.parse(localStorage.getItem('demo_journeys') || '[]');
  }

  const colRef = collection(db, JOURNEYS_COL);
  const q = query(colRef, where('userId', '==', userId), orderBy('startTime', 'desc'));
  try {
    const snap = await getDocs(q);
    return snap.docs.map(d => d.data() as Journey);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, JOURNEYS_COL);
  }
}
