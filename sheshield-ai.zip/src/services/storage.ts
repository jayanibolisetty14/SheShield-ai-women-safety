import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { storage } from './firebase';

/**
 * Uploads an evidence blob (e.g. audio/mp4, video/webm) to Firebase Storage
 * and returns the public download URL.
 */
export async function uploadEvidence(
  userId: string,
  blob: Blob,
  fileExtension: string
): Promise<string> {
  const timestamp = Date.now();
  const filePath = `evidence/${userId}/${timestamp}.${fileExtension}`;
  const fileRef = ref(storage, filePath);

  // Upload the blob
  const snapshot = await uploadBytes(fileRef, blob, {
    contentType: blob.type
  });

  // Get and return the download URL
  const downloadUrl = await getDownloadURL(snapshot.ref);
  return downloadUrl;
}
