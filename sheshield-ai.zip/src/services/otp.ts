import { db } from './firebase';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { handleFirestoreError, OperationType } from './firestoreErrorHandler';

export interface OtpDoc {
  code: string;
  createdAt: string;
  verified: boolean;
  email: string;
}

/**
 * Generates a 6-digit random verification code and stores it in Firestore under the user's ID.
 */
export async function generateOtp(userId: string, email: string): Promise<string> {
  const code = String(Math.floor(100000 + Math.random() * 900000));
  
  if (userId === 'demo_user') {
    const mockOtp: OtpDoc = {
      code,
      createdAt: new Date().toISOString(),
      verified: false,
      email,
    };
    localStorage.setItem(`demo_otp_${userId}`, JSON.stringify(mockOtp));
    return code;
  }

  try {
    const docRef = doc(db, 'otpVerifications', userId);
    await setDoc(docRef, {
      code,
      createdAt: new Date().toISOString(),
      verified: false,
      email,
    });
    return code;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `otpVerifications/${userId}`);
  }
}

/**
 * Verifies the entered OTP code against the stored value in Firestore.
 */
export async function verifyOtp(userId: string, enteredCode: string): Promise<boolean> {
  if (userId === 'demo_user') {
    const mockOtpStr = localStorage.getItem(`demo_otp_${userId}`);
    if (!mockOtpStr) return false;
    const mockOtp: OtpDoc = JSON.parse(mockOtpStr);
    if (mockOtp.code === enteredCode) {
      mockOtp.verified = true;
      localStorage.setItem(`demo_otp_${userId}`, JSON.stringify(mockOtp));
      return true;
    }
    return false;
  }

  try {
    const docRef = doc(db, 'otpVerifications', userId);
    const snap = await getDoc(docRef);
    if (!snap.exists()) {
      return false;
    }
    const data = snap.data() as OtpDoc;
    if (data.code === enteredCode) {
      await setDoc(docRef, { verified: true }, { merge: true });
      return true;
    }
    return false;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `otpVerifications/${userId}`);
  }
}

/**
 * Resends the OTP by generating a new one.
 */
export async function resendOtp(userId: string, email: string): Promise<string> {
  return generateOtp(userId, email);
}
