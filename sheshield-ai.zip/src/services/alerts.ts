import {
  collection,
  doc,
  setDoc,
  updateDoc,
  getDocs,
  query,
  where,
  orderBy,
  onSnapshot
} from 'firebase/firestore';
import { db } from './firebase';
import { handleFirestoreError, OperationType } from './firestoreErrorHandler';

export interface Alert {
  id: string;
  userId: string;
  type: 'sos' | 'silent';
  location: { lat: number; lng: number; address?: string };
  timestamp: string;
  status: 'active' | 'resolved';
  evidenceUrl?: string;
  userDisplayName?: string;
  contacts?: any[];
}

const ALERTS_COL = 'alerts';

// Create Emergency Alert
export async function createAlert(
  userId: string,
  type: 'sos' | 'silent',
  lat: number,
  lng: number,
  userDisplayName?: string,
  evidenceUrl?: string,
  contacts?: any[]
): Promise<string> {
  const alertId = 'alert_' + Math.random().toString(36).substr(2, 9);
  const newAlert: Alert = {
    id: alertId,
    userId,
    type,
    location: { lat, lng },
    timestamp: new Date().toISOString(),
    status: 'active',
    userDisplayName: userDisplayName || '',
    evidenceUrl: evidenceUrl || '',
    contacts: contacts || []
  };

  try {
    await setDoc(doc(db, ALERTS_COL, alertId), newAlert);
    return alertId;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `${ALERTS_COL}/${alertId}`);
  }
}

// Update Alert Status
export async function resolveAlert(alertId: string): Promise<void> {
  if (alertId.startsWith('alert_')) {
    const mockAlerts = JSON.parse(localStorage.getItem('demo_alerts') || '[]');
    const index = mockAlerts.findIndex((a: any) => a.id === alertId);
    if (index !== -1) {
      mockAlerts[index].status = 'resolved';
      localStorage.setItem('demo_alerts', JSON.stringify(mockAlerts));
      window.dispatchEvent(new Event('storage'));
    }
    return;
  }

  const docRef = doc(db, ALERTS_COL, alertId);
  try {
    await updateDoc(docRef, {
      status: 'resolved'
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `${ALERTS_COL}/${alertId}`);
  }
}

// Attach Evidence URL to Alert
export async function attachEvidenceToAlert(alertId: string, evidenceUrl: string): Promise<void> {
  if (alertId.startsWith('alert_')) {
    const mockAlerts = JSON.parse(localStorage.getItem('demo_alerts') || '[]');
    const index = mockAlerts.findIndex((a: any) => a.id === alertId);
    if (index !== -1) {
      mockAlerts[index].evidenceUrl = evidenceUrl;
      localStorage.setItem('demo_alerts', JSON.stringify(mockAlerts));
      window.dispatchEvent(new Event('storage'));
    }
    return;
  }

  const docRef = doc(db, ALERTS_COL, alertId);
  try {
    await updateDoc(docRef, {
      evidenceUrl
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `${ALERTS_COL}/${alertId}`);
  }
}

// Get User's Past Alerts
export async function getUserAlerts(userId: string): Promise<Alert[]> {
  if (userId === 'demo_user') {
    return JSON.parse(localStorage.getItem('demo_alerts') || '[]');
  }

  const colRef = collection(db, ALERTS_COL);
  const q = query(colRef, where('userId', '==', userId), orderBy('timestamp', 'desc'));
  try {
    const snap = await getDocs(q);
    return snap.docs.map(d => d.data() as Alert);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, ALERTS_COL);
  }
}

// Subscribe to Active Alerts (to show safety status notifications)
export function subscribeActiveAlerts(userId: string, callback: (alerts: Alert[]) => void) {
  if (userId === 'demo_user') {
    const updateDemoAlerts = () => {
      const mockAlerts = JSON.parse(localStorage.getItem('demo_alerts') || '[]');
      callback(mockAlerts);
    };
    updateDemoAlerts();
    window.addEventListener('storage', updateDemoAlerts);
    return () => {
      window.removeEventListener('storage', updateDemoAlerts);
    };
  }

  const colRef = collection(db, ALERTS_COL);
  const q = query(colRef, where('userId', '==', userId), orderBy('timestamp', 'desc'));
  return onSnapshot(q, (snap) => {
    const list = snap.docs.map(d => d.data() as Alert);
    callback(list);
  }, (err) => {
    handleFirestoreError(err, OperationType.LIST, ALERTS_COL);
  });
}
