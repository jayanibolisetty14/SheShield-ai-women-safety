import {
  collection,
  doc,
  addDoc,
  updateDoc,
  deleteDoc,
  getDocs,
  query,
  orderBy,
  onSnapshot
} from 'firebase/firestore';
import { db } from './firebase';
import { handleFirestoreError, OperationType } from './firestoreErrorHandler';

export interface EmergencyContact {
  id: string;
  name: string;
  phone: string;
  email: string;
  relation: string;
  createdAt: string;
  isPrimary?: boolean;
}

// Get subcollection ref
function getContactsColRef(userId: string) {
  return collection(db, 'users', userId, 'emergencyContacts');
}

// Add Contact
export async function addContact(userId: string, name: string, phone: string, email: string, relation: string): Promise<string> {
  if (userId === 'demo_user') {
    const mockContacts = JSON.parse(localStorage.getItem('demo_contacts') || '[]');
    const id = 'mock_' + Math.random().toString(36).substr(2, 9);
    const newContact: EmergencyContact = {
      id,
      name,
      phone,
      email,
      relation,
      createdAt: new Date().toISOString()
    };
    mockContacts.push(newContact);
    localStorage.setItem('demo_contacts', JSON.stringify(mockContacts));
    window.dispatchEvent(new Event('storage'));
    return id;
  }
  try {
    const colRef = getContactsColRef(userId);
    const docRef = await addDoc(colRef, {
      name,
      phone,
      email,
      relation,
      createdAt: new Date().toISOString()
    });
    return docRef.id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `users/${userId}/emergencyContacts`);
  }
}

// Update Contact
export async function updateContact(userId: string, contactId: string, updates: Partial<Omit<EmergencyContact, 'id' | 'createdAt'>>): Promise<void> {
  if (userId === 'demo_user') {
    const mockContacts = JSON.parse(localStorage.getItem('demo_contacts') || '[]');
    const index = mockContacts.findIndex((c: any) => c.id === contactId);
    if (index !== -1) {
      mockContacts[index] = { ...mockContacts[index], ...updates };
      localStorage.setItem('demo_contacts', JSON.stringify(mockContacts));
      window.dispatchEvent(new Event('storage'));
    }
    return;
  }
  try {
    const docRef = doc(db, 'users', userId, 'emergencyContacts', contactId);
    await updateDoc(docRef, updates);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `users/${userId}/emergencyContacts/${contactId}`);
  }
}

// Delete Contact
export async function removeContact(userId: string, contactId: string): Promise<void> {
  if (userId === 'demo_user') {
    let mockContacts = JSON.parse(localStorage.getItem('demo_contacts') || '[]');
    mockContacts = mockContacts.filter((c: any) => c.id !== contactId);
    localStorage.setItem('demo_contacts', JSON.stringify(mockContacts));
    window.dispatchEvent(new Event('storage'));
    return;
  }
  try {
    console.log(`Deleting contact: users/${userId}/emergencyContacts/${contactId}`);
    const docRef = doc(db, 'users', userId, 'emergencyContacts', contactId);
    await deleteDoc(docRef);
    console.log("Delete successful");
  } catch (error) {
    console.error("Delete failed:", error);
    handleFirestoreError(error, OperationType.DELETE, `users/${userId}/emergencyContacts/${contactId}`);
  }
}

// Get Contacts (static promise)
export async function getContacts(userId: string): Promise<EmergencyContact[]> {
  if (userId === 'demo_user') {
    return JSON.parse(localStorage.getItem('demo_contacts') || '[]');
  }
  try {
    const colRef = getContactsColRef(userId);
    const q = query(colRef, orderBy('createdAt', 'desc'));
    const snap = await getDocs(q);
    return snap.docs.map(d => ({ id: d.id, ...d.data() }) as EmergencyContact);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, `users/${userId}/emergencyContacts`);
  }
}

// Subscribe to Contacts (real-time listener)
export function subscribeContacts(userId: string, callback: (contacts: EmergencyContact[]) => void) {
  if (userId === 'demo_user') {
    const updateDemoContacts = () => {
      const mockContacts = JSON.parse(localStorage.getItem('demo_contacts') || '[]');
      callback(mockContacts);
    };
    updateDemoContacts();
    window.addEventListener('storage', updateDemoContacts);
    return () => {
      window.removeEventListener('storage', updateDemoContacts);
    };
  }
  const colRef = getContactsColRef(userId);
  const q = query(colRef, orderBy('createdAt', 'desc'));
  return onSnapshot(q, (snap) => {
    const list = snap.docs.map(d => ({ id: d.id, ...d.data() }) as EmergencyContact);
    callback(list);
  }, (err) => {
    handleFirestoreError(err, OperationType.LIST, `users/${userId}/emergencyContacts`);
  });
}
