import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ProtectedRoute } from './components/ProtectedRoute';

// Page Imports
import { Splash } from './pages/Splash';
import { Onboarding } from './pages/Onboarding';
import { Login } from './pages/Login';
import { Register } from './pages/Register';
import { ForgotPassword } from './pages/ForgotPassword';
import { Home } from './pages/Home';
import { JourneyTracker } from './pages/JourneyTracker';
import { EmergencyAlert } from './pages/EmergencyAlert';
import { LegalGuide } from './pages/LegalGuide';
import { CyberSafetyHub } from './pages/CyberSafetyHub';
import { SelfDefenseAwareness } from './pages/SelfDefenseAwareness';
import { EmergencyContacts } from './pages/EmergencyContacts';
import { Notifications } from './pages/Notifications';
import { Profile } from './pages/Profile';
import { SettingsPage } from './pages/SettingsPage';
import { ShareJourney } from './pages/ShareJourney';
import { OtpVerification } from './pages/OtpVerification';
import { AiAssistant } from './pages/AiAssistant';

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          {/* Public Routing */}
          <Route path="/" element={<Splash />} />
          <Route path="/onboarding" element={<Onboarding />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />
          
          {/* OTP Verification Route */}
          <Route
            path="/otp-verification"
            element={
              <ProtectedRoute showNavAndHeader={false}>
                <OtpVerification />
              </ProtectedRoute>
            }
          />
          
          {/* Public Shared tracking page */}
          <Route path="/share/:journeyId" element={<ShareJourney />} />

          {/* Secure Protected Routes with Header & Nav */}
          <Route
            path="/home"
            element={
              <ProtectedRoute>
                <Home />
              </ProtectedRoute>
            }
          />
          <Route
            path="/tracker"
            element={
              <ProtectedRoute>
                <JourneyTracker />
              </ProtectedRoute>
            }
          />
          <Route
            path="/legal"
            element={
              <ProtectedRoute>
                <LegalGuide />
              </ProtectedRoute>
            }
          />
          <Route
            path="/cyber"
            element={
              <ProtectedRoute>
                <CyberSafetyHub />
              </ProtectedRoute>
            }
          />
          <Route
            path="/self-defense"
            element={
              <ProtectedRoute>
                <SelfDefenseAwareness />
              </ProtectedRoute>
            }
          />
          <Route
            path="/contacts"
            element={
              <ProtectedRoute>
                <EmergencyContacts />
              </ProtectedRoute>
            }
          />
          <Route
            path="/notifications"
            element={
              <ProtectedRoute>
                <Notifications />
              </ProtectedRoute>
            }
          />
          <Route
            path="/profile"
            element={
              <ProtectedRoute>
                <Profile />
              </ProtectedRoute>
            }
          />
          <Route
            path="/settings"
            element={
              <ProtectedRoute>
                <SettingsPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/assistant"
            element={
              <ProtectedRoute>
                <AiAssistant />
              </ProtectedRoute>
            }
          />

          {/* Special Fullscreen Protected SOS Countdown (No Top Header / Bottom Nav) */}
          <Route
            path="/alert"
            element={
              <ProtectedRoute showNavAndHeader={false}>
                <EmergencyAlert />
              </ProtectedRoute>
            }
          />

          {/* Catch-all fallback */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
