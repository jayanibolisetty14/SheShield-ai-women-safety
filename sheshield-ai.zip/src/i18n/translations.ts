export type LanguageCode = 'en' | 'hi' | 'te' | 'ta' | 'kn' | 'ml' | 'mr' | 'bn' | 'gu' | 'pa';

export const LANGUAGES = [
  { code: 'en', name: 'English', nativeName: 'English' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी' },
  { code: 'te', name: 'Telugu', nativeName: 'తెలుగు' },
  { code: 'ta', name: 'Tamil', nativeName: 'தமிழ்' },
  { code: 'kn', name: 'Kannada', nativeName: 'ಕನ್ನಡ' },
  { code: 'ml', name: 'Malayalam', nativeName: 'മലയാളം' },
  { code: 'mr', name: 'Marathi', nativeName: 'मराठी' },
  { code: 'bn', name: 'Bengali', nativeName: 'বাংলা' },
  { code: 'gu', name: 'Gujarati', nativeName: 'ગુજરાતી' },
  { code: 'pa', name: 'Punjabi', nativeName: 'ਪੰਜਾਬੀ' },
];

export const translations: Record<LanguageCode, any> = {
  en: {
    title: "Legal Rights Guide",
    subtitle: "Empower yourself with direct knowledge.",
    searchPlaceholder: "Search laws...",
    noResults: "No legal topics matched your query.",
    provisionsTitle: "Key Legal Provisions",
    rightsTitle: "Your Protection Rights",
    laws: [
        { title: 'Zero FIR Guideline', section: 'Supreme Court Mandate (Lalita Kumari Case)', description: 'Allows a victim of a cognizable offense to file a First Information Report (FIR) at any police station across the country, regardless of jurisdiction. The police cannot refuse filing under jurisdiction pretexts; they must file it, register under serial number zero, and transfer it to the correct station.', provisions: ['Police officers refusing to file a Zero FIR can face disciplinary action or prosecution under Section 166A of IPC.', 'No territorial jurisdiction is required for registration of the initial complaint.'], rights: ['Free copy of the Zero FIR must be handed over to the victim immediately.', 'Right to prompt medical check-up if physical assault occurred.'] },
        { title: 'Domestic Violence Protections', section: 'Protection of Women from Domestic Violence Act, 2005', description: 'Comprehensive civil law providing protection and legal solutions to women experiencing physical, emotional, sexual, or economic abuse within their domestic relationships or shared households.', provisions: ['Includes married women, live-in partners, sisters, mothers, and daughters.', 'Appointment of Protection Officers to support the victim in seeking court orders.'], rights: ['Right to secure housing and Protection Orders prohibiting the abuser from entering her workspace or contacting her.', 'Right to immediate custody of children and financial monetary relief.'] },
        { title: 'Workplace Sexual Harassment', section: 'POSH Act, 2013', description: 'Mandates every workplace/organization with 10 or more employees to set up an Internal Complaints Committee (ICC) to address complaints regarding sexual harassment at the workplace.', provisions: ['Covers all women (employee, visitor, intern, regular or contract staff).', 'Inquiry must be completed within 90 days from filing the complaint.'], rights: ['Right to confidential filing and trial proceedings.', 'Right to transfer requests or paid leave (up to 3 months) during the POSH inquiry.'] },
        { title: 'Stalking Penalties', section: 'Section 354D of Indian Penal Code (IPC)', description: 'Criminalizes the act of stalking a woman, which includes physical following, repeatedly contacting her despite clear signs of disinterest, or monitoring her internet/email/electronic communication.', provisions: ['First conviction carries a non-bailable prison sentence of up to 3 years and a fine.', 'Subsequent convictions carry up to 5 years of rigorous imprisonment.'], rights: ['Right to immediate registration of a regular FIR.', 'Right to safe protective custody and police patrol watches if life threats are present.'] },
        { title: 'Cyber Bullying & Voyeurism', section: 'Sections 66E & 67A of IT Act / Section 354C of IPC', description: 'Covers cyber harassment, capture, publication, or transmission of images of private body parts of a woman without her explicit consent, or uploading sexually explicit content online.', provisions: ['Section 354C (Voyeurism) makes it a criminal offense to photograph or distribute images of a woman in private acts.', 'Section 66E of the IT Act penalizes violation of privacy with up to 3 years in jail.'], rights: ['Right to have non-consensual media blocked/removed from digital platforms within 24-36 hours.', 'Right to anonymous reporting directly to the National Cyber Crime portal.'] }
    ]
  },
  hi: {
    title: "कानूनी अधिकार गाइड",
    subtitle: "सीधे ज्ञान के साथ खुद को सशक्त बनाएं।",
    searchPlaceholder: "कानून खोजें...",
    noResults: "आपके खोज के लिए कोई कानूनी विषय नहीं मिला।",
    provisionsTitle: "मुख्य कानूनी प्रावधान",
    rightsTitle: "आपके सुरक्षा अधिकार",
    laws: [
        { title: 'जीरो एफआईआर दिशा-निर्देश', section: 'सुप्रीम कोर्ट का जनादेश (ललिता कुमारी मामला)', description: 'किसी संज्ञेय अपराध की पीड़िता को क्षेत्राधिकार की परवाह किए बिना देश भर के किसी भी पुलिस स्टेशन में प्रथम सूचना रिपोर्ट (एफआईआर) दर्ज करने की अनुमति देता है। पुलिस क्षेत्राधिकार के बहाने फाइल करने से इनकार नहीं कर सकती; उन्हें इसे फाइल करना होगा, शून्य सीरियल नंबर के तहत पंजीकरण करना होगा और इसे सही स्टेशन पर स्थानांतरित करना होगा।', provisions: ['जीरो एफआईआर दर्ज करने से इनकार करने वाले पुलिस अधिकारियों को अनुशासनहीनता या आईपीसी की धारा 166ए के तहत अभियोजन का सामना करना पड़ सकता है।', 'प्राथमिक शिकायत के पंजीकरण के लिए किसी भी क्षेत्रीय क्षेत्राधिकार की आवश्यकता नहीं है।'], rights: ['जीरो एफआईआर की एक निःशुल्क प्रति पीड़िता को तुरंत दी जानी चाहिए।', 'शारीरिक हमले की स्थिति में तत्काल चिकित्सा जांच का अधिकार।'] },
        { title: 'घरेलू हिंसा से सुरक्षा', section: 'महिलाओं का घरेलू हिंसा से संरक्षण अधिनियम, 2005', description: 'व्यापक नागरिक कानून जो घरेलू संबंधों या साझा घरों में शारीरिक, भावनात्मक, यौन या आर्थिक शोषण का सामना करने वाली महिलाओं को सुरक्षा और कानूनी समाधान प्रदान करता है।', provisions: ['विवाहित महिलाएं, लिव-इन पार्टनर, बहनें, माताएं और बेटियां शामिल हैं।', 'पीड़िता को अदालती आदेश प्राप्त करने में सहायता के लिए सुरक्षा अधिकारियों की नियुक्ति।'], rights: ['सुरक्षित आवास का अधिकार और सुरक्षा आदेश जो दुर्व्यवहार करने वाले को उसके कार्यस्थल में प्रवेश करने या उससे संपर्क करने से रोकता है।', 'बच्चों की तत्काल हिरासत और वित्तीय मौद्रिक राहत का अधिकार।'] },
        { title: 'कार्यस्थल पर यौन उत्पीड़न', section: 'POSH अधिनियम, 2013', description: 'कार्यस्थल पर यौन उत्पीड़न की शिकायतों को संबोधित करने के लिए 10 या अधिक कर्मचारियों वाले प्रत्येक कार्यस्थल/संगठन को एक आंतरिक शिकायत समिति (आईसीसी) स्थापित करने का आदेश देता है।', provisions: ['सभी महिलाओं को कवर करता है (कर्मचारी, आगंतुक, इंटर्न, नियमित या अनुबंध कर्मचारी)।', 'शिकायत दर्ज करने के 90 दिनों के भीतर जांच पूरी की जानी चाहिए।'], rights: ['गोपनीय फाइलिंग और परीक्षण कार्यवाही का अधिकार।', 'POSH जांच के दौरान स्थानांतरण अनुरोध या सवेतन अवकाश (3 महीने तक) का अधिकार।'] },
        { title: 'पीछा करने पर दंड', section: 'भारतीय दंड संहिता (IPC) की धारा 354D', description: 'किसी महिला का पीछा करने के कृत्य को अपराध घोषित करता है, जिसमें शारीरिक रूप से पीछा करना, रुचि के स्पष्ट संकेतों के बावजूद बार-बार संपर्क करना, या उसके इंटरनेट/ईमेल/इलेक्ट्रॉनिक संचार की निगरानी करना शामिल है।', provisions: ['पहली सजा में 3 साल तक की गैर-जमानती जेल की सजा और जुर्माना है।', 'बाद की सजाओं में 5 साल तक की कठोर कारावास की सजा है।'], rights: ['नियमित एफआईआर के तत्काल पंजीकरण का अधिकार।', 'जीवन के खतरे होने पर सुरक्षित सुरक्षात्मक हिरासत और पुलिस गश्त का अधिकार।'] },
        { title: 'साइबर बुलिंग और वोयूरिज्म', section: 'आईटी अधिनियम की धारा 66E और 67A / आईपीसी की धारा 354C', description: 'साइबर उत्पीड़न, किसी महिला की स्पष्ट सहमति के बिना उसके निजी अंगों की छवियों को कैप्चर, प्रकाशित या प्रसारित करना, या ऑनलाइन यौन स्पष्ट सामग्री अपलोड करना शामिल है।', provisions: ['धारा 354C (वोयूरिज्म) किसी महिला की निजी कार्यों की तस्वीरें लेना या वितरित करना एक आपराधिक अपराध बनाती है।', 'आईटी अधिनियम की धारा 66E गोपनीयता के उल्लंघन पर 3 साल तक की जेल का दंड देती है।'], rights: ['गैर-सहमति वाली मीडिया को 24-36 घंटों के भीतर डिजिटल प्लेटफॉर्म से ब्लॉक/हटाने का अधिकार।', 'राष्ट्रीय साइबर अपराध पोर्टल पर सीधे गुमनाम रिपोर्टिंग का अधिकार।'] }
    ]
  },
  te: { title: "చట్టపరమైన హక్కుల గైడ్", subtitle: "జ్ఞానంతో మిమ్మల్ని మీరు శక్తివంతం చేసుకోండి.", searchPlaceholder: "చట్టాలను శోధించండి...", noResults: "ఏదీ దొరకలేదు.", provisionsTitle: "నిబంధనలు", rightsTitle: "హక్కులు", laws: [] },
  ta: { title: "சட்ட உரிமைகள் கையேடு", subtitle: "நேரடி அறிவுடன் உங்களை மேம்படுத்துங்கள்.", searchPlaceholder: "சட்டங்களைத் தேடுங்கள்...", noResults: "எதுவும் கிடைக்கவில்லை.", provisionsTitle: "விதிகள்", rightsTitle: "உரிமைகள்", laws: [] },
  kn: { title: "ಕಾನೂನು ಹಕ್ಕುಗಳ ಮಾರ್ಗದರ್ಶಿ", subtitle: "ನೇರ ಜ್ಞಾನದೊಂದಿಗೆ ನಿಮ್ಮನ್ನು ಸಬಲರಾಗಿಸಿ.", searchPlaceholder: "ಕಾನೂನುಗಳನ್ನು ಹುಡುಕಿ...", noResults: "ಯಾವುದೂ ಸಿಗಲಿಲ್ಲ.", provisionsTitle: "ನಿಯಮಗಳು", rightsTitle: "ಹಕ್ಕುಗಳು", laws: [] },
  ml: { title: "നിയമപരമായ അവകാശങ്ങളുടെ ഗൈഡ്", subtitle: "നേരിട്ടുള്ള അറിവ് കൊണ്ട് സ്വയം ശാക്തീകരിക്കുക.", searchPlaceholder: "നിയമങ്ങൾ തിരയുക...", noResults: "ഒന്നും ലഭിച്ചില്ല.", provisionsTitle: "വ്യവസ്ഥകൾ", rightsTitle: "അവകാശങ്ങൾ", laws: [] },
  mr: { title: "कायदेशीर हक्क मार्गदर्शक", subtitle: "थेट ज्ञानाने स्वतःला सक्षम करा.", searchPlaceholder: "कायदे शोधा...", noResults: "काहीही सापडले नाही.", provisionsTitle: "तरतुदी", rightsTitle: "हक्क", laws: [] },
  bn: { title: "আইনি অধিকার নির্দেশিকা", subtitle: "সরাসরি জ্ঞানের সাথে নিজেকে শক্তিশালী করুন.", searchPlaceholder: "আইন অনুসন্ধান করুন...", noResults: "কিছু পাওয়া যায়নি।", provisionsTitle: "বিধান", rightsTitle: "অধিকার", laws: [] },
  gu: { title: "કાનૂની અધિકારો માર્ગદર્શિકા", subtitle: "સીધા જ્ઞાન સાથે તમારી જાતને સશક્ત બનાવો.", searchPlaceholder: "કાયદાઓ શોધો...", noResults: "કંઈ મળ્યું નથી.", provisionsTitle: "જોગવાઈઓ", rightsTitle: "અધિકારો", laws: [] },
  pa: { title: "ਕਾਨੂੰਨੀ ਅਧਿਕਾਰ ਗਾਈਡ", subtitle: "ਸਿੱਧੇ ਗਿਆਨ ਨਾਲ ਆਪਣੇ ਆਪ ਨੂੰ ਸਮਰੱਥ ਬਣਾਓ.", searchPlaceholder: "ਕਾਨੂੰਨ ਲੱਭੋ...", noResults: "ਕੁਝ ਨਹੀਂ ਮਿਲਿਆ।", provisionsTitle: "ਉਪਬੰਧ", rightsTitle: "ਅਧਿਕਾਰ", laws: [] }
};
