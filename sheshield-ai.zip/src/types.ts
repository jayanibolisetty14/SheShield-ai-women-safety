export interface Language {
  code: string;
  name: string;
  nativeName: string;
  voiceCode: string;
}

export const LANGUAGES: Language[] = [
  { code: 'en', name: 'English', nativeName: 'English', voiceCode: 'en-US' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी', voiceCode: 'hi-IN' },
  { code: 'es', name: 'Spanish', nativeName: 'Español', voiceCode: 'es-ES' },
  { code: 'fr', name: 'French', nativeName: 'Français', voiceCode: 'fr-FR' },
  { code: 'ar', name: 'Arabic', nativeName: 'العربية', voiceCode: 'ar-SA' },
  { code: 'bn', name: 'Bengali', nativeName: 'বাংলা', voiceCode: 'bn-IN' },
  { code: 'te', name: 'Telugu', nativeName: 'తెలుగు', voiceCode: 'te-IN' },
  { code: 'mr', name: 'Marathi', nativeName: 'मराठी', voiceCode: 'mr-IN' },
  { code: 'ta', name: 'Tamil', nativeName: 'தமிழ்', voiceCode: 'ta-IN' },
];
