import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { signOut } from 'firebase/auth';
import { auth } from '../services/firebase';
import { UserCheck, Shield, Settings, LogOut, Award, ChevronRight, Compass, ShieldAlert, ArrowLeft } from 'lucide-react';

export const Profile: React.FC = () => {
  const { currentUser, userProfile, logout } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    try {
      if (currentUser?.uid === 'demo_user') {
        await logout();
      } else {
        await signOut(auth);
      }
      console.log("User signed out");
      navigate('/login');
    } catch (err: any) {
      console.error('Sign out error:', err);
      alert(err.message || 'Error signing out.');
    }
  };

  return (
    <div className="flex flex-col gap-6 py-2 pb-12">
      {/* Back Button */}
      <div className="flex items-center gap-3">
        <button 
          onClick={() => navigate(-1)} 
          className="w-8 h-8 flex items-center justify-center rounded-full glass border border-white/10 hover:bg-white/5 transition active:scale-95 shrink-0"
        >
          <ArrowLeft className="w-4 h-4 text-white" />
        </button>
        <h2 className="text-xl font-bold font-display text-white">Profile Options</h2>
      </div>

      {/* 1. Profile Card with Avatar & Name */}
      <div className="glass p-5 rounded-[25px] flex flex-col items-center text-center relative overflow-hidden border border-purple-500/15">
        <div className="absolute top-0 right-0 w-32 h-32 bg-brand-purple/15 rounded-full blur-[40px] -translate-y-6 translate-x-6" />

        <img
          src={userProfile?.photoURL || 'https://api.dicebear.com/7.x/adventurer/svg?seed=default'}
          alt="Avatar"
          referrerPolicy="no-referrer"
          className="w-20 h-20 rounded-full border-4 border-brand-purple object-cover shadow-[0_4px_15px_rgba(124,58,237,0.3)]"
        />

        <h3 className="text-xl font-bold font-display text-white mt-4">{userProfile?.displayName || ''}</h3>
        <p className="text-xs text-brand-lavender font-mono mt-0.5">{userProfile?.email}</p>

        {/* Account Type pill */}
        <span className="mt-3.5 px-3 py-1 bg-brand-pink/15 border border-brand-pink/25 rounded-full text-[10px] font-bold font-mono text-brand-pink uppercase tracking-widest">
          Shield Active Member
        </span>
      </div>

      {/* 2. Menu options List */}
      <div className="flex flex-col gap-2.5">
        <span className="text-[10px] font-bold font-mono text-gray-500 uppercase tracking-widest pl-1">
          My Account
        </span>

        <div className="flex flex-col gap-2">
          {/* Trusted Guardians link */}
          <button
            onClick={() => navigate('/contacts')}
            className="glass p-4 rounded-xl flex items-center justify-between border border-purple-500/5 hover:border-purple-500/15 text-left transition"
          >
            <div className="flex items-center gap-3">
              <div className="p-2 bg-brand-purple/10 border border-brand-purple/15 rounded-xl text-brand-lavender">
                <UserCheck className="w-4.5 h-4.5" />
              </div>
              <div className="flex flex-col">
                <span className="text-xs font-bold text-white font-sans">Trusted Guardians</span>
                <span className="text-[10px] text-gray-400 mt-0.5">Add or manage your emergency contacts</span>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-gray-500" />
          </button>

          {/* Journey History shortcut */}
          <button
            onClick={() => navigate('/tracker')}
            className="glass p-4 rounded-xl flex items-center justify-between border border-purple-500/5 hover:border-purple-500/15 text-left transition"
          >
            <div className="flex items-center gap-3">
              <div className="p-2 bg-brand-pink/10 border border-brand-pink/15 rounded-xl text-brand-pink">
                <Compass className="w-4.5 h-4.5" />
              </div>
              <div className="flex flex-col">
                <span className="text-xs font-bold text-white font-sans">Journey Tracker</span>
                <span className="text-[10px] text-gray-400 mt-0.5">Track and share your live location</span>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-gray-500" />
          </button>

          {/* Settings link */}
          <button
            onClick={() => navigate('/settings')}
            className="glass p-4 rounded-xl flex items-center justify-between border border-purple-500/5 hover:border-purple-500/15 text-left transition"
          >
            <div className="flex items-center gap-3">
              <div className="p-2 bg-slate-500/10 border border-slate-500/15 rounded-xl text-slate-300">
                <Settings className="w-4.5 h-4.5" />
              </div>
              <div className="flex flex-col">
                <span className="text-xs font-bold text-white font-sans">Settings</span>
                <span className="text-[10px] text-gray-400 mt-0.5">App preferences</span>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-gray-500" />
          </button>
        </div>
      </div>

      {/* 3. Safe Out logout card */}
      <button
        onClick={handleSignOut}
        className="w-full h-11 rounded-xl bg-red-500/10 hover:bg-red-500/15 border border-red-500/20 text-red-400 text-xs font-bold font-sans flex items-center justify-center gap-2 transition"
      >
        <LogOut className="w-4 h-4" />
        <span>Sign Out from SheShield</span>
      </button>
    </div>
  );
};
