import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ShieldAlert, HeartHandshake } from 'lucide-react';

export const Splash: React.FC = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setTimeout(() => {
      const onboarded = localStorage.getItem('sheshield_onboarded');
      if (onboarded === 'true') {
        navigate('/login');
      } else {
        navigate('/onboarding');
      }
    }, 2800);

    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className="flex flex-col items-center justify-between min-h-screen bg-[#0B0617] px-6 py-12 relative overflow-hidden">
      {/* Background radial glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-brand-purple/20 rounded-full blur-[100px]" />
      <div className="absolute bottom-1/4 left-1/2 -translate-x-1/2 translate-y-1/2 w-80 h-80 bg-brand-pink/15 rounded-full blur-[100px]" />

      <div />

      {/* Center Logo Area */}
      <div className="flex flex-col items-center text-center z-10">
        <div className="relative mb-6 flex items-center justify-center">
          {/* Animated concentric rings */}
          <div className="absolute w-28 h-28 bg-brand-purple/30 rounded-full pulse-ring-element" />
          <div className="absolute w-20 h-20 bg-brand-pink/40 rounded-full pulse-ring-element [animation-delay:0.8s]" />
          
          <div className="relative w-16 h-16 bg-gradient-to-tr from-brand-purple to-brand-pink rounded-2xl flex items-center justify-center shadow-[0_0_30px_rgba(124,58,237,0.5)] border border-white/10">
            <ShieldAlert className="w-9 h-9 text-white" />
          </div>
        </div>

        <h1 className="text-4xl font-extrabold font-display tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white via-brand-lavender to-brand-pink drop-shadow-sm">
          SheShield AI
        </h1>
        <p className="mt-2 text-sm text-brand-lavender font-mono tracking-widest uppercase">
          Smart • Secure • Empowered
        </p>
      </div>

      {/* Footer Area */}
      <div className="flex flex-col items-center z-10 text-center gap-1">
        <div className="flex items-center gap-2 text-gray-400 text-xs">
          <HeartHandshake className="w-4 h-4 text-brand-pink" />
          <span>Women Safety & Empowerment</span>
        </div>
      </div>
    </div>
  );
};
