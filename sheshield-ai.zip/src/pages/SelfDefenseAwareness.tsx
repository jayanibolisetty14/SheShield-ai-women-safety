import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { ShieldCheck, Shield, Award, MapPin, Compass, ArrowLeft, Search, Bookmark, Phone, AlertTriangle, CheckCircle, Info } from 'lucide-react';

// Types
interface TipItem {
  id: string;
  category: 'Techniques' | 'Safety Tips' | 'Preparedness' | 'Scam Awareness' | 'Checklist' | 'Helpline';
  title: string;
  content: string;
  icon: React.ReactNode;
}

// Data
const allTips: TipItem[] = [
  // Techniques
  { id: '1', category: 'Techniques', title: 'Palm Heel Strike', content: 'Use the heel of your open palm, thrusting upward and into the attacker’s nose or jaw...', icon: <ShieldCheck /> },
  { id: '2', category: 'Techniques', title: 'The Throat Jab', content: 'Strike directly into the center hollow of the collarbone...', icon: <ShieldCheck /> },
  // ... add more

  // Safety Tips
  { id: '3', category: 'Safety Tips', title: 'Public Transport Vigilance', content: 'Always sit near the driver...', icon: <Compass /> },

  // Preparedness
  { id: '4', category: 'Preparedness', title: 'Emergency Actions', content: '1. Stay calm. 2. Call help. 3. Find cover...', icon: <AlertTriangle /> },

  // Scam Awareness
  { id: '5', category: 'Scam Awareness', title: 'Common Scams', content: 'Be wary of unsolicited links...', icon: <Info /> },

  // Checklist
  { id: '6', category: 'Checklist', title: 'Before Traveling', content: '1. Share location. 2. Check phone charge...', icon: <CheckCircle /> },

  // Helpline
  { id: '7', category: 'Helpline', title: 'Emergency Numbers', content: '100 - Police, 108 - Ambulance...', icon: <Phone /> },
];

export const SelfDefenseAwareness: React.FC = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [bookmarks, setBookmarks] = useState<string[]>(() => JSON.parse(localStorage.getItem('sd_bookmarks') || '[]'));

  const filteredTips = useMemo(() => {
    return allTips.filter(tip => {
      const matchesSearch = tip.title.toLowerCase().includes(searchQuery.toLowerCase()) || tip.content.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory === 'All' || tip.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [searchQuery, selectedCategory]);

  const toggleBookmark = (id: string) => {
    const newBookmarks = bookmarks.includes(id) ? bookmarks.filter(b => b !== id) : [...bookmarks, id];
    setBookmarks(newBookmarks);
    localStorage.setItem('sd_bookmarks', JSON.stringify(newBookmarks));
  };

  return (
    <div className="flex flex-col gap-6 py-4 pb-20 px-4">
      {/* Header */}
      <div className="flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="w-10 h-10 flex items-center justify-center rounded-full glass border border-white/10 hover:bg-white/5 transition active:scale-95">
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
        <h2 className="text-2xl font-bold font-display text-white">Self-Defense Awareness</h2>
      </div>

      {/* Search & Filter */}
      <div className="flex flex-col gap-3">
        <div className="relative">
          <Search className="absolute left-3 top-3 w-5 h-5 text-gray-500" />
          <input
            type="text"
            placeholder="Search tips..."
            className="w-full pl-10 pr-4 py-3 bg-white/5 rounded-2xl border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-brand-pink/50"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex gap-2 overflow-x-auto pb-2">
          {['All', 'Techniques', 'Safety Tips', 'Preparedness', 'Scam Awareness', 'Checklist', 'Helpline'].map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap border ${selectedCategory === cat ? 'bg-brand-purple/20 border-brand-purple/50 text-white' : 'bg-white/5 border-transparent text-gray-400'}`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Tips List */}
      <div className="grid grid-cols-1 gap-4">
        {filteredTips.map(tip => (
          <div key={tip.id} className="glass p-5 rounded-[24px] border border-white/5 flex flex-col gap-3">
            <div className="flex justify-between items-start">
              <div className="flex gap-3 items-center">
                <div className="p-2 bg-brand-purple/20 rounded-xl text-brand-pink">{tip.icon}</div>
                <h3 className="font-bold text-white">{tip.title}</h3>
              </div>
              <button onClick={() => toggleBookmark(tip.id)} className={`transition ${bookmarks.includes(tip.id) ? 'text-brand-pink' : 'text-gray-500'}`}>
                <Bookmark className={`w-5 h-5 ${bookmarks.includes(tip.id) ? 'fill-current' : ''}`} />
              </button>
            </div>
            <p className="text-sm text-gray-400">{tip.content}</p>
          </div>
        ))}
      </div>
    </div>
  );
};
