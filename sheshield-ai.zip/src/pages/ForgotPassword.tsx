import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { ShieldAlert, Mail, AlertCircle, CheckCircle, ArrowLeft } from 'lucide-react';

export const ForgotPassword: React.FC = () => {
  const { forgotPassword } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      setError('Please provide your email address.');
      return;
    }
    setError('');
    setSuccess('');
    setLoading(true);
    try {
      await forgotPassword(email);
      setSuccess('A password reset link has been dispatched to your email address.');
      setEmail('');
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Error executing password reset request.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col justify-center min-h-screen bg-[#0B0617] px-6 py-12 relative overflow-hidden">
      {/* Background ambient glow circles from Frosted Glass theme */}
      <div className="absolute top-[-100px] right-[-100px] w-[500px] h-[500px] bg-[#7C3AED]/20 rounded-full blur-[120px] pointer-events-none z-0" />
      <div className="absolute bottom-[-100px] left-[-100px] w-[500px] h-[500px] bg-[#EC4899]/15 rounded-full blur-[120px] pointer-events-none z-0" />

      {/* Back Button */}
      <button 
        onClick={() => navigate(-1)} 
        className="absolute top-8 left-6 z-20 w-10 h-10 flex items-center justify-center rounded-full glass border border-white/10 hover:bg-white/5 transition active:scale-95"
      >
        <ArrowLeft className="w-5 h-5 text-white" />
      </button>

      <div className="w-full max-w-sm mx-auto z-10">
        {/* Header Branding */}
        <div className="flex flex-col items-center text-center mb-8">
          <div className="w-12 h-12 bg-gradient-to-tr from-brand-purple to-brand-pink rounded-xl flex items-center justify-center shadow-lg border border-white/5 mb-3">
            <ShieldAlert className="w-6 h-6 text-white" />
          </div>
          <h2 className="text-2xl font-bold font-display text-white">Reset Password</h2>
          <p className="text-xs text-brand-lavender font-mono mt-1 uppercase tracking-wider">
            Recover access securely
          </p>
        </div>

        {/* Status Callouts */}
        {error && (
          <div className="mb-4 p-3.5 bg-red-500/10 border border-red-500/20 rounded-xl flex items-start gap-2 text-xs text-red-400">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {success && (
          <div className="mb-4 p-3.5 bg-green-500/10 border border-green-500/20 rounded-xl flex items-start gap-2 text-xs text-green-400">
            <CheckCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{success}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleReset} className="flex flex-col gap-4">
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-gray-400 font-sans">Email Address</label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                required
                className="w-full h-11 pl-10 pr-4 rounded-xl bg-white/5 border border-white/10 focus:border-brand-pink/50 focus:outline-none text-sm text-white placeholder-white/20 font-sans transition"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full h-11 rounded-xl bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-purple hover:to-brand-lavender text-white font-semibold text-sm font-sans flex items-center justify-center shadow-lg shadow-brand-purple/10 transition hover:scale-[1.01] disabled:opacity-50 mt-2"
          >
            {loading ? 'Dispatched request...' : 'Send Recovery Link'}
          </button>
        </form>

        {/* Back to Login */}
        <p className="text-center text-xs text-gray-400 mt-8 font-sans">
          Remembered your password?{' '}
          <Link to="/login" className="text-brand-pink hover:text-brand-lavender font-bold transition">
            Sign In
          </Link>
        </p>
      </div>
    </div>
  );
};
