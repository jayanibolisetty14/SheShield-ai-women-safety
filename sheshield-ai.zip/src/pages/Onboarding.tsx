import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Eye, ShieldAlert, BookOpen, ChevronRight } from 'lucide-react';

export const Onboarding: React.FC = () => {
  const navigate = useNavigate();
  const [activeSlide, setActiveSlide] = useState(0);

  const slides = [
    {
      title: 'AI Safety Monitoring',
      description: 'Our logical Heuristic Safety Engine evaluates route deviations, time-of-day risks, and sudden inactivity triggers to automatically secure your path.',
      icon: Eye,
      gradient: 'from-brand-purple to-indigo-600',
    },
    {
      title: 'Instant SOS System',
      description: 'Trigger visual alarms, record voice triggers, capture background evidence, and dispatch instant SMS/WhatsApp alerts with coordinates to guardians.',
      icon: ShieldAlert,
      gradient: 'from-brand-purple to-brand-pink',
    },
    {
      title: 'Legal & Cyber Hub',
      description: 'Empower yourself with direct access to physical and cyber laws including Zero FIR, workplace safety, and stalker guidelines, readable completely offline.',
      icon: BookOpen,
      gradient: 'from-brand-pink to-rose-500',
    },
  ];

  const handleNext = () => {
    if (activeSlide < slides.length - 1) {
      setActiveSlide(activeSlide + 1);
    } else {
      localStorage.setItem('sheshield_onboarded', 'true');
      navigate('/login');
    }
  };

  const handleSkip = () => {
    localStorage.setItem('sheshield_onboarded', 'true');
    navigate('/login');
  };

  const SlideIcon = slides[activeSlide].icon;

  return (
    <div className="flex flex-col justify-between min-h-screen bg-[#0B0617] px-6 py-12 relative overflow-hidden">
      {/* Glow */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 bg-brand-purple/15 rounded-full blur-[90px]" />

      {/* Top Header */}
      <div className="flex justify-between items-center z-10">
        <span className="text-sm font-bold font-display text-brand-lavender">SheShield AI</span>
        {activeSlide < slides.length - 1 && (
          <button
            onClick={handleSkip}
            className="text-xs text-gray-400 hover:text-white transition font-sans"
          >
            Skip
          </button>
        )}
      </div>

      {/* Slide Content */}
      <div className="flex flex-col items-center text-center my-auto z-10">
        <div className={`w-20 h-20 rounded-2xl bg-gradient-to-tr ${slides[activeSlide].gradient} flex items-center justify-center shadow-lg mb-8 transition-transform duration-500 hover:scale-105`}>
          <SlideIcon className="w-10 h-10 text-white" />
        </div>

        <h2 className="text-2xl font-bold font-display text-white mb-4">
          {slides[activeSlide].title}
        </h2>
        <p className="text-sm text-gray-300 leading-relaxed max-w-sm font-sans">
          {slides[activeSlide].description}
        </p>
      </div>

      {/* Footer Controls */}
      <div className="flex flex-col gap-6 z-10">
        {/* Slide Indicators */}
        <div className="flex justify-center gap-2">
          {slides.map((_, idx) => (
            <div
              key={idx}
              className={`h-1.5 rounded-full transition-all duration-300 ${
                activeSlide === idx ? 'w-6 bg-brand-pink' : 'w-2 bg-gray-600'
              }`}
            />
          ))}
        </div>

        {/* Action Button */}
        <button
          onClick={handleNext}
          className="w-full h-13 rounded-2xl bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-purple hover:to-brand-lavender text-white font-semibold font-sans flex items-center justify-center gap-2 shadow-lg shadow-brand-purple/20 transition-all hover:scale-[1.01]"
        >
          <span>{activeSlide === slides.length - 1 ? "Get Started" : "Continue"}</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
