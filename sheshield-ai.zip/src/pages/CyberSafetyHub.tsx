import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, ShieldAlert, Globe, MessageSquare, AlertCircle, ExternalLink, ArrowLeft } from 'lucide-react';
import { FloatingBot } from '../components/FloatingBot';
import { OfflineBanner } from '../components/OfflineBanner';

interface GuideItem {
  title: string;
  category: 'Scams & Fraud' | 'Cyber Bullying' | 'Social Privacy';
  summary: string;
  steps: string[];
  tips: string[];
  reportLink?: { label: string; url: string };
}

export const CyberSafetyHub: React.FC = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);

  const guides: GuideItem[] = [
    {
      title: 'Phishing & Online Financial Scams',
      category: 'Scams & Fraud',
      summary: 'Deceptive messages or emails posing as legitimate banks, courier services, or government bodies requesting money transfers, OTP verification, or personal identity documents.',
      steps: [
        'Never click on shortened links received via unsolicited SMS or WhatsApp chats.',
        'Legitimate banks will never ask for your passwords, card PINs, or UPI OTP numbers over the phone.',
        'Verify courier alerts by searching the tracking number directly on the official postal website.'
      ],
      tips: [
        'Install UPI verification guards and call your bank branch immediately if money is debited.',
        'Double-check email domains to ensure they match real organizations (e.g. support@fedex.com, not fedex-support@gmail.com).'
      ],
      reportLink: { label: 'Report Financial Fraud (National Portal)', url: 'https://cybercrime.gov.in' }
    },
    {
      title: 'Online Harassment & Cyber Bullying',
      category: 'Cyber Bullying',
      summary: 'Targeted abusive posts, defamatory comments, non-consensual sharing of personal photographs, or threats of blackmail / extortion over digital platforms.',
      steps: [
        'Screenshot all abusive communication immediately to capture vital evidence (timestamps, usernames).',
        'Do not reply or engage with cyber bullies; interactions often escalate their harassment.',
        'Report the offender profiles directly to the platform’s abuse division (Instagram, Twitter/X, Facebook).'
      ],
      tips: [
        'Block offending profiles immediately after archiving evidence.',
        'Remember that sharing non-consensual images is a serious offense. You have the right to demand platform take-downs.'
      ],
      reportLink: { label: 'File Harassment Complaint', url: 'https://cybercrime.gov.in' }
    },
    {
      title: 'Social Media Profile Privacy Lock',
      category: 'Social Privacy',
      summary: 'Configuring social networking platforms (Instagram, Snapchat, Facebook) to prevent random stalkers from tracking your physical whereabouts, photographs, or contact numbers.',
      steps: [
        'Switch accounts to "Private Profile" so only approved friends can view posted stories or media.',
        'Turn off "Live Location Sharing" and disable precise GPS tags on posted photo uploads.',
        'Restrict direct messages to "Friends Only" to filter out unsolicited chats from strangers.'
      ],
      tips: [
        'Periodically review active logins in account settings and log out of unrecognized devices.',
        'Enable Two-Factor Authentication (2FA) using authenticator apps to block hijacking attempts.'
      ]
    },
    {
      title: 'Workplace Email Spoofing & Phishing',
      category: 'Scams & Fraud',
      summary: 'Urgent requests from high-profile executive names (CEOs, Managers) requesting gift card purchases, confidential code credentials, or immediate business transfers.',
      steps: [
        'Always call or verify in-person with the manager before dispatching money or files.',
        'Check the headers for reply-to mismatches where sender is different from the spoofed name.'
      ],
      tips: [
        'Flag spoofed emails as spam or phishing to your company’s internal IT Security Desk.'
      ]
    }
  ];

  const categories = ['All', 'Scams & Fraud', 'Cyber Bullying', 'Social Privacy'];

  const filteredGuides = guides.filter((g) => {
    const matchesQuery =
      g.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      g.summary.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === 'All' || g.category === activeCategory;
    return matchesQuery && matchesCategory;
  });

  return (
    <div className="flex flex-col gap-5 py-2 pb-12">
      {/* Page Title */}
      <div className="flex flex-col mt-1">
        <div className="flex items-center gap-3 mb-2">
          <button 
            onClick={() => navigate(-1)} 
            className="w-8 h-8 flex items-center justify-center rounded-full glass border border-white/10 hover:bg-white/5 transition active:scale-95 shrink-0"
          >
            <ArrowLeft className="w-4 h-4 text-white" />
          </button>
          <h2 className="text-xl font-bold font-display text-white">Cyber Safety Hub</h2>
        </div>
        <p className="text-xs text-gray-400 font-sans mt-0.5 pl-11">
          Safeguard your digital identity and discover actionable tips to counter online scams and harassment.
        </p>
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-gray-500" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search safety guides..."
          className="w-full h-11 pl-10 pr-4 rounded-xl bg-brand-card/70 border border-purple-500/15 focus:border-brand-pink/50 focus:outline-none text-sm text-white placeholder-gray-500 font-sans transition"
        />
      </div>

      {/* Category Pills */}
      <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => {
              setActiveCategory(cat);
              setExpandedIndex(null);
            }}
            className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition cursor-pointer select-none ${
              activeCategory === cat
                ? 'bg-gradient-to-r from-brand-purple to-brand-pink text-white border-none'
                : 'bg-brand-card text-gray-400 border border-purple-500/10 hover:text-white'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      <OfflineBanner />

      {/* Guides list */}
      <div className="flex flex-col gap-3">
        {filteredGuides.length > 0 ? (
          filteredGuides.map((guide, idx) => {
            const isExpanded = expandedIndex === idx;

            return (
              <div
                key={idx}
                className="glass rounded-[20px] overflow-hidden transition-all duration-300 border border-purple-500/10 hover:border-purple-500/20"
              >
                {/* Header Toggle */}
                <div
                  onClick={() => setExpandedIndex(isExpanded ? null : idx)}
                  className="p-4 flex flex-col gap-1 cursor-pointer select-none bg-white/[0.01]"
                >
                  <span className="text-[10px] font-bold font-mono text-brand-pink uppercase tracking-widest">
                    {guide.category}
                  </span>
                  <span className="text-sm font-bold text-white font-display leading-tight">{guide.title}</span>
                  <p className="text-xs text-gray-400 line-clamp-2 mt-1 font-sans">{guide.summary}</p>
                </div>

                {/* Expanded steps */}
                {isExpanded && (
                  <div className="px-5 pb-5 border-t border-purple-500/5 pt-4 bg-black/10 flex flex-col gap-4 text-xs leading-relaxed text-gray-300 font-sans">
                    {/* Action Steps */}
                    <div>
                      <span className="font-bold text-white block mb-1.5 uppercase font-mono tracking-wider text-[10px] text-brand-lavender">
                        Immediate Response Actions
                      </span>
                      <ol className="list-decimal pl-4 flex flex-col gap-2">
                        {guide.steps.map((step, sIdx) => (
                          <li key={sIdx}>{step}</li>
                        ))}
                      </ol>
                    </div>

                    {/* Safety Tips box */}
                    <div className="p-3 bg-brand-purple/10 border border-brand-purple/15 rounded-xl">
                      <span className="font-bold text-white flex items-center gap-1.5 mb-1.5 uppercase font-mono tracking-wider text-[10px] text-brand-pink">
                        <AlertCircle className="w-3.5 h-3.5" />
                        Preventative Safety Tips
                      </span>
                      <ul className="list-disc pl-4 flex flex-col gap-1.5">
                        {guide.tips.map((tip, tIdx) => (
                          <li key={tIdx} className="text-gray-200">
                            {tip}
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Actionable Link */}
                    {guide.reportLink && (
                      <a
                        href={guide.reportLink.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="h-10 rounded-xl bg-gradient-to-r from-brand-purple/20 to-brand-pink/20 border border-brand-pink/30 hover:border-brand-pink/50 text-white font-semibold text-[11px] font-sans flex items-center justify-center gap-1.5 transition"
                      >
                        <span>{guide.reportLink.label}</span>
                        <ExternalLink className="w-3.5 h-3.5 text-brand-pink" />
                      </a>
                    )}
                  </div>
                )}
              </div>
            );
          })
        ) : (
          <div className="text-center py-10">
            <p className="text-sm text-gray-400 font-sans">No digital safety guides found matching your choice.</p>
          </div>
        )}
      </div>
      <FloatingBot />
    </div>
  );
};
