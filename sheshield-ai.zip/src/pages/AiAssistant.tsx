import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { Send, ArrowLeft, Bot, User, AlertTriangle, Mic, MicOff, Volume2, VolumeX, Languages } from 'lucide-react';
import { sendMessageToBot, ChatMessage } from '../services/chatbot';
import { LANGUAGES, Language } from '../types';
import { useSpeech } from '../hooks/useSpeech';

export const AiAssistant: React.FC = () => {
  const navigate = useNavigate();
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<{ role: 'user' | 'bot'; text: string }[]>([]);
  const [history, setHistory] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isRateLimited, setIsRateLimited] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState<Language>(LANGUAGES[0]);
  const [showLanguageMenu, setShowLanguageMenu] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { isListening, isSpeaking, startListening, stopListening, speak, stopSpeaking } = useSpeech(selectedLanguage);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  useEffect(() => {
    // Initial greeting
    const greeting = selectedLanguage.code === 'hi' 
      ? "👋 नमस्ते! SheShield AI में आपका स्वागत है। मैं आपकी AI सुरक्षा सहायक हूँ, जो आपको सूचित और सुरक्षित रखने में मदद के लिए यहाँ हूँ।\n\nमैं आपकी सहायता कर सकती हूँ:\n- 🛡️ महिलाओं की सुरक्षा मार्गदर्शन\n- 🚨 SOS और आपातकालीन सहायता\n- 📍 स्थान और सुरक्षा सुझाव\n- 👥 विश्वसनीय संपर्क\n- ❓ SheShield AI सुविधाओं के बारे में जानकारी\n\nआज मैं आपकी कैसे मदद कर सकती हूँ? आपकी सुरक्षा मेरी प्राथमिकता है।"
      : "👋 Hello! Welcome to SheShield AI. I'm your AI Safety Assistant, here to help you stay informed and protected.\n\nI can assist you with:\n- 🛡️ Women's safety guidance\n- 🚨 SOS and emergency support\n- 📍 Location and safety tips\n- 👥 Trusted contacts\n- ❓ Information about SheShield AI features\n\nHow can I help you today? Your safety is my priority.";
    
    setMessages([
      { role: 'bot', text: greeting }
    ]);
  }, [selectedLanguage]);

  const handleSend = async (customMessage?: string) => {
    const userMessage = customMessage || input.trim();
    if (!userMessage || isLoading || isRateLimited) return;

    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setIsLoading(true);
    setIsRateLimited(true);

    // Re-enable send button after 1 second
    setTimeout(() => setIsRateLimited(false), 1000);

    try {
      const botResponse = await sendMessageToBot(userMessage, history, selectedLanguage.name);
      
      setMessages(prev => [...prev, { role: 'bot', text: botResponse }]);
      
      // Auto-read bot response if needed (optional, could be a toggle)
      // speak(botResponse);
      
      // Update history for context
      const newHistory: ChatMessage[] = [
        ...history,
        { role: 'user', parts: [{ text: userMessage }] },
        { role: 'model', parts: [{ text: botResponse }] }
      ];
      
      // Keep only last 10 messages for context
      setHistory(newHistory.slice(-10));
    } catch (error: any) {
      setMessages(prev => [...prev, { 
        role: 'bot', 
        text: "I'm having trouble responding right now — please try again, or use the SOS button if this is an emergency." 
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleVoiceInput = () => {
    if (isListening) {
      stopListening();
    } else {
      startListening((text) => {
        handleSend(text);
      });
    }
  };

  return (
    <div className="flex flex-col h-screen bg-[#0a050d] text-white">
      {/* Header */}
      <div className="glass px-4 py-4 flex items-center justify-between border-b border-white/5 sticky top-0 z-20">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-white/5 rounded-full transition">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <div className="p-2 bg-brand-pink/20 rounded-xl text-brand-pink">
              <Bot className="w-5 h-5" />
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-bold tracking-tight">SheShield AI</span>
              <span className="text-[10px] text-green-400 flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" />
                AI Assistant Active
              </span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setShowLanguageMenu(!showLanguageMenu)}
            className="p-2 bg-white/5 text-white/70 rounded-xl hover:bg-white/10 transition relative"
          >
            <Languages className="w-5 h-5" />
            <span className="absolute -top-1 -right-1 bg-brand-pink text-[8px] font-bold px-1 rounded-full uppercase">
              {selectedLanguage.code}
            </span>
          </button>
          
          <button 
            onClick={() => navigate('/alert')}
            className="p-2 bg-red-500/20 text-red-400 rounded-xl hover:bg-red-500/30 transition flex items-center gap-1.5 px-3"
          >
            <AlertTriangle className="w-4 h-4" />
            <span className="text-[10px] font-bold uppercase tracking-wider">SOS</span>
          </button>
        </div>
      </div>

      {/* Language Menu */}
      <AnimatePresence>
        {showLanguageMenu && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-16 right-4 z-30 glass border border-white/10 rounded-2xl p-2 w-48 shadow-2xl"
          >
            <div className="grid grid-cols-1 gap-1">
              {LANGUAGES.map((lang) => (
                <button
                  key={lang.code}
                  onClick={() => {
                    setSelectedLanguage(lang);
                    setShowLanguageMenu(false);
                    setHistory([]); // Clear history when changing language to avoid mixed-language context issues
                  }}
                  className={`flex items-center justify-between px-3 py-2 rounded-xl text-xs transition ${
                    selectedLanguage.code === lang.code ? 'bg-brand-pink text-white' : 'hover:bg-white/5 text-white/70'
                  }`}
                >
                  <span>{lang.name}</span>
                  <span className="opacity-50">{lang.nativeName}</span>
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4">
        <AnimatePresence initial={false}>
          {messages.map((msg, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ duration: 0.2 }}
              className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div className={`max-w-[85%] px-4 py-3 rounded-2xl text-sm leading-relaxed relative group ${
                msg.role === 'user' 
                ? 'bg-brand-pink text-white rounded-tr-none' 
                : 'glass border border-white/10 text-white/90 rounded-tl-none'
              }`}>
                {msg.text}
                
                {msg.role === 'bot' && (
                  <button 
                    onClick={() => isSpeaking ? stopSpeaking() : speak(msg.text)}
                    className="absolute -right-10 top-1/2 -translate-y-1/2 p-2 rounded-full hover:bg-white/5 text-white/30 hover:text-brand-pink transition"
                  >
                    {isSpeaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                  </button>
                )}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {isLoading && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex justify-start"
          >
            <div className="glass border border-white/10 px-4 py-3 rounded-2xl rounded-tl-none">
              <div className="flex gap-1">
                <motion.span 
                  animate={{ opacity: [0.3, 1, 0.3] }} 
                  transition={{ repeat: Infinity, duration: 1 }}
                  className="w-1.5 h-1.5 bg-brand-pink rounded-full" 
                />
                <motion.span 
                  animate={{ opacity: [0.3, 1, 0.3] }} 
                  transition={{ repeat: Infinity, duration: 1, delay: 0.2 }}
                  className="w-1.5 h-1.5 bg-brand-pink rounded-full" 
                />
                <motion.span 
                  animate={{ opacity: [0.3, 1, 0.3] }} 
                  transition={{ repeat: Infinity, duration: 1, delay: 0.4 }}
                  className="w-1.5 h-1.5 bg-brand-pink rounded-full" 
                />
              </div>
            </div>
          </motion.div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-4 bg-[#0a050d] border-t border-white/5 pb-8">
        <div className="flex items-center gap-2">
          <button
            onClick={handleVoiceInput}
            className={`p-3.5 rounded-2xl transition border ${
              isListening 
              ? 'bg-red-500/20 border-red-500 text-red-500 animate-pulse' 
              : 'bg-white/5 border-white/10 text-white/50 hover:text-brand-pink'
            }`}
          >
            {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>
          
          <div className="relative flex-1 flex items-center">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder={isListening ? "Listening..." : "Type your question..."}
              className="w-full bg-white/5 border border-white/10 rounded-2xl px-4 py-3.5 text-sm focus:outline-none focus:border-brand-pink/50 transition pr-12"
            />
            <button
              onClick={() => handleSend()}
              disabled={!input.trim() || isLoading || isRateLimited}
              className={`absolute right-1.5 p-2.5 rounded-xl transition ${
                input.trim() && !isLoading && !isRateLimited
                ? 'bg-brand-pink text-white shadow-lg'
                : 'bg-white/5 text-white/20'
              }`}
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
        <p className="text-[10px] text-white/30 mt-3 text-center px-4">
          SheShield AI is an AI assistant. For emergencies, tap the SOS button or call 112.
        </p>
      </div>
    </div>
  );
};
