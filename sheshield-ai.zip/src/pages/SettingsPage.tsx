import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Settings, Shield, Moon, Eye, AlertTriangle, Check, Sliders, Lock, Trash2, EyeOff, ArrowLeft } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const SettingsPage: React.FC = () => {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  
  const [vibrationEnabled, setVibrationEnabled] = useState(true);
  const [highAccuracyEnabled, setHighAccuracyEnabled] = useState(true);
  
  return (
    <div className="flex flex-col gap-5 py-2 pb-12">
      {/* Title */}
      <div className="flex flex-col mt-1">
        <div className="flex items-center gap-3 mb-2">
          <button 
            onClick={() => navigate(-1)} 
            className="w-8 h-8 flex items-center justify-center rounded-full glass border border-white/10 hover:bg-white/5 transition active:scale-95 shrink-0"
          >
            <ArrowLeft className="w-4 h-4 text-white" />
          </button>
          <h2 className="text-xl font-bold font-display text-white">System Settings</h2>
        </div>
        <p className="text-xs text-gray-400 font-sans mt-0.5 pl-11">
          Tune your emergency preferences and security parameters.
        </p>
      </div>

      {/* 1. App Theme Preference */}
      <div className="glass p-4 rounded-[20px] flex flex-col gap-3 border border-purple-500/10">
        <h3 className="text-xs font-bold uppercase tracking-wider text-brand-pink font-mono flex items-center gap-1.5">
          <Moon className="w-4 h-4" />
          Active Application Theme
        </h3>

        <div className="p-3 bg-white/[0.02] border border-purple-500/5 rounded-xl flex items-center justify-between">
          <div className="flex flex-col">
            <span className="text-xs font-bold text-white font-sans">Neon Twilight Theme</span>
            <span className="text-[10px] text-brand-lavender font-sans mt-0.5">Optimized for safety and contrast</span>
          </div>
          <div className="p-1 px-2.5 bg-brand-pink/15 rounded-md border border-brand-pink/25 text-[10px] font-bold text-brand-pink flex items-center gap-1 font-sans">
            <Check className="w-3 h-3" />
            <span>ACTIVE</span>
          </div>
        </div>
      </div>

      {/* 2. Device Parameters Configuration */}
      <div className="glass p-4 rounded-[20px] flex flex-col gap-3.5 border border-purple-500/10">
        <h3 className="text-xs font-bold uppercase tracking-wider text-brand-pink font-mono flex items-center gap-1.5">
          <Sliders className="w-4 h-4" />
          Feedback Preferences
        </h3>

        <div className="flex flex-col gap-3.5">
          {/* Vibration */}
          <div className="flex items-center justify-between">
            <div className="flex flex-col gap-0.5">
              <span className="text-xs font-bold text-white font-sans">Physical Vibration Loops</span>
              <p className="text-[10px] text-gray-400 leading-tight max-w-[200px] font-sans">
                Trigger heavy rhythmic device vibration pattern when alarm triggers.
              </p>
            </div>
            <button
              onClick={() => setVibrationEnabled(!vibrationEnabled)}
              className={`w-11 h-5.5 rounded-full p-0.5 transition-colors duration-300 outline-none ${
                vibrationEnabled ? 'bg-brand-pink' : 'bg-gray-700'
              }`}
            >
              <div
                className={`w-4.5 h-4.5 bg-white rounded-full shadow-md transform duration-300 ${
                  vibrationEnabled ? 'translate-x-5.5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          <div className="border-t border-purple-500/5" />

          {/* High Accuracy GPS */}
          <div className="flex items-center justify-between">
            <div className="flex flex-col gap-0.5">
              <span className="text-xs font-bold text-white font-sans">High Accuracy GPS Watch</span>
              <p className="text-[10px] text-gray-400 leading-tight max-w-[200px] font-sans">
                Prioritize satellite GPS connection over cellular triangulation for precise routes.
              </p>
            </div>
            <button
              onClick={() => setHighAccuracyEnabled(!highAccuracyEnabled)}
              className={`w-11 h-5.5 rounded-full p-0.5 transition-colors duration-300 outline-none ${
                highAccuracyEnabled ? 'bg-brand-pink' : 'bg-gray-700'
              }`}
            >
              <div
                className={`w-4.5 h-4.5 bg-white rounded-full shadow-md transform duration-300 ${
                  highAccuracyEnabled ? 'translate-x-5.5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
