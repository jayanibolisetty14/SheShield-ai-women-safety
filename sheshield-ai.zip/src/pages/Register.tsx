import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { ShieldAlert, User, Mail, Lock, AlertCircle, Eye, EyeOff, ArrowLeft } from 'lucide-react';

export const Register: React.FC = () => {
  const { register } = useAuth();
  const navigate = useNavigate();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !password) {
      setError('Please fill in all fields.');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    setError('');
    setLoading(true);
    try {
      await register(email, password, name);
      localStorage.setItem('otp_pending', 'true');
      navigate('/otp-verification');
    } catch (err: any) {
      console.error(err);
      if (err.code === 'auth/operation-not-allowed') {
        setError('Email/Password Authentication is not enabled in your Firebase Console. Please follow the link below to enable it.');
      } else {
        setError(err.message || 'Failed to create an account.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col justify-center min-h-screen bg-[#0B0617] px-6 py-12 relative overflow-hidden">
      {/* Background ambient glow circles from Frosted Glass theme */}
      <div className="absolute top-[-100px] right-[-100px] w-[500px] h-[500px] bg-[#7C3AED]/20 rounded-full blur-[120px] pointer-events-none z-0" />
      <div className="absolute bottom-[-100px] left-[-100px] w-[500px] h-[500px] bg-[#EC4899]/15 rounded-full blur-[120px] pointer-events-none z-0" />

      {/* Back Button */}
      <button 
        onClick={() => navigate(-1)} 
        className="absolute top-8 left-6 z-20 w-10 h-10 flex items-center justify-center rounded-full glass border border-white/10 hover:bg-white/5 transition active:scale-95"
      >
        <ArrowLeft className="w-5 h-5 text-white" />
      </button>

      <div className="w-full max-w-sm mx-auto z-10">
        {/* Header Branding */}
        <div className="flex flex-col items-center text-center mb-8">
          <div className="w-12 h-12 bg-gradient-to-tr from-brand-purple to-brand-pink rounded-xl flex items-center justify-center shadow-lg border border-white/5 mb-3">
            <ShieldAlert className="w-6 h-6 text-white" />
          </div>
          <h2 className="text-2xl font-bold font-display text-white">Create Account</h2>
          <p className="text-xs text-brand-lavender font-mono mt-1 uppercase tracking-wider">
            Join the safety network
          </p>
        </div>

        {/* Error Callout */}
        {error && (
          <div className="mb-5 p-4 bg-red-500/10 border border-red-500/20 rounded-2xl flex flex-col gap-2.5 text-xs text-red-400">
            <div className="flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
            {(error.toLowerCase().includes('sign-in') || error.toLowerCase().includes('not-allowed') || error.toLowerCase().includes('operation')) && (
              <div className="flex gap-2">
                <a
                  href="https://console.firebase.google.com/project/sheshield-a1-1/authentication/providers"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 mt-1 px-3 py-1.5 bg-red-500/20 hover:bg-red-500/30 border border-red-500/30 rounded-xl font-bold tracking-wide uppercase text-center text-[10px] text-white transition-all inline-block"
                >
                  Go to Firebase Auth Console
                </a>
                <button
                  type="button"
                  onClick={handleRegister}
                  className="flex-1 mt-1 px-3 py-1.5 bg-red-500/20 hover:bg-red-500/30 border border-red-500/30 rounded-xl font-bold tracking-wide uppercase text-center text-[10px] text-white transition-all inline-block cursor-pointer"
                >
                  Retry
                </button>
              </div>
            )}
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleRegister} className="flex flex-col gap-4">
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-gray-400 font-sans">Full Name</label>
            <div className="relative">
              <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Jane Doe"
                required
                className="w-full h-11 pl-10 pr-4 rounded-xl bg-white/5 border border-white/10 focus:border-brand-pink/50 focus:outline-none text-sm text-white placeholder-white/20 font-sans transition"
              />
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-gray-400 font-sans">Email Address</label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="jane@example.com"
                required
                className="w-full h-11 pl-10 pr-4 rounded-xl bg-white/5 border border-white/10 focus:border-brand-pink/50 focus:outline-none text-sm text-white placeholder-white/20 font-sans transition"
              />
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-gray-400 font-sans">Password</label>
            <div className="relative">
              <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="At least 6 characters"
                required
                className="w-full h-11 pl-10 pr-12 rounded-xl bg-white/5 border border-white/10 focus:border-brand-pink/50 focus:outline-none text-sm text-white placeholder-white/20 font-sans transition"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white transition flex items-center justify-center p-1 rounded-md focus:outline-none focus:ring-1 focus:ring-brand-pink/50 cursor-pointer"
                aria-label={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? (
                  <EyeOff className="w-4 h-4" />
                ) : (
                  <Eye className="w-4 h-4" />
                )}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full h-11 rounded-xl bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-purple hover:to-brand-lavender text-white font-semibold text-sm font-sans flex items-center justify-center shadow-lg shadow-brand-purple/10 transition hover:scale-[1.01] disabled:opacity-50 mt-2"
          >
            {loading ? 'Creating Account...' : 'Sign Up'}
          </button>
        </form>

        {/* Back to Login */}
        <p className="text-center text-xs text-gray-400 mt-8 font-sans">
          Already have an account?{' '}
          <Link to="/login" className="text-brand-pink hover:text-brand-lavender font-bold transition">
            Sign In
          </Link>
        </p>
      </div>
    </div>
  );
};
