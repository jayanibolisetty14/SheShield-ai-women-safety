import React, { useEffect, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getContacts, EmergencyContact } from '../services/contacts';
import { createAlert, attachEvidenceToAlert, resolveAlert } from '../services/alerts';
import { uploadEvidence } from '../services/storage';
import { ShieldCheck, ShieldAlert, AlertTriangle, RefreshCw, Volume2, VolumeX, Mic, EyeOff, Zap, CheckCircle2, CircleDashed, ExternalLink } from 'lucide-react';

export const EmergencyAlert: React.FC = () => {
  const { currentUser, userProfile, updateSafety, currentLocation, locationError } = useAuth();
  const navigate = useNavigate();

  const [countdown, setCountdown] = useState(60);
  const [contacts, setContacts] = useState<EmergencyContact[]>([]);
  const [statusText, setStatusText] = useState('Initiating emergency protocols...');
  const [alertActive, setAlertActive] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [notifiedGuardians, setNotifiedGuardians] = useState<{[key: string]: 'pending' | 'success' | 'failed'}>({});
  const [activeAlertId, setActiveAlertId] = useState<string | null>(null);
  
  // Siren Refs
  const audioCtxRef = useRef<AudioContext | null>(null);
  const oscillatorRef = useRef<OscillatorNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const sweepIntervalRef = useRef<any>(null);
  
  // Torch/Flashlight support state
  const [hasTorch, setHasTorch] = useState(false);
  const [torchOn, setTorchOn] = useState(false);
  const [mediaStream, setMediaStream] = useState<MediaStream | null>(null);

  // Audio Evidence State
  const [isRecording, setIsRecording] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  // Refs for countdown loop
  const timerRef = useRef<any>(null);

  // 1. Fetch trusted contacts and check flashlight
  useEffect(() => {
    if (currentUser) {
      getContacts(currentUser.uid).then(setContacts).catch(console.error);
    }

    checkFlashlightSupport();
  }, [currentUser]);

  // Siren Logic
  const startSiren = () => {
    if (isMuted) return;
    
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }

      // Create nodes
      const oscillator = ctx.createOscillator();
      const gainNode = ctx.createGain();
      
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(600, ctx.currentTime);
      
      gainNode.gain.setValueAtTime(0.15, ctx.currentTime); // Safe volume
      
      oscillator.connect(gainNode);
      gainNode.connect(ctx.destination);
      
      oscillator.start();
      
      oscillatorRef.current = oscillator;
      gainNodeRef.current = gainNode;

      // Sweep logic: 600Hz to 1200Hz every 0.5s
      let goingUp = true;
      sweepIntervalRef.current = setInterval(() => {
        const freq = goingUp ? 1200 : 600;
        if (oscillatorRef.current && audioCtxRef.current) {
          oscillatorRef.current.frequency.exponentialRampToValueAtTime(freq, audioCtxRef.current.currentTime + 0.5);
        }
        goingUp = !goingUp;
      }, 500);

      console.log('Siren started');
    } catch (err) {
      console.error('Failed to start siren:', err);
    }
  };

  const stopSiren = () => {
    if (oscillatorRef.current) {
      try {
        oscillatorRef.current.stop();
        oscillatorRef.current.disconnect();
      } catch (e) {}
      oscillatorRef.current = null;
    }
    if (gainNodeRef.current) {
      gainNodeRef.current.disconnect();
      gainNodeRef.current = null;
    }
    if (sweepIntervalRef.current) {
      clearInterval(sweepIntervalRef.current);
      sweepIntervalRef.current = null;
    }
    if (audioCtxRef.current) {
      audioCtxRef.current.close();
      audioCtxRef.current = null;
    }
    console.log('Siren stopped');
  };

  const toggleMute = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    if (nextMuted) {
      stopSiren();
    } else {
      startSiren();
    }
  };

  // 2. Countdown loop
  useEffect(() => {
    // Try to start siren on mount (might be blocked until first interaction)
    startSiren();

    timerRef.current = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) return 0;
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      stopMediaTracks();
      stopSiren();
    };
  }, []);

  // 3. SOS Trigger Observer
  useEffect(() => {
    if (countdown === 0 && !alertActive) {
      if (timerRef.current) clearInterval(timerRef.current);
      triggerEmergencySos();
    }
  }, [countdown, alertActive]);

  // Check Flashlight compatibility via mediaStream track capabilities
  const checkFlashlightSupport = async () => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return;
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' }
      });
      setMediaStream(stream);
      const track = stream.getVideoTracks()[0];
      const capabilities: any = track.getCapabilities ? track.getCapabilities() : {};
      
      if (capabilities.torch) {
        setHasTorch(true);
      } else {
        // If not supported, we stop the camera track to save power
        track.stop();
      }
    } catch (e) {
      console.log("Torch access not supported in this client environment.", e);
    }
  };

  const stopMediaTracks = () => {
    if (mediaStream) {
      mediaStream.getTracks().forEach(track => track.stop());
    }
  };

  // Toggle Torch
  const toggleFlashlight = async () => {
    if (!mediaStream) return;
    try {
      const track = mediaStream.getVideoTracks()[0];
      const nextTorch = !torchOn;
      await track.applyConstraints({
        advanced: [{ torch: nextTorch } as any]
      });
      setTorchOn(nextTorch);
    } catch (err) {
      console.error("Failed to toggle flashlight:", err);
    }
  };

  // Trigger Emergency SOS instantly
  const handleTriggerNow = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    setCountdown(0);
    // User interaction here guarantees AudioContext can start
    startSiren();
    // triggerEmergencySos will be called by the observer useEffect
  };

  // Core SOS triggering logic (creates log, record evidence, vibration, SMS/WhatsApp triggers)
  const triggerEmergencySos = async () => {
    if (!currentUser) return;
    console.log("SOS TRIGGER: Starting emergency sequence...");
    setStatusText('DISPATCHING EMERGENCY ALERTS...');
    setAlertActive(true);
    await updateSafety('danger');

    // 1. Device Vibration
    if ('vibrate' in navigator) {
      navigator.vibrate([300, 100, 300, 100, 300, 100, 500]);
    }

    // 2. Record 8-seconds audio evidence
    startAudioRecording();

    // 3. Write Alert document to Firestore
    const currentLat = currentLocation?.lat || 0;
    const currentLng = currentLocation?.lng || 0;
    
    try {
      console.log("SOS TRIGGER: Fetching location...", currentLat, currentLng);
      const alertId = await createAlert(
        currentUser.uid,
        'sos',
        currentLat,
        currentLng,
        userProfile?.displayName || 'SheShield User',
        '',
        contacts
      );

      setActiveAlertId(alertId);
      // Save alert ID to window ref for background audio hook
      (window as any).currentActiveAlertId = alertId;

      // 4. Construct SOS message
      const mapsUrl = `https://www.google.com/maps?q=${currentLat},${currentLng}`;
      const now = new Date().toLocaleTimeString();
      const message = `🚨 EMERGENCY ALERT from ${userProfile?.displayName || 'me'} via SheShield AI. I may be in danger. My last known location: ${mapsUrl} — Sent at ${now}.`;

      console.log("SOS TRIGGER: Message built:", message);

      // 5. Notify Guardians
      if (contacts.length === 0) {
        console.log("SOS TRIGGER: No guardians found.");
        setStatusText('No trusted guardians found — log recorded to system.');
      } else {
        console.log(`SOS TRIGGER: Alerting ${contacts.length} guardians...`);
        const initialStatus: {[key: string]: 'pending' | 'success' | 'failed'} = {};
        contacts.forEach(c => initialStatus[c.id] = 'pending');
        setNotifiedGuardians(initialStatus);

        // 1. Send Email Notifications via Backend
        try {
          await fetch('/api/send-emergency-notification', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ contacts, message }),
          });
          console.log("SOS TRIGGER: Email notifications sent.");
        } catch (err) {
          console.error("SOS TRIGGER: Email notification error:", err);
        }

        // 2. Attempt to open WhatsApp links
        contacts.forEach((contact, index) => {
          setTimeout(() => {
            const phoneNumber = contact.phone.replace(/\D/g, '');
            // Default to India (91) if no country code provided
            const formattedPhone = phoneNumber.length === 10 ? `91${phoneNumber}` : phoneNumber;
            
            let url = '';
            if (phoneNumber) {
              url = `https://wa.me/${formattedPhone}?text=${encodeURIComponent(message)}`;
            }

            if (url) {
              // Only try automatic open for the first contact to avoid popup blockers
              if (index === 0) {
                console.log(`SOS TRIGGER: Opening auto-tab for ${contact.name}`);
                window.open(url, '_blank');
              }
              setNotifiedGuardians(prev => ({ ...prev, [contact.id]: 'success' }));
            } else {
              setNotifiedGuardians(prev => ({ ...prev, [contact.id]: 'failed' }));
            }
          }, index * 200); // Slight stagger
        });

        setStatusText(`SOS Broadcaster: Notifying ${contacts.length} guardians...`);
      }
    } catch (err: any) {
      console.error("SOS Trigger Error:", err);
      setStatusText('Network delayed. Dispatching backup links...');
    }
  };

  const handleNotifyManually = (contact: EmergencyContact) => {
    const currentLat = currentLocation?.lat || 0;
    const currentLng = currentLocation?.lng || 0;
    const mapsUrl = `https://www.google.com/maps?q=${currentLat},${currentLng}`;
    const now = new Date().toLocaleTimeString();
    const message = `🚨 EMERGENCY ALERT from ${userProfile?.displayName || 'me'} via SheShield AI. I may be in danger. My last known location: ${mapsUrl} — Sent at ${now}.`;

    const phoneNumber = contact.phone.replace(/\D/g, '');
    const formattedPhone = phoneNumber.length === 10 ? `91${phoneNumber}` : phoneNumber;
    
    let url = '';
    if (phoneNumber) {
      url = `https://wa.me/${formattedPhone}?text=${encodeURIComponent(message)}`;
    }

    if (url) {
      window.open(url, '_blank');
    }
  };

  // Start MediaRecorder audio capture
  const startAudioRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];
      setIsRecording(true);

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          audioChunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = async () => {
        setIsRecording(false);
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        
        // Stop all audio stream tracks
        stream.getTracks().forEach(t => t.stop());

        // Upload evidence to Firebase Storage
        const alertId = (window as any).currentActiveAlertId;
        if (alertId && currentUser) {
          try {
            setStatusText('Uploading audio evidence secure file...');
            const url = await uploadEvidence(currentUser.uid, audioBlob, 'webm');
            await attachEvidenceToAlert(alertId, url);
            setStatusText('Audio evidence securely recorded and attached.');
          } catch (err) {
            console.error("Failed to upload SOS audio evidence:", err);
          }
        }
      };

      // Start recording
      mediaRecorder.start();

      // Automatically stop recording after 8 seconds
      setTimeout(() => {
        if (mediaRecorder.state !== 'inactive') {
          mediaRecorder.stop();
        }
      }, 8000);

    } catch (err) {
      console.error("MediaRecorder Audio input failed:", err);
    }
  };

  // Abort Emergency Countdown
  const handleAbort = async () => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    stopMediaTracks();
    setIsMuted(true);
    stopSiren();

    if (activeAlertId) {
      await resolveAlert(activeAlertId);
    }

    await updateSafety('safe');
    alert('Emergency alert safely resolved. Safety state normalized.');
    navigate('/home');
  };

  return (
    <div className={`relative flex flex-col justify-between min-h-screen px-6 py-12 text-center transition-all duration-500 overflow-y-auto ${
      alertActive ? 'bg-[#1a0505] text-white' : 'bg-red-600/90 text-white'
    }`}>
      {/* Glow */}
      <div className={`absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 rounded-full blur-[110px] ${
        alertActive ? 'bg-red-900/40' : 'bg-red-500/20'
      }`} />

      {locationError && (
        <div className="absolute top-4 inset-x-6 z-20 p-3 bg-white/10 border border-white/20 rounded-2xl backdrop-blur-md text-xs font-bold text-red-200">
          {locationError}
        </div>
      )}

      {/* Title */}
      <div className="z-10 mt-4">
        <div className="flex items-center justify-center gap-4 mb-2">
          <button
            onClick={toggleMute}
            className="p-2 bg-white/10 rounded-full hover:bg-white/20 transition-colors"
            title={isMuted ? "Unmute Siren" : "Mute Siren"}
          >
            {isMuted ? <VolumeX className="w-5 h-5 text-red-200" /> : <Volume2 className="w-5 h-5 text-white" />}
          </button>
        </div>
        <h2 className="text-3xl font-extrabold font-display tracking-wide uppercase">
          {alertActive ? "SOS BROADCASTER ACTIVE" : "ARE YOU SAFE?"}
        </h2>
        <p className="text-xs font-semibold text-red-100 uppercase tracking-widest mt-1.5 font-mono max-w-xs mx-auto">
          {statusText}
        </p>
      </div>

      {/* Main Content Area */}
      <div className="flex flex-col items-center z-10 my-8 gap-8">
        {alertActive ? (
          <div className="w-full max-w-sm flex flex-col gap-6">
            {/* Pulsing Alert Icon */}
            <div className="relative flex items-center justify-center h-32">
              <div className="absolute w-44 h-44 bg-red-500/20 rounded-full animate-ping" />
              <div className="absolute w-32 h-32 bg-red-500/30 rounded-full animate-pulse" />
              <div className="relative w-20 h-20 bg-white text-red-600 rounded-full flex items-center justify-center shadow-2xl">
                <ShieldAlert className="w-10 h-10" />
              </div>
            </div>

            {/* Guardian Notification Checklist */}
            {contacts.length > 0 && (
              <div className="bg-white/5 border border-white/10 rounded-[28px] p-5 flex flex-col gap-4 text-left">
                <div className="flex items-center justify-between px-1">
                  <h3 className="text-[10px] font-bold text-white/40 uppercase tracking-[0.2em]">Guardian Notifications</h3>
                  <span className="text-[10px] font-bold text-red-400 uppercase tracking-widest">
                    {Object.values(notifiedGuardians).filter(s => s === 'success').length} / {contacts.length} Sent
                  </span>
                </div>
                
                <div className="flex flex-col gap-3">
                  {contacts.map((contact) => (
                    <div key={contact.id} className="flex items-center justify-between p-3 bg-white/5 rounded-2xl border border-white/5">
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-xl ${
                          notifiedGuardians[contact.id] === 'success' ? 'bg-green-500/20 text-green-400' : 'bg-white/10 text-white/40'
                        }`}>
                          {notifiedGuardians[contact.id] === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <CircleDashed className="w-4 h-4 animate-spin-slow" />}
                        </div>
                        <div className="flex flex-col">
                          <span className="text-xs font-bold text-white">{contact.name}</span>
                          <span className="text-[10px] text-white/40">{contact.phone}</span>
                        </div>
                      </div>
                      
                      <button 
                        onClick={() => handleNotifyManually(contact)}
                        className="p-2 bg-white/5 hover:bg-white/10 rounded-lg text-white/60 transition"
                        title="Re-send notification"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>

                <p className="text-[9px] text-white/30 text-center leading-relaxed italic">
                  Note: If browser blocked auto-tabs, use the <ExternalLink className="w-2 h-2 inline" /> icons above to manually send alerts.
                </p>
              </div>
            )}

            {/* Map Placeholder or Evidence Status */}
            <div className="bg-red-500/10 border border-red-500/20 rounded-2xl p-3 flex items-center gap-3">
              <div className="w-10 h-10 bg-red-500/20 rounded-xl flex items-center justify-center text-red-400">
                <Mic className={`w-5 h-5 ${isRecording ? 'animate-pulse' : ''}`} />
              </div>
              <div className="flex flex-col text-left">
                <span className="text-[10px] font-bold text-red-400 uppercase tracking-tight">Audio Evidence</span>
                <span className="text-[11px] text-white/70">
                  {isRecording ? "Recording active environment..." : "Audio securely stored with alert log."}
                </span>
              </div>
            </div>
          </div>
        ) : (
          <div className="relative w-40 h-40 bg-white/10 rounded-full border border-white/20 flex flex-col items-center justify-center shadow-inner">
            <span className="text-6xl font-extrabold font-mono text-white tracking-tighter">
              {countdown}
            </span>
            <span className="text-[10px] font-bold text-red-200 tracking-wider uppercase font-sans mt-1">
              seconds remaining
            </span>
          </div>
        )}
      </div>

      {/* Bottom Action buttons */}
      <div className="flex flex-col gap-4 z-10 w-full max-w-sm mx-auto">
        {!alertActive && (
          <button
            onClick={handleTriggerNow}
            className="w-full h-13 rounded-2xl bg-white text-red-600 hover:bg-red-50 font-extrabold text-sm uppercase tracking-wider font-sans flex items-center justify-center gap-2 shadow-2xl active:scale-[0.99] transition"
          >
            <ShieldAlert className="w-4.5 h-4.5 fill-red-600" />
            <span>Send SOS Instantly</span>
          </button>
        )}

        {/* Abort/Safe button */}
        <button
          onClick={handleAbort}
          className={`w-full h-13 rounded-2xl font-bold text-sm uppercase tracking-wider font-sans flex items-center justify-center gap-2 transition shadow-xl ${
            alertActive 
            ? 'bg-green-600 hover:bg-green-500 text-white border-green-400/30' 
            : 'bg-black/30 hover:bg-black/45 border border-white/20 text-white'
          }`}
        >
          <ShieldCheck className="w-4.5 h-4.5" />
          <span>{alertActive ? "I am Safe (Resolve Alert)" : "I am Safe (Abort)"}</span>
        </button>

        {/* Flashlight/Torch Toggle if supported */}
        {hasTorch && (
          <button
            onClick={toggleFlashlight}
            className={`w-12 h-12 rounded-full mx-auto flex items-center justify-center transition border ${
              torchOn ? 'bg-yellow-500 text-black border-yellow-400' : 'bg-black/25 text-white border-white/10'
            }`}
          >
            <Zap className={`w-5 h-5 ${torchOn ? 'fill-black' : ''}`} />
          </button>
        )}
      </div>
    </div>
  );
};
