import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getUserAlerts, Alert } from '../services/alerts';
import { Bell, ShieldAlert, CheckCircle, Clock, Volume2, VolumeX, MapPin, RefreshCw, Eye, ArrowLeft } from 'lucide-react';

export const Notifications: React.FC = () => {
  const { currentUser } = useAuth();
  const navigate = useNavigate();

  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!currentUser) return;
    getUserAlerts(currentUser.uid)
      .then((data) => {
        setAlerts(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  }, [currentUser]);

  return (
    <div className="flex flex-col gap-5 py-2 pb-12">
      {/* Title */}
      <div className="flex flex-col mt-1">
        <div className="flex items-center gap-3 mb-2">
          <button 
            onClick={() => navigate(-1)} 
            className="w-8 h-8 flex items-center justify-center rounded-full glass border border-white/10 hover:bg-white/5 transition active:scale-95 shrink-0"
          >
            <ArrowLeft className="w-4 h-4 text-white" />
          </button>
          <h2 className="text-xl font-bold font-display text-white">Emergency Dispatch Logs</h2>
        </div>
        <p className="text-xs text-gray-400 font-sans mt-0.5 pl-11">
          Review history logs of active visual alarms and silent alerts triggered from this device.
        </p>
      </div>

      {/* List content */}
      <div className="flex flex-col gap-3">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-12 gap-2">
            <RefreshCw className="w-5 h-5 text-brand-pink animate-spin" />
            <span className="text-xs text-gray-400">Loading safety log history...</span>
          </div>
        ) : alerts.length > 0 ? (
          alerts.map((alertItem) => (
            <div
              key={alertItem.id}
              className="glass p-4 rounded-[20px] flex flex-col gap-3 border border-purple-500/10"
            >
              {/* Top row */}
              <div className="flex justify-between items-start">
                <div className="flex gap-2.5 items-center">
                  <div className={`p-2 rounded-xl border ${
                    alertItem.type === 'sos'
                      ? 'bg-red-500/10 text-red-400 border-red-500/20'
                      : 'bg-slate-500/10 text-slate-400 border-slate-500/20'
                  }`}>
                    {alertItem.type === 'sos' ? <Volume2 className="w-4 h-4 animate-bounce" /> : <VolumeX className="w-4 h-4" />}
                  </div>
                  <div className="flex flex-col">
                    <span className="text-sm font-bold text-white font-display">
                      {alertItem.type === 'sos' ? 'Visual Alarm Triggered' : 'Silent Emergency alert'}
                    </span>
                    <span className="text-[10px] text-gray-400 font-sans flex items-center gap-1 mt-0.5">
                      <Clock className="w-3 h-3" />
                      {new Date(alertItem.timestamp).toLocaleString()}
                    </span>
                  </div>
                </div>

                <span className={`text-[9px] font-bold font-sans px-2 py-0.5 rounded-full border ${
                  alertItem.status === 'active'
                    ? 'bg-red-500/10 text-red-400 border-red-500/25 animate-pulse'
                    : 'bg-green-500/10 text-green-400 border-green-500/25'
                }`}>
                  {alertItem.status.toUpperCase()}
                </span>
              </div>

              {/* Coordinates row */}
              <div className="p-3 bg-white/[0.02] border border-purple-500/5 rounded-xl flex items-center justify-between text-xs font-mono text-gray-300">
                <span className="flex items-center gap-1.5 font-sans text-gray-400">
                  <MapPin className="w-3.5 h-3.5 text-brand-pink shrink-0" />
                  Coordinates
                </span>
                <span>{alertItem.location.lat.toFixed(6)}, {alertItem.location.lng.toFixed(6)}</span>
              </div>

              {/* Evidence Media link if available */}
              {alertItem.evidenceUrl && (
                <a
                  href={alertItem.evidenceUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="h-9 rounded-xl bg-brand-purple/10 border border-brand-purple/20 text-[11px] font-semibold text-white font-sans flex items-center justify-center gap-1.5 transition hover:bg-brand-purple/20"
                >
                  <Eye className="w-3.5 h-3.5 text-brand-pink" />
                  <span>Listen to Secure Audio Evidence</span>
                </a>
              )}
            </div>
          ))
        ) : (
          <div className="text-center p-10 glass rounded-[20px] border border-dashed border-purple-500/10">
            <CheckCircle className="w-8 h-8 text-green-400 mx-auto mb-3" />
            <p className="text-xs text-gray-400 font-sans">
              Clean history slate! No emergency alert dispatch records found.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
