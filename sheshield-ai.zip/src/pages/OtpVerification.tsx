// DEMO OTP: code is generated and shown client-side for demonstration purposes. In production this would be sent via a verified email/SMS provider and validated server-side.

import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { generateOtp, verifyOtp, resendOtp } from '../services/otp';
import { ShieldAlert, AlertCircle, CheckCircle2, ArrowRight, RefreshCw, X, ArrowLeft } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const OtpVerification: React.FC = () => {
  const { currentUser, loading: authLoading } = useAuth();
  const navigate = useNavigate();

  const [otp, setOtp] = useState<string[]>(Array(6).fill(''));
  const [generatedCode, setGeneratedCode] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [isVerifying, setIsVerifying] = useState<boolean>(false);
  const [isSuccess, setIsSuccess] = useState<boolean>(false);
  const [cooldown, setCooldown] = useState<number>(30);
  const [showDevBanner, setShowDevBanner] = useState<boolean>(true);
  const [isResending, setIsResending] = useState<boolean>(false);

  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Timer for resend cooldown
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (cooldown > 0) {
      timer = setInterval(() => {
        setCooldown((prev) => prev - 1);
      }, 1000);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [cooldown]);

  // Initial OTP generation
  useEffect(() => {
    if (authLoading) return;

    if (!currentUser) {
      // If there is no user, send them back to registration
      navigate('/register', { replace: true });
      return;
    }

    const initOtp = async () => {
      try {
        const code = await generateOtp(currentUser.uid, currentUser.email || '');
        setGeneratedCode(code);
      } catch (err: any) {
        console.error('Error generating OTP:', err);
        setError('Failed to generate verification code.');
      }
    };

    initOtp();
  }, [currentUser, authLoading, navigate]);

  // Autofocus first input box
  useEffect(() => {
    if (inputRefs.current[0]) {
      inputRefs.current[0].focus();
    }
  }, []);

  const handleChange = (value: string, index: number) => {
    // Only allow numbers
    if (value && !/^\d+$/.test(value)) return;

    const newOtp = [...otp];
    // Keep only the last character if typed
    newOtp[index] = value.substring(value.length - 1);
    setOtp(newOtp);
    setError('');

    // If typed a digit, move to next box
    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, index: number) => {
    if (e.key === 'Backspace') {
      if (!otp[index] && index > 0) {
        // If box is empty and backspace pressed, clear and focus previous box
        const newOtp = [...otp];
        newOtp[index - 1] = '';
        setOtp(newOtp);
        inputRefs.current[index - 1]?.focus();
      } else {
        // Clear current box
        const newOtp = [...otp];
        newOtp[index] = '';
        setOtp(newOtp);
      }
    }
  };

  const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData('text').trim();
    if (!/^\d{6}$/.test(pastedData)) {
      setError('Please paste a valid 6-digit verification code.');
      return;
    }

    const digits = pastedData.split('');
    setOtp(digits);
    setError('');

    // Focus last box
    inputRefs.current[5]?.focus();
  };

  const handleVerify = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const enteredCode = otp.join('');
    if (enteredCode.length < 6) {
      setError('Please enter all 6 digits of the code.');
      return;
    }

    setIsVerifying(true);
    setError('');

    try {
      if (!currentUser) throw new Error('User session not found.');
      
      const isValid = await verifyOtp(currentUser.uid, enteredCode);
      if (isValid) {
        setIsSuccess(true);
        localStorage.removeItem('otp_pending');
        
        // Wait for checkmark animation, then navigate
        setTimeout(() => {
          navigate('/home', { replace: true });
        }, 1500);
      } else {
        setError('Incorrect code. Please try again.');
        // Trigger simple shake / reset
        setOtp(Array(6).fill(''));
        inputRefs.current[0]?.focus();
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Verification failed. Please try again.');
    } finally {
      setIsVerifying(false);
    }
  };

  const handleResend = async () => {
    if (cooldown > 0 || isResending) return;
    setIsResending(true);
    setError('');
    setOtp(Array(6).fill(''));

    try {
      if (!currentUser) throw new Error('User session not found.');
      const code = await resendOtp(currentUser.uid, currentUser.email || '');
      setGeneratedCode(code);
      setCooldown(30);
      setShowDevBanner(true);
      // Focus first box
      inputRefs.current[0]?.focus();
    } catch (err: any) {
      console.error(err);
      setError('Failed to resend code. Please try again.');
    } finally {
      setIsResending(false);
    }
  };

  // Shake animation variant
  const shakeVariants = {
    shake: {
      x: [0, -10, 10, -10, 10, -5, 5, 0],
      transition: { duration: 0.5 }
    }
  };

  if (authLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-[#0B0617]">
        <div className="relative flex items-center justify-center w-20 h-20">
          <div className="absolute w-16 h-16 border-4 border-brand-purple border-t-transparent rounded-full animate-spin" />
          <div className="absolute w-10 h-10 border-4 border-brand-pink border-b-transparent rounded-full animate-spin [animation-direction:reverse]" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col justify-center min-h-screen bg-[#0B0617] px-6 py-12 relative overflow-hidden">
      {/* Background ambient glow circles */}
      <div className="absolute top-[-100px] right-[-100px] w-[500px] h-[500px] bg-[#7C3AED]/20 rounded-full blur-[120px] pointer-events-none z-0" />
      <div className="absolute bottom-[-100px] left-[-100px] w-[500px] h-[500px] bg-[#EC4899]/15 rounded-full blur-[120px] pointer-events-none z-0" />

      {/* Back Button */}
      <button 
        onClick={() => navigate(-1)} 
        className="absolute top-8 left-6 z-20 w-10 h-10 flex items-center justify-center rounded-full glass border border-white/10 hover:bg-white/5 transition active:scale-95"
      >
        <ArrowLeft className="w-5 h-5 text-white" />
      </button>

      <div className="w-full max-w-md mx-auto z-10">
        {/* Header Branding */}
        <div className="flex flex-col items-center text-center mb-8">
          <div className="w-12 h-12 bg-gradient-to-tr from-brand-purple to-brand-pink rounded-xl flex items-center justify-center shadow-lg border border-white/5 mb-3">
            <ShieldAlert className="w-6 h-6 text-white" />
          </div>
          <h2 className="text-2xl font-bold font-display text-white">Security Verification</h2>
          <p className="text-xs text-brand-lavender font-mono mt-1 uppercase tracking-wider">
            One-Time Password
          </p>
        </div>

        {/* Success Card or OTP form */}
        <AnimatePresence mode="wait">
          {isSuccess ? (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="glass rounded-2xl p-8 border border-emerald-500/30 flex flex-col items-center text-center shadow-2xl"
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: 'spring', stiffness: 200, damping: 15 }}
                className="w-16 h-16 bg-emerald-500/10 rounded-full border border-emerald-500/30 flex items-center justify-center mb-4"
              >
                <CheckCircle2 className="w-10 h-10 text-emerald-400" />
              </motion.div>
              <h3 className="text-lg font-bold text-white mb-2">Verified Successfully</h3>
              <p className="text-sm text-gray-400 mb-6">
                Your identity has been verified. Welcome to SheShield AI.
              </p>
              <div className="flex items-center gap-2 text-brand-pink font-semibold text-sm animate-pulse">
                <span>Entering Dashboard</span>
                <ArrowRight className="w-4 h-4" />
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="otp-form"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              className="glass rounded-2xl p-6 md:p-8 border border-white/5 shadow-2xl flex flex-col gap-6"
            >
              <div className="text-center">
                <p className="text-sm text-gray-300 leading-relaxed font-sans">
                  We've sent a 6-digit verification code to your registered email address:
                </p>
                <p className="text-sm text-brand-pink font-semibold mt-1 font-mono break-all select-all">
                  {currentUser?.email}
                </p>
              </div>

              {/* DEV MODE OTP Display Banner */}
              {showDevBanner && generatedCode && (
                <div className="bg-brand-purple/10 border-2 border-dashed border-brand-purple/30 rounded-xl p-4 flex items-start gap-3 relative overflow-hidden transition-all">
                  <div className="bg-brand-purple/20 p-2 rounded-lg text-brand-pink">
                    <ShieldAlert className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <span className="text-[10px] font-bold text-brand-lavender tracking-wider uppercase font-mono block">
                      DEV MODE — Simulated OTP helper
                    </span>
                    <p className="text-sm text-white font-sans mt-0.5">
                      Your verification OTP is:{' '}
                      <strong className="text-brand-pink font-mono text-base tracking-widest bg-brand-purple/30 px-2 py-0.5 rounded ml-1">
                        {generatedCode}
                      </strong>
                    </p>
                  </div>
                  <button
                    onClick={() => setShowDevBanner(false)}
                    className="absolute top-2 right-2 p-1 text-gray-500 hover:text-white transition rounded-md"
                    aria-label="Dismiss banner"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}

              {/* Error Alert */}
              {error && (
                <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-3 flex items-start gap-3 text-red-400 text-xs">
                  <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                  <span className="font-sans font-medium">{error}</span>
                </div>
              )}

              {/* OTP Input Boxes */}
              <form onSubmit={handleVerify} className="flex flex-col gap-6">
                <motion.div 
                  className="flex justify-between gap-2"
                  animate={error ? 'shake' : ''}
                  variants={shakeVariants}
                >
                  {otp.map((digit, index) => (
                    <input
                      key={index}
                      ref={(el) => {
                        inputRefs.current[index] = el;
                      }}
                      type="text"
                      inputMode="numeric"
                      pattern="[0-9]*"
                      maxLength={1}
                      value={digit}
                      onChange={(e) => handleChange(e.target.value, index)}
                      onKeyDown={(e) => handleKeyDown(e, index)}
                      onPaste={handlePaste}
                      className="w-11 h-12 md:w-12 md:h-14 rounded-xl bg-white/5 border border-white/10 focus:border-brand-pink/50 focus:outline-none text-center text-lg md:text-xl font-bold font-mono text-white transition focus:bg-brand-purple/5"
                    />
                  ))}
                </motion.div>

                <button
                  type="submit"
                  disabled={isVerifying || otp.some((d) => !d)}
                  className="w-full h-11 rounded-xl bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-purple hover:to-brand-lavender text-white font-semibold text-sm font-sans flex items-center justify-center shadow-lg shadow-brand-purple/10 transition hover:scale-[1.01] disabled:opacity-40 disabled:scale-100 cursor-pointer"
                >
                  {isVerifying ? (
                    <div className="flex items-center gap-2">
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Verifying Code...</span>
                    </div>
                  ) : (
                    'Verify Code'
                  )}
                </button>
              </form>

              {/* Resend Actions */}
              <div className="flex flex-col items-center gap-2 mt-2">
                {cooldown > 0 ? (
                  <p className="text-xs text-gray-500 font-mono">
                    Resend code in <strong className="text-brand-pink">{cooldown}s</strong>
                  </p>
                ) : (
                  <button
                    onClick={handleResend}
                    disabled={isResending}
                    className="flex items-center gap-1.5 text-xs text-brand-pink hover:text-brand-lavender font-bold transition focus:outline-none group disabled:opacity-50 cursor-pointer"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isResending ? 'animate-spin' : 'group-hover:rotate-180 transition-transform duration-500'}`} />
                    <span>Resend verification code</span>
                  </button>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Back to Login */}
        <p className="text-center text-xs text-gray-500 mt-8 font-sans">
          Need to change email or sign in differently?{' '}
          <button
            onClick={() => navigate('/login', { replace: true })}
            className="text-brand-pink hover:text-brand-lavender font-bold transition focus:outline-none bg-transparent border-none cursor-pointer"
          >
            Go Back
          </button>
        </p>
      </div>
    </div>
  );
};
