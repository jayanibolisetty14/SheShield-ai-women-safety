import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { addContact, removeContact, subscribeContacts, EmergencyContact } from '../services/contacts';
import { UserCheck, Plus, Trash2, Phone, ShieldAlert, Heart, RefreshCw, AlertCircle, ArrowLeft } from 'lucide-react';

export const EmergencyContacts: React.FC = () => {
  const { currentUser } = useAuth();
  const navigate = useNavigate();

  const [contacts, setContacts] = useState<EmergencyContact[]>([]);
  const [loading, setLoading] = useState(true);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  // Form Fields
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [relation, setRelation] = useState('');
  const [adding, setAdding] = useState(false);
  const [error, setError] = useState('');

  // Subscribe to real-time updates
  useEffect(() => {
    if (!currentUser) return;

    setLoading(true);
    const unsubscribe = subscribeContacts(currentUser.uid, (list) => {
      setContacts(list);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [currentUser]);

  // Handle Add Contact Submit
  const handleAddContact = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    if (!name || !phone || !email || !relation) {
      setError('Please fill in all contact inputs.');
      return;
    }

    setError('');
    setAdding(true);
    try {
      await addContact(currentUser.uid, name, phone, email, relation);
      // Reset form
      setName('');
      setPhone('');
      setEmail('');
      setRelation('');
      alert('Guardian successfully enrolled!');
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Error writing contact.');
    } finally {
      setAdding(false);
    }
  };

  // Handle Delete Contact
  const handleDeleteContact = async (id: string) => {
    if (!currentUser) {
      console.error("Delete failed: No current user");
      alert("Please log in to delete contacts.");
      return;
    }
    
    const confirmDelete = window.confirm('Are you sure you want to remove this guardian?');
    if (!confirmDelete) return;

    setDeletingId(id);
    try {
      console.log("Attempting to delete contact:", id);
      await removeContact(currentUser.uid, id);
      
      // Update local state immediately for faster UI feedback
      setContacts(prev => prev.filter(c => c.id !== id));
      
      console.log("Delete successful for:", id);
      alert('Guardian removed successfully.');
    } catch (err: any) {
      console.error("Delete error:", err);
      alert("Couldn't remove guardian: " + (err.message || "Please try again."));
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <div className="flex flex-col gap-5 py-2 pb-12">
      {/* Title */}
      <div className="flex flex-col mt-1">
        <div className="flex items-center gap-3 mb-2">
          <button 
            onClick={() => navigate(-1)} 
            className="w-8 h-8 flex items-center justify-center rounded-full glass border border-white/10 hover:bg-white/5 transition active:scale-95 shrink-0"
          >
            <ArrowLeft className="w-4 h-4 text-white" />
          </button>
          <h2 className="text-xl font-bold font-display text-white">Trusted Guardians</h2>
        </div>
        <p className="text-xs text-gray-400 font-sans mt-0.5 pl-11">
          Enlist trusted contacts who will be notified instantly during emergency alerts.
        </p>
      </div>

      {/* 1. Add Guardian Form */}
      <div className="glass p-5 rounded-[24px]">
        <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 flex items-center gap-2 mb-4">
          <Plus className="w-4 h-4 text-brand-pink" />
          Add Trusted Guardian
        </h3>

        {error && (
          <div className="p-3.5 bg-red-500/10 border border-red-500/20 rounded-xl flex items-start gap-2 text-xs text-red-400 mb-4">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleAddContact} className="flex flex-col gap-4">
          <div className="grid grid-cols-2 gap-3">
            {/* Full Name */}
            <div className="flex flex-col gap-1.5">
              <label className="text-[10px] font-bold text-white/50 uppercase tracking-wider pl-1">Full Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Jane Doe"
                required
                className="h-11 px-4 rounded-xl bg-white/5 border border-white/10 focus:border-brand-pink/60 focus:outline-none text-xs text-white transition-all duration-300 placeholder-white/20"
              />
            </div>

            {/* Relation */}
            <div className="flex flex-col gap-1.5">
              <label className="text-[10px] font-bold text-white/50 uppercase tracking-wider pl-1">Relation</label>
              <input
                type="text"
                value={relation}
                onChange={(e) => setRelation(e.target.value)}
                placeholder="Sister, Friend..."
                required
                className="h-11 px-4 rounded-xl bg-white/5 border border-white/10 focus:border-brand-pink/60 focus:outline-none text-xs text-white transition-all duration-300 placeholder-white/20"
              />
            </div>
          </div>

          {/* Phone Number */}
          <div className="flex flex-col gap-1.5">
            <label className="text-[10px] font-bold text-white/50 uppercase tracking-wider pl-1">Mobile Phone Number</label>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="+91 XXXXX XXXXX"
              required
              className="h-11 px-4 rounded-xl bg-white/5 border border-white/10 focus:border-brand-pink/60 focus:outline-none text-xs text-white font-mono transition-all duration-300 placeholder-white/20"
            />
          </div>

          {/* Email Address */}
          <div className="flex flex-col gap-1.5">
            <label className="text-[10px] font-bold text-white/50 uppercase tracking-wider pl-1">Email Address</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="jane@example.com"
              required
              className="h-11 px-4 rounded-xl bg-white/5 border border-white/10 focus:border-brand-pink/60 focus:outline-none text-xs text-white font-mono transition-all duration-300 placeholder-white/20"
            />
          </div>

          <button
            type="submit"
            disabled={adding}
            className="w-full h-11 mt-1 rounded-xl bg-gradient-to-r from-brand-purple to-brand-pink text-white font-semibold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 shadow-md shadow-brand-purple/20 hover:scale-[1.01] active:scale-[0.99] transition duration-300 cursor-pointer"
          >
            {adding ? 'Enrolling Guardian...' : 'Save Guardian'}
          </button>
        </form>
      </div>

      {/* 2. Guardian List */}
      <div className="flex flex-col gap-3">
        <h3 className="text-xs font-bold font-mono text-gray-400 uppercase tracking-widest pl-1">
          Enrolled Guardians ({contacts.length})
        </h3>

        {loading ? (
          <div className="flex flex-col items-center justify-center py-10 gap-2">
            <RefreshCw className="w-5 h-5 text-brand-pink animate-spin" />
            <span className="text-xs text-gray-400">Querying security circle...</span>
          </div>
        ) : contacts.length > 0 ? (
          <div className="flex flex-col gap-3">
            {contacts.map((contact) => (
              <div
                key={contact.id}
                className="glass p-4 rounded-[20px] flex items-center justify-between border border-purple-500/10"
              >
                <div className="flex items-center gap-3">
                  <div className="relative w-10 h-10 bg-brand-pink/10 border border-brand-pink/20 text-brand-pink rounded-full flex items-center justify-center shadow-inner">
                    <UserCheck className="w-5 h-5" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-sm font-bold text-white font-display leading-none">{contact.name}</span>
                    <div className="flex items-center gap-1.5 mt-1">
                      <span className="text-[10px] font-semibold font-sans px-1.5 py-0.5 rounded-md bg-brand-purple/10 border border-brand-purple/20 text-brand-lavender uppercase">
                        {contact.relation}
                      </span>
                      <span className="text-xs text-gray-400 font-mono">{contact.phone}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {/* Phone Dial backup link */}
                  <a
                    href={`tel:${contact.phone.replace(/\D/g, '')}`}
                    className="p-2.5 bg-green-500/15 hover:bg-green-500/25 text-green-400 rounded-xl transition border border-green-500/25 relative z-10"
                  >
                    <Phone className="w-4 h-4" />
                  </a>

                  {/* Delete guardian */}
                  <button
                    onClick={() => handleDeleteContact(contact.id)}
                    disabled={deletingId === contact.id}
                    className={`p-2.5 rounded-xl transition border relative z-10 ${
                      deletingId === contact.id
                        ? 'bg-red-500/10 border-red-500/10 text-red-400/50 cursor-not-allowed'
                        : 'bg-red-500/15 hover:bg-red-500/25 text-red-400 border-red-500/25'
                    }`}
                  >
                    {deletingId === contact.id ? (
                      <RefreshCw className="w-4 h-4 animate-spin" />
                    ) : (
                      <Trash2 className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center p-8 glass rounded-[20px] border border-dashed border-purple-500/15">
            <ShieldAlert className="w-8 h-8 text-brand-pink mx-auto mb-3" />
            <p className="text-xs text-gray-400 font-sans">
              No contacts saved yet. Please enroll at least one guardian above to ensure they receive SMS/WhatsApp coordinates during alarms!
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
