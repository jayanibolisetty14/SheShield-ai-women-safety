import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Scale, ShieldCheck, ChevronDown, ChevronUp, Languages, Mic, MicOff, Volume2, VolumeX, ArrowLeft } from 'lucide-react';
import { FloatingBot } from '../components/FloatingBot';
import { OfflineBanner } from '../components/OfflineBanner';
import { LANGUAGES, translations, LanguageCode } from '../i18n/translations';
import { useSpeech } from '../hooks/useSpeech';
import { motion, AnimatePresence } from 'motion/react';

export const LegalGuide: React.FC = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);
  const [selectedLanguageCode, setSelectedLanguageCode] = useState<LanguageCode>(() => (localStorage.getItem('lang') as LanguageCode) || 'en');
  const [showLanguageMenu, setShowLanguageMenu] = useState(false);

  useEffect(() => {
    localStorage.setItem('lang', selectedLanguageCode);
  }, [selectedLanguageCode]);

  const t = translations[selectedLanguageCode];
  const { isListening, isSpeaking, startListening, stopListening, speak, stopSpeaking } = useSpeech({ code: selectedLanguageCode, name: '', nativeName: '' });

  const filteredLaws = t.laws.filter(
    (law: any) =>
      law.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      law.section.toLowerCase().includes(searchQuery.toLowerCase()) ||
      law.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleExpand = (idx: number) => {
    if (isSpeaking) stopSpeaking();
    setExpandedIndex(expandedIndex === idx ? null : idx);
  };

  const handleVoiceSearch = () => {
    if (isListening) {
      stopListening();
    } else {
      startListening((text) => {
        setSearchQuery(text);
      });
    }
  };

  return (
    <div className="flex flex-col gap-5 py-2 pb-12 relative">
      {/* Page Title & Language Selector */}
      <div className="flex items-center justify-between mt-1">
        <div className="flex items-center gap-3">
          <button 
            onClick={() => navigate(-1)} 
            className="w-8 h-8 flex items-center justify-center rounded-full glass border border-white/10 hover:bg-white/5 transition active:scale-95 shrink-0"
          >
            <ArrowLeft className="w-4 h-4 text-white" />
          </button>
          <div className="flex flex-col">
            <h2 className="text-xl font-bold font-display text-white">{t.title}</h2>
            <p className="text-xs text-gray-400 font-sans mt-0.5">
              {t.subtitle}
            </p>
          </div>
        </div>
        
        <div className="relative">
          <button 
            onClick={() => setShowLanguageMenu(!showLanguageMenu)}
            className="p-2.5 bg-brand-purple/10 border border-brand-purple/20 text-brand-lavender rounded-xl hover:bg-brand-purple/20 transition flex items-center gap-2"
          >
            <Languages className="w-4.5 h-4.5" />
            <span className="text-[10px] font-bold uppercase tracking-wider">{selectedLanguageCode.toUpperCase()}</span>
          </button>

          <AnimatePresence>
            {showLanguageMenu && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="absolute top-12 right-0 z-30 glass border border-white/10 rounded-2xl p-2 w-48 shadow-2xl"
              >
                <div className="grid grid-cols-1 gap-1">
                  {LANGUAGES.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => {
                        setSelectedLanguageCode(lang.code as LanguageCode);
                        setShowLanguageMenu(false);
                      }}
                      className={`flex items-center justify-between px-3 py-2 rounded-xl text-xs transition ${
                        selectedLanguageCode === lang.code ? 'bg-brand-pink text-white' : 'hover:bg-white/5 text-white/70'
                      }`}
                    >
                      <span>{lang.name}</span>
                      <span className="opacity-50">{lang.nativeName}</span>
                    </button>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Search Input */}
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-gray-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={isListening ? "Listening..." : t.searchPlaceholder}
            className="w-full h-11 pl-10 pr-4 rounded-xl bg-brand-card/70 border border-purple-500/15 focus:border-brand-pink/50 focus:outline-none text-sm text-white placeholder-gray-500 font-sans transition"
          />
        </div>
        <button
          onClick={handleVoiceSearch}
          className={`h-11 px-3.5 rounded-xl transition border ${
            isListening 
            ? 'bg-red-500/20 border-red-500 text-red-500' 
            : 'bg-brand-card/70 border-purple-500/15 text-gray-400 hover:text-brand-pink'
          }`}
        >
          {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
        </button>
      </div>

      <OfflineBanner />

      {/* Law Catalog Cards */}
      <div className="flex flex-col gap-3">
        {filteredLaws.length > 0 ? (
          filteredLaws.map((law: any, idx: number) => {
            const isExpanded = expandedIndex === idx;

            return (
              <div
                key={idx}
                className="glass rounded-[20px] overflow-hidden transition-all duration-300 border border-purple-500/10 hover:border-purple-500/20"
              >
                {/* Expandable Header */}
                <div
                  onClick={() => toggleExpand(idx)}
                  className="p-4 flex justify-between items-start cursor-pointer select-none bg-white/[0.01]"
                >
                  <div className="flex gap-3 items-start">
                    <div className="p-2 bg-brand-purple/10 border border-brand-purple/20 text-brand-lavender rounded-xl mt-0.5 shrink-0">
                      <Scale className="w-4.5 h-4.5" />
                    </div>
                    <div className="flex flex-col">
                      <span className="text-sm font-bold text-white font-display leading-tight">{law.title}</span>
                      <span className="text-[10px] font-mono font-medium text-brand-pink uppercase tracking-wide mt-1">
                        {law.section}
                      </span>
                    </div>
                  </div>

                  <div className="text-gray-500 p-1 shrink-0">
                    {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </div>
                </div>

                {/* Expanded Details body */}
                {isExpanded && (
                  <div className="px-5 pb-5 border-t border-purple-500/5 pt-4 bg-black/10 flex flex-col gap-4 text-xs leading-relaxed text-gray-300 font-sans relative">
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        isSpeaking ? stopSpeaking() : speak(`${law.title}. ${law.description}`);
                      }}
                      className="absolute right-4 top-4 p-2 bg-white/5 rounded-full text-white/40 hover:text-brand-pink hover:bg-white/10 transition"
                    >
                      {isSpeaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                    </button>

                    <p className="pr-10">{law.description}</p>

                    {/* Provisions Section */}
                    <div>
                      <span className="font-bold text-white block mb-1.5 uppercase font-mono tracking-wider text-[10px] text-brand-pink">
                        {t.provisionsTitle}
                      </span>
                      <ul className="list-disc pl-4 flex flex-col gap-1.5">
                        {law.provisions.map((prov: string, pIdx: number) => (
                          <li key={pIdx}>{prov}</li>
                        ))}
                      </ul>
                    </div>

                    {/* Rights Section */}
                    <div className="p-3 bg-brand-purple/10 border border-brand-purple/15 rounded-xl">
                      <span className="font-bold text-white flex items-center gap-1.5 mb-1.5 uppercase font-mono tracking-wider text-[10px] text-brand-lavender">
                        <ShieldCheck className="w-3.5 h-3.5 text-brand-pink" />
                        {t.rightsTitle}
                      </span>
                      <ul className="list-disc pl-4 flex flex-col gap-1.5 text-gray-200">
                        {law.rights.map((right: string, rIdx: number) => (
                          <li key={rIdx}>{right}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        ) : (
          <div className="text-center py-10">
            <p className="text-sm text-gray-400 font-sans">{t.noResults}</p>
          </div>
        )}
      </div>
      <FloatingBot />
    </div>
  );
};
