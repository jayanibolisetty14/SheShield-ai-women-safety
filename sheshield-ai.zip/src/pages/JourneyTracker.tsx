import React, { useEffect, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { startNewJourney, updateJourneyRoute, stopJourney, updateRideDetails, Journey, RoutePoint, RideDetails } from '../services/journeys';
import { FloatingBot } from '../components/FloatingBot';
import { evaluateSafetyScore } from '../utils/safetyScore';
import { geocodeAddress } from '../utils/geocoding';
import { calculateDistance } from '../utils/distance';
import { OfflineBanner } from '../components/OfflineBanner';
import { subscribeContacts, EmergencyContact } from '../services/contacts';
import { 
  Compass, 
  Play, 
  Square, 
  Share2, 
  Copy, 
  Check, 
  MapPin, 
  ShieldCheck, 
  ShieldAlert, 
  HeartPulse, 
  Car, 
  ChevronDown, 
  ChevronUp, 
  User, 
  Phone, 
  Hash, 
  Info, 
  Edit2,
  AlertTriangle,
  Bell,
  Navigation,
  Activity,
  PhoneCall,
  Clock,
  Shield,
  Eye,
  AlertCircle,
  ArrowLeft,
  Skull
} from 'lucide-react';
import L from 'leaflet';
import { UnsafeModal } from '../components/UnsafeModal';

export const JourneyTracker: React.FC = () => {
  const { currentUser, updateSafety, currentLocation, locationError } = useAuth();
  const navigate = useNavigate();

  const [destination, setDestination] = useState('');
  const [activeJourney, setActiveJourney] = useState<Journey | null>(null);
  const [routePoints, setRoutePoints] = useState<RoutePoint[]>([]);
  const [isTracking, setIsTracking] = useState(false);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showRideDetails, setShowRideDetails] = useState(false);
  const [isEditingRide, setIsEditingRide] = useState(false);
  const [showUnsafeModal, setShowUnsafeModal] = useState(false);
  const [contacts, setContacts] = useState<EmergencyContact[]>([]);

  // Ride Details State
  const [driverName, setDriverName] = useState('');
  const [vehicleNumber, setVehicleNumber] = useState('');
  const [vehicleType, setVehicleType] = useState<'Auto' | 'Cab' | 'Bike' | 'Other'>('Cab');
  const [driverPhone, setDriverPhone] = useState('');

  // Dynamic Metrics
  const [safetyScore, setSafetyScore] = useState(100);
  const [riskLevel, setRiskLevel] = useState<'low' | 'medium' | 'high'>('low');
  const [explanation, setExplanation] = useState('Safety is normal.');
  const [eta, setEta] = useState('--');
  const [distanceRemaining, setDistanceRemaining] = useState<string>('--');
  
  // Predefined destinations for testing
  const PREDEFINED_DESTINATIONS: Record<string, { lat: number, lng: number }> = {
    'Home': { lat: 12.9716, lng: 77.5946 },
    'Work': { lat: 12.9352, lng: 77.6245 },
    'Station': { lat: 12.9784, lng: 77.6408 }
  };

  // Recalculate metrics when location or destination changes
  useEffect(() => {
    async function updateMetrics() {
      if (!currentLocation || !destination) {
        setEta('--');
        setDistanceRemaining('--');
        return;
      }

      let dest: { lat: number, lng: number } | null = PREDEFINED_DESTINATIONS[destination] || null;
      
      if (!dest) {
        dest = await geocodeAddress(destination);
      }

      if (!dest || isNaN(dest.lat) || isNaN(dest.lng)) {
        setEta('Location not found');
        setDistanceRemaining('--');
        return;
      }

      const distMeters = calculateDistance(currentLocation.lat, currentLocation.lng, dest.lat, dest.lng);
      const distKm = (distMeters / 1000).toFixed(1);
      setDistanceRemaining(`${distKm} km`);

      // Travel modes: Walking: 5 km/h, Bicycle: 15 km/h, Car: 40 km/h
      const speedKmh = 40; 
      const etaMins = Math.ceil((distMeters / 1000 / speedKmh) * 60);
      setEta(etaMins > 0 ? `${etaMins} mins` : 'Arrived');
    }

    updateMetrics();
  }, [currentLocation, destination]);


  // References for Leaflet
  const mapRef = useRef<L.Map | null>(null);
  const markerRef = useRef<L.Marker | null>(null);
  const polylineRef = useRef<L.Polyline | null>(null);
  const journeyIdRef = useRef<string | null>(null);

  // Subscribe to contacts for guardians count
  useEffect(() => {
    if (!currentUser) return;
    const unsub = subscribeContacts(currentUser.uid, (data) => {
      setContacts(data);
    });
    return () => unsub();
  }, [currentUser]);

  // Initialize Map
  useEffect(() => {
    // Only build map once container is mounted
    if (!mapRef.current) {
      const mapContainer = document.getElementById('journey-map');
      if (mapContainer) {
        // Start with a neutral view, will re-center once location is found
        mapRef.current = L.map('journey-map', {
          zoomControl: false,
          attributionControl: false
        }).setView([0, 0], 2);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          crossOrigin: true
        }).addTo(mapRef.current);

        // Pink/Purple neon path line
        polylineRef.current = L.polyline([], {
          color: '#EC4899',
          weight: 5,
          opacity: 0.8
        }).addTo(mapRef.current);

        // Marker indicator
        const customIcon = L.divIcon({
          className: 'custom-gps-icon',
          html: `<div class="relative w-6 h-6"><div class="absolute w-6 h-6 bg-brand-pink/30 rounded-full animate-ping"></div><div class="relative w-4 h-4 m-1 bg-brand-pink border-2 border-white rounded-full"></div></div>`,
          iconSize: [24, 24]
        });

        markerRef.current = L.marker([0, 0], { icon: customIcon }).addTo(mapRef.current);
      }
    }
  }, []);

  // Sync Leaflet map with current location or route points
  useEffect(() => {
    if (!mapRef.current) return;

    if (isTracking && routePoints.length > 0) {
      const latLngs = routePoints.map(p => [p.lat, p.lng] as [number, number]);
      const latest = latLngs[latLngs.length - 1];

      if (polylineRef.current) polylineRef.current.setLatLngs(latLngs);
      if (markerRef.current) markerRef.current.setLatLng(latest);
      mapRef.current.panTo(latest);
    } else if (currentLocation) {
      const pos: [number, number] = [currentLocation.lat, currentLocation.lng];
      if (markerRef.current) markerRef.current.setLatLng(pos);
      if (mapRef.current.getZoom() < 10) {
        mapRef.current.setView(pos, 14);
      } else {
        mapRef.current.panTo(pos);
      }
    }
  }, [currentLocation, routePoints, isTracking]);

  // Handle Starting Journey
  const handleStartJourney = async () => {
    if (!currentUser) return;
    if (!currentLocation) {
      alert(locationError || 'Awaiting active GPS signal coordinates...');
      return;
    }
    if (!destination.trim()) {
      alert('Please enter a destination to start journey tracking.');
      return;
    }

    setLoading(true);
    setError(null);

    const initialPoint: RoutePoint = {
      lat: currentLocation.lat,
      lng: currentLocation.lng,
      timestamp: new Date().toISOString()
    };

    try {
      // Initialize Heuristic details
      const initialScore = 100;
      const initialRisk: 'low' | 'medium' | 'high' = 'low';

      // Prepare ride details if any field is filled
      let rideDetails: RideDetails | undefined = undefined;
      if (driverName || vehicleNumber || driverPhone) {
        rideDetails = {
          driverName,
          vehicleNumber,
          vehicleType,
          driverPhone,
          addedAt: new Date().toISOString()
        };
      }

      // Call Firestore
      const jId = await startNewJourney(
        currentUser.uid,
        destination,
        initialPoint,
        initialScore,
        initialRisk,
        rideDetails
      );

      journeyIdRef.current = jId;
      const initialJourney: Journey = {
        id: jId,
        userId: currentUser.uid,
        startTime: initialPoint.timestamp,
        route: [initialPoint],
        status: 'active',
        destination: destination,
        safetyScore: initialScore,
        riskLevel: initialRisk,
        rideDetails
      };

      setActiveJourney(initialJourney);
      setRoutePoints([initialPoint]);
      setIsTracking(true);
      await updateSafety('tracking');
    } catch (err: any) {
      console.error(err);
      alert('Failed to launch journey tracking: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  // GPS watch loop (triggered by shared currentLocation)
  useEffect(() => {
    if (!isTracking || !currentLocation || !journeyIdRef.current) return;

    const jId = journeyIdRef.current;
    const currentPoint: RoutePoint = {
      lat: currentLocation.lat,
      lng: currentLocation.lng,
      timestamp: new Date().toISOString()
    };

    // Render point instantly in client-side state
    setRoutePoints(prev => {
      // Avoid duplicate points if location hasn't changed
      const last = prev[prev.length - 1];
      if (last && last.lat === currentPoint.lat && last.lng === currentPoint.lng) return prev;
      return [...prev, currentPoint];
    });

    // We can't use state refs easily here for throttling without refs, but we have routePoints
  }, [currentLocation, isTracking]);

  // Separate effect for Firestore syncing to allow throttling
  const lastSyncRef = useRef<number>(0);
  useEffect(() => {
    if (!isTracking || !currentLocation || !journeyIdRef.current) return;

    const now = Date.now();
    if (now - lastSyncRef.current >= 10000) {
      lastSyncRef.current = now;
      const jId = journeyIdRef.current;
      const currentPoint: RoutePoint = {
        lat: currentLocation.lat,
        lng: currentLocation.lng,
        timestamp: new Date().toISOString()
      };

      // 1. Evaluate safety heuristic
      const evaluation = evaluateSafetyScore(
        routePoints,
        destination,
        activeJourney?.startTime || new Date().toISOString()
      );

      // Update state values
      setSafetyScore(evaluation.score);
      setRiskLevel(evaluation.riskLevel);
      setExplanation(evaluation.explanation);

      // 2. Estimate ETA
      const syncMetrics = async () => {
        let dest: { lat: number, lng: number } | null = PREDEFINED_DESTINATIONS[destination] || null;
        if (!dest) {
          dest = await geocodeAddress(destination);
        }

        let etaStr = 'N/A';
        if (dest && !isNaN(dest.lat) && !isNaN(dest.lng)) {
          const remainingDist = calculateDistance(currentPoint.lat, currentPoint.lng, dest.lat, dest.lng);
          const distKm = (remainingDist / 1000).toFixed(1);
          
          const speedKmh = 40; 
          const etaMins = Math.ceil((remainingDist / 1000 / speedKmh) * 60);
          etaStr = etaMins > 0 ? `${etaMins} mins` : 'Arrived';

          setDistanceRemaining(`${distKm} km`);
          setEta(etaStr);
        } else {
          setDistanceRemaining('N/A');
          setEta('Location not found');
        }
        
        // 3. Write update to Firestore
        updateJourneyRoute(
          jId,
          currentPoint,
          evaluation.score,
          evaluation.riskLevel,
          etaStr
        ).catch(err => console.error("Firestore route update failed:", err));
      };

      syncMetrics();
    }
  }, [currentLocation, isTracking, routePoints, destination, activeJourney?.startTime]);

  // Handle stopping the tracked journey
  const handleStopJourney = async () => {
    if (!journeyIdRef.current) return;
    setLoading(true);

    try {
      await stopJourney(journeyIdRef.current, 'completed');
      await updateSafety('safe');

      setActiveJourney(null);
      setRoutePoints([]);
      setIsTracking(false);
      setDestination('');
      journeyIdRef.current = null;
      alert('Journey successfully completed. Safety log archived.');
    } catch (err: any) {
      console.error(err);
      alert('Error completing journey: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  // Handle Update Ride Details
  const handleUpdateRideDetails = async () => {
    if (!journeyIdRef.current) return;
    setLoading(true);
    try {
      const updatedDetails: RideDetails = {
        driverName,
        vehicleNumber,
        vehicleType,
        driverPhone,
        addedAt: new Date().toISOString()
      };
      await updateRideDetails(journeyIdRef.current, updatedDetails);
      setActiveJourney(prev => prev ? { ...prev, rideDetails: updatedDetails } : null);
      setIsEditingRide(false);
      alert('Ride details successfully updated.');
    } catch (err: any) {
      console.error(err);
      alert('Error updating ride details: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  // Share Read-Only Tracking Link
  const copyShareLink = () => {
    if (!journeyIdRef.current) return;
    const shareUrl = `${window.location.origin}/share/${journeyIdRef.current}`;
    
    navigator.clipboard.writeText(shareUrl).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }).catch(console.error);
  };

  return (
    <div className="flex flex-col gap-5 py-2 pb-12">
      {/* Page Title Header */}
      <div className="flex flex-col mt-1">
        <div className="flex items-center gap-3 mb-2">
          <button 
            onClick={() => navigate(-1)} 
            className="w-8 h-8 flex items-center justify-center rounded-full glass border border-white/10 hover:bg-white/5 transition active:scale-95 shrink-0"
          >
            <ArrowLeft className="w-4 h-4 text-white" />
          </button>
          <h2 className="text-xl font-bold font-display text-white italic tracking-tight">Live Journey Guardian</h2>
        </div>
        <p className="text-xs text-gray-400 font-sans mt-1 leading-relaxed pl-11">
          Share your live location with trusted contacts and stay protected throughout your journey.
        </p>
      </div>

      {/* Journey Status Card */}
      <div className="glass p-5 rounded-[24px] border border-white/5 relative overflow-hidden group">
        <div className="absolute top-0 right-0 w-32 h-32 bg-brand-pink/5 rounded-full blur-3xl -mr-16 -mt-16 group-hover:bg-brand-pink/10 transition-colors" />
        <div className="flex flex-col gap-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className={`w-2.5 h-2.5 rounded-full ${isTracking ? 'bg-green-500 animate-pulse' : 'bg-gray-500'}`} />
              <span className="text-[10px] font-bold text-white/50 uppercase tracking-[0.2em]">Journey Status</span>
            </div>
            <span className={`text-[10px] font-black px-2 py-0.5 rounded-full border ${
              isTracking 
              ? 'bg-green-500/10 border-green-500/20 text-green-400' 
              : 'bg-white/5 border-white/10 text-white/40'
            }`}>
              {isTracking ? 'ACTIVE' : 'NOT STARTED'}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-y-5 gap-x-8">
            <div className="flex flex-col gap-1">
              <span className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Safety Score</span>
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-brand-purple to-brand-pink">
                  {safetyScore}%
                </span>
                <span className="text-[8px] font-bold text-green-400/70 uppercase">High</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Guardians</span>
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl font-black text-white">
                  {contacts.length}
                </span>
                <span className="text-[8px] font-bold text-brand-lavender/70 uppercase">Connected</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">ETA</span>
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl font-black text-white">
                  {eta}
                </span>
                <span className="text-[8px] font-bold text-gray-600 uppercase">Estimated</span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Distance</span>
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl font-black text-white">
                  {distanceRemaining}
                </span>
                <span className="text-[8px] font-bold text-gray-600 uppercase">To Go</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 1. Leaflet Map container */}
      <div className="relative">
        <div
          id="journey-map"
          className="h-60 w-full rounded-2xl border border-purple-500/10 z-10 shadow-[0_4px_20px_rgba(0,0,0,0.3)]"
          style={{ minHeight: '240px' }}
        />
        
        <div className="absolute bottom-3 left-3 z-20 glass px-3 py-1.5 rounded-xl border border-white/5 shadow-xl max-w-[80%]">
          <p className="text-[9px] font-bold text-white/80 leading-tight">
            📍 Live Safety Tracking Active — Your location is being securely shared with trusted guardians.
          </p>
        </div>

        {locationError && (
          <div className="absolute top-3 inset-x-3 z-30 p-2.5 bg-red-500/10 border border-red-500/20 rounded-xl backdrop-blur-md text-center text-[10px] font-bold text-red-400">
            {locationError}
          </div>
        )}

        {isTracking && (
          <div className="absolute top-3 left-3 z-20 glass px-3 py-1.5 rounded-xl border border-brand-purple/20 flex items-center gap-1.5">
            <span className="w-2 h-2 bg-red-500 rounded-full animate-ping" />
            <span className="text-[10px] font-bold text-white uppercase tracking-wider font-mono">Live Broadcast</span>
          </div>
        )}
      </div>

      <OfflineBanner />

      {/* 2. Destination Form Controls / Active Tracking Stats */}
      {!isTracking ? (
        <div className="glass p-5 rounded-[20px] flex flex-col gap-4">
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-gray-400 font-sans">Set Journey Destination</label>
            <div className="relative">
              <Compass className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-brand-lavender animate-spin [animation-duration:8s]" />
              <input
                type="text"
                value={destination}
                onChange={(e) => setDestination(e.target.value)}
                placeholder="Enter your destination"
                className="w-full h-11 pl-10 pr-4 rounded-xl bg-brand-card/70 border border-purple-500/15 focus:border-brand-pink/50 focus:outline-none text-sm text-white placeholder-gray-500 font-sans transition"
              />
            </div>
          </div>

          <button
            onClick={handleStartJourney}
            disabled={loading}
            className="w-full h-11 rounded-xl bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-purple hover:to-brand-lavender text-white font-semibold text-sm font-sans flex items-center justify-center gap-2 shadow-lg transition active:scale-[0.99] disabled:opacity-50"
          >
            <Play className="w-4 h-4 fill-white" />
            <span>{loading ? 'Starting Tracker...' : 'Start Safe Journey'}</span>
          </button>

          {/* Ride Details Collapsible */}
          <div className="border-t border-white/5 pt-4">
            <button
              onClick={() => setShowRideDetails(!showRideDetails)}
              className="flex items-center justify-between w-full text-xs font-semibold text-brand-lavender hover:text-white transition"
            >
              <div className="flex items-center gap-2">
                <Car className="w-4 h-4" />
                <span>Ride Details (optional)</span>
              </div>
              {showRideDetails ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>

            {showRideDetails && (
              <div className="flex flex-col gap-3 mt-4 animate-in fade-in slide-in-from-top-2 duration-300">
                <div className="grid grid-cols-2 gap-3">
                  <div className="flex flex-col gap-1.5">
                    <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider ml-1">Driver Name</label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-500" />
                      <input
                        type="text"
                        value={driverName}
                        onChange={(e) => setDriverName(e.target.value)}
                        placeholder="e.g. Ramesh"
                        className="w-full h-10 pl-9 pr-3 rounded-xl bg-white/5 border border-white/10 focus:border-brand-pink/40 focus:outline-none text-xs text-white placeholder-gray-600 font-sans transition"
                      />
                    </div>
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider ml-1">Vehicle Num</label>
                    <div className="relative">
                      <Hash className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-500" />
                      <input
                        type="text"
                        value={vehicleNumber}
                        onChange={(e) => setVehicleNumber(e.target.value)}
                        placeholder="AP 16 AB 1234"
                        className="w-full h-10 pl-9 pr-3 rounded-xl bg-white/5 border border-white/10 focus:border-brand-pink/40 focus:outline-none text-xs text-white placeholder-gray-600 font-sans transition"
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="flex flex-col gap-1.5">
                    <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider ml-1">Vehicle Type</label>
                    <select
                      value={vehicleType}
                      onChange={(e) => setVehicleType(e.target.value as any)}
                      className="w-full h-10 px-3 rounded-xl bg-brand-card/70 border border-white/10 focus:border-brand-pink/40 focus:outline-none text-xs text-white font-sans transition appearance-none"
                    >
                      <option value="Cab" className="bg-brand-dark">Cab</option>
                      <option value="Auto" className="bg-brand-dark">Auto</option>
                      <option value="Bike" className="bg-brand-dark">Bike</option>
                      <option value="Other" className="bg-brand-dark">Other</option>
                    </select>
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider ml-1">Driver Phone</label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-500" />
                      <input
                        type="text"
                        value={driverPhone}
                        onChange={(e) => setDriverPhone(e.target.value)}
                        placeholder="Optional"
                        className="w-full h-10 pl-9 pr-3 rounded-xl bg-white/5 border border-white/10 focus:border-brand-pink/40 focus:outline-none text-xs text-white placeholder-gray-600 font-sans transition"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="flex flex-col gap-4">
          {/* Active stats display */}
          <div className="glass p-5 rounded-[20px] flex flex-col gap-4">
            <div className="flex justify-between items-start border-b border-purple-500/10 pb-3">
              <div>
                <span className="text-xs text-gray-400 font-sans">Destination</span>
                <p className="text-sm font-bold text-white mt-0.5 flex items-center gap-1.5 font-display">
                  <MapPin className="w-4 h-4 text-brand-pink shrink-0" />
                  <span>{destination}</span>
                </p>
              </div>

              <div className="text-right">
                <span className="text-xs text-gray-400 font-sans">Estimated ETA</span>
                <p className="text-sm font-mono font-bold text-brand-pink mt-0.5">{eta}</p>
              </div>
            </div>

            {/* Heuristic Safety Score Display */}
            <div className="flex flex-col gap-2">
              <div className="flex justify-between items-center">
                <span className="text-xs font-semibold text-gray-400 font-sans">Heuristic Safety Score</span>
                <span className={`text-xs font-bold font-sans px-2.5 py-0.5 rounded-full ${
                  riskLevel === 'low' ? 'bg-green-500/20 text-green-400 border border-green-500/30' :
                  riskLevel === 'medium' ? 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30' :
                  'bg-red-500/20 text-red-400 border border-red-500/30 animate-pulse'
                }`}>
                  {riskLevel.toUpperCase()} RISK
                </span>
              </div>

              <div className="flex items-center gap-3">
                <div className="flex-grow bg-white/5 h-2.5 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      safetyScore >= 80 ? 'bg-green-500' : safetyScore >= 50 ? 'bg-yellow-500' : 'bg-red-500'
                    }`}
                    style={{ width: `${safetyScore}%` }}
                  />
                </div>
                <span className="text-sm font-bold font-mono text-white">{safetyScore}%</span>
              </div>

              <div className="p-2.5 bg-brand-purple/10 border border-brand-purple/15 rounded-xl text-[11px] text-brand-lavender leading-relaxed font-sans">
                <span className="font-semibold uppercase tracking-wider text-[9px] font-mono block text-brand-pink mb-0.5">Heuristic Engine Summary</span>
                {explanation}
              </div>
            </div>

            {/* Stop Tracker button */}
            <div className="flex flex-col gap-3">
              {activeJourney?.rideDetails && !isEditingRide && (
                <div className="p-3 bg-brand-purple/5 border border-brand-purple/10 rounded-xl flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="p-1.5 bg-brand-purple/20 rounded-lg text-brand-lavender">
                      <Car className="w-3.5 h-3.5" />
                    </div>
                    <div className="flex flex-col">
                      <span className="text-[10px] font-bold text-brand-lavender/60 uppercase tracking-tight">Active Ride</span>
                      <span className="text-[11px] text-white font-medium">
                        {activeJourney.rideDetails.vehicleType} • {activeJourney.rideDetails.vehicleNumber}
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => setIsEditingRide(true)}
                    className="p-1.5 hover:bg-white/5 rounded-lg text-brand-lavender transition"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {isEditingRide && (
                <div className="p-4 bg-brand-card/90 border border-brand-pink/20 rounded-xl flex flex-col gap-3 animate-in fade-in zoom-in-95">
                  <h4 className="text-[10px] font-bold text-brand-pink uppercase tracking-[0.1em]">Edit Ride Details</h4>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      value={driverName}
                      onChange={(e) => setDriverName(e.target.value)}
                      placeholder="Driver Name"
                      className="w-full h-9 px-3 rounded-lg bg-white/5 border border-white/10 text-[11px] text-white focus:outline-none"
                    />
                    <input
                      type="text"
                      value={vehicleNumber}
                      onChange={(e) => setVehicleNumber(e.target.value)}
                      placeholder="Vehicle Num"
                      className="w-full h-9 px-3 rounded-lg bg-white/5 border border-white/10 text-[11px] text-white focus:outline-none"
                    />
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={handleUpdateRideDetails}
                      disabled={loading}
                      className="flex-1 h-9 bg-brand-purple text-white text-[11px] font-bold rounded-lg transition"
                    >
                      {loading ? 'Updating...' : 'Save Updates'}
                    </button>
                    <button
                      onClick={() => setIsEditingRide(false)}
                      className="px-4 h-9 bg-white/5 text-gray-400 text-[11px] font-medium rounded-lg"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              )}

              <button
                onClick={handleStopJourney}
                disabled={loading}
                className="w-full h-11 rounded-xl bg-red-500/15 hover:bg-red-500/20 border border-red-500/30 text-red-400 font-semibold text-sm font-sans flex items-center justify-center gap-2 transition"
              >
                <Square className="w-4 h-4 fill-red-400" />
                <span>Complete Active Journey</span>
              </button>
              <button
                  onClick={() => setShowUnsafeModal(true)}
                  className="w-full h-11 rounded-xl bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 text-red-400 font-semibold text-sm font-sans flex items-center justify-center gap-2 transition"
              >
                  <Skull className="w-4 h-4" />
                  <span>I'm Unsafe</span>
              </button>
            </div>
          </div>

          {/* Share tracking link controls */}
          <div className="glass p-4 rounded-[20px] flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-brand-purple/15 rounded-xl border border-brand-purple/20 text-brand-lavender">
                <Share2 className="w-4 h-4" />
              </div>
              <div className="flex flex-col">
                <span className="text-xs text-gray-400 font-sans">Share live path</span>
                <span className="text-[11px] text-gray-400 font-sans">Allow guardians to view in real-time</span>
              </div>
            </div>

            <button
              onClick={copyShareLink}
              className="px-3.5 py-1.5 bg-brand-purple hover:bg-brand-lavender text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition active:scale-[0.98]"
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy link'}</span>
            </button>
          </div>
        </div>
      )}

      {/* Safety Features Grid Section */}
      <div className="flex flex-col gap-4 mt-2">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-[10px] font-bold uppercase tracking-[0.2em] text-white/40">Safety Ecosystem Features</h3>
          <span className="text-[8px] font-bold text-brand-pink/60 uppercase tracking-tighter">Powered by SheShield AI</span>
        </div>
        
        <div className="grid grid-cols-2 gap-3">
          {[
            { title: 'Live Location Sharing', icon: Navigation, route: '/tracker', status: isTracking ? 'Live' : 'Ready' },
            { title: 'Trusted Guardian Alerts', icon: Bell, route: '/contacts', status: contacts.length > 0 ? `${contacts.length} Active` : 'Setup' },
            { title: 'AI Safety Score', icon: Activity, route: '/home', status: 'Active' },
            { title: 'Emergency SOS', icon: AlertTriangle, route: '/alert', status: 'Ready' },
            { title: 'One-Tap Police Contact', icon: PhoneCall, route: 'tel:112', status: 'Direct' },
            { title: 'Journey Completion Alert', icon: Check, comingSoon: true },
            { title: 'Auto Check-In Notifications', icon: Clock, comingSoon: true },
            { title: 'Unsafe Area Detection', icon: Shield, comingSoon: true },
          ].map((feature, idx) => (
            <button
              key={idx}
              onClick={() => {
                if (feature.route) {
                  if (feature.route.startsWith('tel:')) {
                    window.location.href = feature.route;
                  } else {
                    navigate(feature.route);
                  }
                }
              }}
              className={`glass p-4 rounded-2xl flex flex-col gap-3 transition-all duration-300 border border-white/5 text-left group ${
                feature.comingSoon ? 'opacity-50 cursor-not-allowed' : 'hover:bg-white/5 hover:border-brand-pink/20 cursor-pointer'
              }`}
            >
              <div className={`p-2 w-fit rounded-xl transition-colors ${
                feature.comingSoon ? 'bg-white/5 text-gray-500' : 'bg-brand-pink/10 text-brand-pink group-hover:bg-brand-pink/20'
              }`}>
                <feature.icon className="w-4.5 h-4.5" />
              </div>
              <div className="flex flex-col gap-0.5">
                <span className="text-[11px] font-bold text-white/90 leading-tight">{feature.title}</span>
                {feature.comingSoon && (
                  <span className="text-[8px] font-bold text-brand-purple uppercase tracking-widest mt-1">Coming Soon</span>
                )}
                {!feature.comingSoon && feature.status && (
                  <span className={`text-[8px] font-bold uppercase tracking-widest mt-1 ${
                    ['Live', 'Active', 'Direct'].includes(feature.status) || feature.status.includes('Active') 
                    ? 'text-green-400' 
                    : 'text-gray-500'
                  }`}>
                    {feature.status}
                  </span>
                )}
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="flex justify-center mt-4 mb-2">
        <div className="px-6 py-2 rounded-full glass border border-white/5 bg-brand-pink/5">
          <span className="text-[10px] font-bold tracking-[0.2em] uppercase bg-clip-text text-transparent bg-gradient-to-r from-brand-purple to-brand-pink">
            Your Safety, Our Priority 💜
          </span>
        </div>
      </div>

      <FloatingBot />
      <UnsafeModal isOpen={showUnsafeModal} onClose={() => setShowUnsafeModal(false)} contacts={contacts} />
    </div>
  );
};
