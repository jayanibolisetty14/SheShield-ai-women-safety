import React, { useEffect, useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { subscribeJourney, Journey, RoutePoint } from '../services/journeys';
import { calculateDistance } from '../utils/distance';
import { MapPin, Compass, ShieldCheck, ShieldAlert, Heart, Info, RefreshCw, Landmark } from 'lucide-react';
import L from 'leaflet';

export const ShareJourney: React.FC = () => {
  const { journeyId } = useParams<{ journeyId: string }>();
  const navigate = useNavigate();

  const [journey, setJourney] = useState<Journey | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // References for Leaflet
  const mapRef = useRef<L.Map | null>(null);
  const markerRef = useRef<L.Marker | null>(null);
  const polylineRef = useRef<L.Polyline | null>(null);

  // 1. Subscribe to Live Journey
  useEffect(() => {
    if (!journeyId) {
      setError('Invalid tracking URL link.');
      setLoading(false);
      return;
    }

    setLoading(true);
    const unsubscribe = subscribeJourney(journeyId, (data) => {
      setLoading(false);
      if (data) {
        setJourney(data);
        setError('');
      } else {
        setError('No active tracking log found with this URL ID.');
      }
    });

    return () => unsubscribe();
  }, [journeyId]);

  // 2. Initialize Map once
  useEffect(() => {
    if (!mapRef.current) {
      const mapContainer = document.getElementById('share-map');
      if (mapContainer) {
        mapRef.current = L.map('share-map', {
          zoomControl: false,
          attributionControl: false
        }).setView([0, 0], 2);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          crossOrigin: true
        }).addTo(mapRef.current);

        polylineRef.current = L.polyline([], {
          color: '#EC4899',
          weight: 5,
          opacity: 0.8
        }).addTo(mapRef.current);

        const customIcon = L.divIcon({
          className: 'custom-gps-icon',
          html: `<div class="relative w-6 h-6"><div class="absolute w-6 h-6 bg-brand-pink/30 rounded-full animate-ping"></div><div class="relative w-4 h-4 m-1 bg-brand-pink border-2 border-white rounded-full"></div></div>`,
          iconSize: [24, 24]
        });

        markerRef.current = L.marker([0, 0], { icon: customIcon }).addTo(mapRef.current);
      }
    }
  }, []);

  // 3. Keep Map in Sync with Journey updates
  useEffect(() => {
    if (journey && journey.route.length > 0 && mapRef.current) {
      const latLngs = journey.route.map(p => [p.lat, p.lng] as [number, number]);
      const latest = latLngs[latLngs.length - 1];

      // Update Path
      if (polylineRef.current) {
        polylineRef.current.setLatLngs(latLngs);
      }

      // Update current marker position
      if (markerRef.current) {
        markerRef.current.setLatLng(latest);
      }

      // Pan to follow user movement
      mapRef.current.panTo(latest);
    }
  }, [journey]);

  return (
    <div className="flex flex-col min-h-screen bg-[#0B0617] text-white">
      {/* Public Tracking Header */}
      <header className="glass px-5 py-4 border-b border-purple-500/10 flex items-center justify-between z-10">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-tr from-brand-purple to-brand-pink rounded-lg flex items-center justify-center">
            <Compass className="w-4.5 h-4.5 text-white animate-spin [animation-duration:8s]" />
          </div>
          <div className="flex flex-col">
            <span className="text-xs font-bold font-display">SheShield Live-Share</span>
            <span className="text-[9px] font-mono text-brand-pink uppercase tracking-wider">Guardian Read-Only Link</span>
          </div>
        </div>

        <button
          onClick={() => navigate('/login')}
          className="text-xs text-brand-lavender font-semibold hover:text-white transition"
        >
          App Login
        </button>
      </header>

      {/* Main Map Stage */}
      <main className="flex-grow relative flex flex-col justify-end">
        {/* Full screen Map */}
        <div id="share-map" className="absolute inset-0 z-0 h-full w-full" />

        {/* Loading Overlay */}
        {loading && (
          <div className="absolute inset-0 bg-[#0B0617]/95 z-30 flex flex-col items-center justify-center gap-2">
            <RefreshCw className="w-6 h-6 text-brand-pink animate-spin" />
            <span className="text-xs text-brand-lavender font-mono">Synchronizing live coordinates...</span>
          </div>
        )}

        {/* Error Dialog */}
        {error && (
          <div className="absolute inset-x-4 top-4 z-30 p-4 bg-red-500/10 border border-red-500/20 rounded-[20px] backdrop-blur-md text-center text-xs text-red-400">
            {error}
          </div>
        )}

        {/* Live Status bottom HUD card */}
        {journey && (
          <div className="z-10 m-4 glass p-4 rounded-[20px] border border-purple-500/15 flex flex-col gap-3 backdrop-blur-lg shadow-2xl">
            <div className="flex justify-between items-start border-b border-purple-500/5 pb-2.5">
              <div>
                <span className="text-[10px] text-gray-400 font-sans">Active Journey Track</span>
                <h3 className="text-sm font-bold text-white font-display mt-0.5 flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-brand-pink" />
                  <span>{journey.destination}</span>
                </h3>
              </div>

              <div className="text-right">
                <span className="text-[10px] text-gray-400 font-sans">Estimate ETA</span>
                <p className="text-sm font-mono font-bold text-brand-pink mt-0.5">{journey.eta || 'Calculating...'}</p>
              </div>
            </div>

            {/* Ride Details if exists */}
            {journey.rideDetails && (
              <div className="px-3 py-2.5 bg-white/5 border border-white/5 rounded-xl flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-1.5 bg-brand-pink/20 rounded-lg text-brand-pink">
                    <Landmark className="w-3.5 h-3.5" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[9px] font-bold text-white/40 uppercase tracking-tight">Ride Details</span>
                    <span className="text-xs text-white font-medium">
                      {journey.rideDetails.vehicleType} • {journey.rideDetails.vehicleNumber}
                    </span>
                  </div>
                </div>
                <div className="flex flex-col items-end">
                  <span className="text-[9px] font-bold text-white/40 uppercase tracking-tight">Driver</span>
                  <span className="text-xs text-white font-medium">{journey.rideDetails.driverName}</span>
                </div>
              </div>
            )}

            {/* Safety Assessment indicator */}
            <div className="grid grid-cols-2 gap-3.5 mt-0.5">
              <div className="flex flex-col">
                <span className="text-[10px] text-gray-400 font-sans">Heuristic Safety Score</span>
                <span className="text-lg font-bold font-mono text-white mt-0.5">{journey.safetyScore}%</span>
              </div>

              <div className="flex flex-col items-end">
                <span className="text-[10px] text-gray-400 font-sans">Risk Level</span>
                <span className={`text-[10px] font-bold font-sans px-2.5 py-0.5 rounded-full border mt-1 shrink-0 ${
                  journey.riskLevel === 'low' ? 'bg-green-500/15 text-green-400 border-green-500/20' :
                  journey.riskLevel === 'medium' ? 'bg-yellow-500/15 text-yellow-400 border-yellow-500/20' :
                  'bg-red-500/15 text-red-400 border-red-500/20 animate-pulse'
                }`}>
                  {journey.riskLevel.toUpperCase()} RISK
                </span>
              </div>
            </div>

            {/* Realtime tracking info text */}
            <div className="flex items-start gap-1.5 p-2 bg-brand-purple/10 border border-brand-purple/15 rounded-xl text-[10px] text-brand-lavender leading-relaxed">
              <Info className="w-3.5 h-3.5 text-brand-pink shrink-0 mt-0.5" />
              <span>
                {journey.status === 'active'
                  ? 'This live coordinate track updates every 10 seconds. Keep this tab open to monitor real-time progress.'
                  : 'This tracking session has ended. The user completed their journey safely.'}
              </span>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};
