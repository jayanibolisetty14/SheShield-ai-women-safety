import React, { useEffect, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { useAuth } from '../context/AuthContext';
import { getContacts, EmergencyContact, subscribeContacts } from '../services/contacts';
import { createAlert, resolveAlert, getUserAlerts } from '../services/alerts';
import {
  ShieldAlert,
  Phone,
  Share2,
  AlertTriangle,
  MapPin,
  Flame,
  Shield,
  Book,
  FileText,
  UserCheck,
  Volume2,
  VolumeX,
  Compass,
  Car,
  ArrowRight,
  Bot,
  ShieldCheck,
  Skull
} from 'lucide-react';
import { getUserJourneys, Journey } from '../services/journeys';
import { FloatingBot } from '../components/FloatingBot';
import { UnsafeModal } from '../components/UnsafeModal';

export const Home: React.FC = () => {
  const { currentUser, userProfile, updateLocation, updateSafety, currentLocation, locationError } = useAuth();
  const navigate = useNavigate();

  const [contacts, setContacts] = useState<EmergencyContact[]>([]);
  const [gpsLoading, setGpsLoading] = useState(false);
  const [addressLoading, setAddressLoading] = useState(false);
  const [placeName, setPlaceName] = useState<string | null>(null);
  const [voiceTriggerActive, setVoiceTriggerActive] = useState(false);
  const [sirenActive, setSirenActive] = useState(false);
  const [speechError, setSpeechError] = useState('');
  const voiceTriggerActiveRef = useRef(false);
  voiceTriggerActiveRef.current = voiceTriggerActive;

  // Siren Refs
  const audioCtxRef = useRef<AudioContext | null>(null);
  const oscillatorRef = useRef<OscillatorNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const sweepIntervalRef = useRef<any>(null);

  // Reverse geocoding cache ref
  const lastFetchRef = useRef<{ lat: number; lng: number; time: number } | null>(null);

  // Speech Recognition reference
  const recognitionRef = useRef<any>(null);

  const [activeJourney, setActiveJourney] = useState<Journey | null>(null);
  const [showUnsafeModal, setShowUnsafeModal] = useState(false);

  // 1. Subscribe to Emergency Contacts
  useEffect(() => {
    if (!currentUser) return;
    const unsub = subscribeContacts(currentUser.uid, (data) => {
      setContacts(data);
    });
    return () => unsub();
  }, [currentUser?.uid]);

  // Check for Active Journey
  useEffect(() => {
    if (!currentUser) return;
    const checkActiveJourney = async () => {
      try {
        const journeys = await getUserJourneys(currentUser.uid);
        const active = journeys.find(j => j.status === 'active');
        setActiveJourney(active || null);
      } catch (err) {
        console.error('Error checking active journey:', err);
      }
    };
    checkActiveJourney();
  }, [currentUser]);

  // 2. Fetch Live Geolocation
  useEffect(() => {
    setGpsLoading(!currentLocation && !locationError);
  }, [currentLocation, locationError]);

  // 3. Reverse Geocoding Effect
  useEffect(() => {
    if (!currentLocation) return;

    const fetchPlace = async () => {
      const now = Date.now();
      if (lastFetchRef.current) {
        const dist = getDistance(
          currentLocation.lat,
          currentLocation.lng,
          lastFetchRef.current.lat,
          lastFetchRef.current.lng
        );
        const timeDiff = now - lastFetchRef.current.time;
        
        // Cache: Only re-fetch if moved > 50m OR 30 seconds passed
        if (dist < 50 && timeDiff < 30000) return;
      }

      setAddressLoading(true);
      try {
        // Nominatim requires email/User-Agent. Using user email as requested.
        const response = await fetch(
          `https://nominatim.openstreetmap.org/reverse?format=json&lat=${currentLocation.lat}&lon=${currentLocation.lng}&email=chotaterracegarden@gmail.com`
        );
        const data = await response.json();
        
        if (data && data.address) {
          const addr = data.address;
          const road = addr.road || addr.suburb || addr.neighbourhood || addr.pedestrian;
          const city = addr.city || addr.town || addr.village || addr.state_district;
          
          let display = road ? `Near ${road}` : '';
          if (city) {
            display = display ? `${display}, ${city}` : city;
          }
          
          // Fallback to display_name snippet if constructed string is empty
          setPlaceName(display || data.display_name.split(',').slice(0, 2).join(','));
        } else {
          setPlaceName(null);
        }
        
        lastFetchRef.current = { lat: currentLocation.lat, lng: currentLocation.lng, time: now };
      } catch (err) {
        console.error('Reverse geocoding failed:', err);
        // Fallback to lat/lng by setting placeName to null
        setPlaceName(null);
      } finally {
        setAddressLoading(false);
      }
    };

    fetchPlace();
  }, [currentLocation]);

  // 4. Siren Control Logic
  const startSiren = () => {
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }

      const oscillator = ctx.createOscillator();
      const gainNode = ctx.createGain();
      
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(600, ctx.currentTime);
      gainNode.gain.setValueAtTime(0.15, ctx.currentTime);
      
      oscillator.connect(gainNode);
      gainNode.connect(ctx.destination);
      oscillator.start();
      
      oscillatorRef.current = oscillator;
      gainNodeRef.current = gainNode;

      let goingUp = true;
      sweepIntervalRef.current = setInterval(() => {
        const freq = goingUp ? 1200 : 600;
        if (oscillatorRef.current && audioCtxRef.current) {
          oscillatorRef.current.frequency.exponentialRampToValueAtTime(freq, audioCtxRef.current.currentTime + 0.5);
        }
        goingUp = !goingUp;
      }, 500);

      setSirenActive(true);
      console.log('Home Siren started');
    } catch (err) {
      console.error('Failed to start home siren:', err);
    }
  };

  const stopSiren = () => {
    if (oscillatorRef.current) {
      try {
        oscillatorRef.current.stop();
        oscillatorRef.current.disconnect();
      } catch (e) {}
      oscillatorRef.current = null;
    }
    if (gainNodeRef.current) {
      gainNodeRef.current.disconnect();
      gainNodeRef.current = null;
    }
    if (sweepIntervalRef.current) {
      clearInterval(sweepIntervalRef.current);
      sweepIntervalRef.current = null;
    }
    setSirenActive(false);
    console.log('Home Siren stopped');
  };

  const toggleSiren = () => {
    if (sirenActive) {
      stopSiren();
    } else {
      startSiren();
    }
  };

  // 5. Speech Recognition Setup (Voice Activation "Help Me")
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setSpeechError('Speech recognition is not supported in your browser.');
      return;
    }

    const rec = new SpeechRecognition();
    rec.continuous = true;
    rec.interimResults = false;
    rec.lang = 'en-US';

    rec.onresult = (event: any) => {
      const resultIndex = event.resultIndex;
      const transcript = event.results[resultIndex][0].transcript.toLowerCase().trim();
      console.log('Voice trigger recognized:', transcript);

      if (transcript.includes('help me') || transcript.includes('emergency')) {
        // Voice trigger detected! Redirect to Active SOS Alert Page
        triggerSosImmediate();
      }
    };

    rec.onerror = (e: any) => {
      const errorType = e.error;
      console.error('Speech recognition error in onerror:', errorType, e);
      
      // Certain errors should NOT kill the listener permanently (e.g. no-speech, aborted)
      // 'not-allowed' is fatal (permission denied)
      const fatalErrors = ['not-allowed', 'service-not-allowed', 'language-not-supported'];
      
      if (fatalErrors.includes(errorType)) {
        setSpeechError(`Speech recognition status: ${errorType || 'permission denied'}`);
        setVoiceTriggerActive(false);
        voiceTriggerActiveRef.current = false;
      } else {
        // Non-fatal errors like 'no-speech' or 'network' (temporary) shouldn't disable the UI toggle
        // We just log it and let onend handle the restart attempt if voiceTriggerActiveRef is still true
        console.warn('Non-fatal speech error, will attempt restart if active:', errorType);
      }
    };

    rec.onend = () => {
      console.log('Speech recognition service disconnected.');
      // Auto restart ONLY if explicitly enabled
      if (voiceTriggerActiveRef.current) {
        console.log('Voice trigger is still active, attempting restart...');
        try {
          rec.start();
        } catch (err) {
          console.error('Failed to restart speech recognition:', err);
          // If restart fails multiple times, we might want to notify the user, 
          // but for now we just log it.
        }
      }
    };

    recognitionRef.current = rec;

    // Start recognition if toggled active
    if (voiceTriggerActive) {
      try {
        rec.start();
      } catch (err) {
        console.error("Failed to start speech recognition in useEffect:", err);
      }
    }

    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.onend = null; // Unregister onend to prevent restarts during cleanup
          recognitionRef.current.stop();
        } catch (e) {}
      }
    };
  }, [voiceTriggerActive]);

  // Toggle Voice Activation
  const handleVoiceToggle = () => {
    if (!voiceTriggerActive) {
      // Clear the status and let the useEffect initialize
      setSpeechError('');
      setVoiceTriggerActive(true);
    } else {
      setVoiceTriggerActive(false);
      if (recognitionRef.current) {
        try {
          recognitionRef.current.onend = null;
          recognitionRef.current.stop();
        } catch (err) {}
      }
    }
  };

  // Immediate SOS Trigger
  const triggerSosImmediate = () => {
    // Navigate straight to Emergency Alert countdown page
    navigate('/alert');
  };

  // Trigger Silent SOS (Quietly logs alert, notifies contacts via silent links, no audio/visual feedback)
  const triggerSilentSos = async () => {
    if (!currentUser || !currentLocation) {
      alert(locationError || 'Awaiting active GPS signal coordinates...');
      return;
    }
    const currentLat = currentLocation.lat;
    const currentLng = currentLocation.lng;

    try {
      await updateSafety('danger');
      const alertId = await createAlert(
        currentUser.uid,
        'silent',
        currentLat,
        currentLng,
        userProfile?.displayName || 'SheShield User'
      );

      // Web share link for emergency contact
      const mapsUrl = `https://www.google.com/maps?q=${currentLat},${currentLng}`;
      const message = `SILENT SOS ALERT from SheShield AI! I need help. My coordinates: ${currentLat}, ${currentLng}. Map: ${mapsUrl}`;

      if (navigator.share) {
        await navigator.share({
          title: 'SheShield AI SILENT SOS',
          text: message,
          url: mapsUrl
        });
      } else {
        const smsUrl = `sms:${contacts.map(c => c.phone).join(',')}?body=${encodeURIComponent(message)}`;
        window.open(smsUrl, '_blank');
      }

      alert('Silent Alert registered! Guardians have been notified.');
    } catch (err: any) {
      console.error(err);
      alert('Error triggering Silent SOS: ' + err.message);
    }
  };

  const handleIAmSafe = async () => {
    // 1. Stop local siren
    stopSiren();
    
    // 2. Stop voice triggers
    setVoiceTriggerActive(false);
    if (recognitionRef.current) {
      try {
        recognitionRef.current.onend = null;
        recognitionRef.current.stop();
      } catch (err) {}
    }

    try {
      // 3. Update safety status in profile
      await updateSafety('safe');

      // 4. Resolve any active alerts in database
      if (currentUser) {
        const alerts = await getUserAlerts(currentUser.uid);
        const activeAlerts = (alerts || []).filter(a => a.status === 'active');
        for (const alertObj of activeAlerts) {
          await resolveAlert(alertObj.id);
        }
      }

      alert('Safety confirmed. All alerts and sirens have been deactivated.');
    } catch (err) {
      console.error('Failed to update safety status:', err);
    }
  };

  // Share Location Utility
  const shareLocation = async () => {
    if (!currentLocation) {
      alert(locationError || 'Awaiting active GPS signal coordinates...');
      return;
    }
    const mapsUrl = `https://www.google.com/maps?q=${currentLocation.lat},${currentLocation.lng}`;
    const message = `I am sharing my live coordinates via SheShield: ${mapsUrl}`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: 'My Live Location',
          text: message,
          url: mapsUrl
        });
      } catch (err) {
        console.error(err);
      }
    } else {
      const whatsappUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(message)}`;
      window.open(whatsappUrl, '_blank');
    }
  };

  return (
    <div className="flex flex-col gap-6 py-2 pb-12">
      {/* Welcome Message */}
      <div className="px-1 mt-2">
        <h1 className="text-2xl font-bold font-display text-white">Hello, {userProfile?.displayName || currentUser?.displayName || currentUser?.email?.split('@')[0] || ''}</h1>
        <p className="text-sm text-white/60">Stay safe today.</p>
      </div>
      
      {/* Active Journey Ride Details Banner */}
      {activeJourney && activeJourney.rideDetails && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          onClick={() => navigate('/tracker')}
          className="glass p-4 rounded-[24px] border border-brand-pink/30 bg-brand-pink/5 flex items-center justify-between cursor-pointer group"
        >
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-brand-pink/20 rounded-xl text-brand-pink group-hover:scale-110 transition">
              <Car className="w-5 h-5" />
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] font-bold text-brand-pink uppercase tracking-widest">Active Ride Details</span>
              <p className="text-xs text-white mt-0.5">
                {activeJourney.rideDetails.vehicleType} • {activeJourney.rideDetails.vehicleNumber} • Driver: {activeJourney.rideDetails.driverName}
              </p>
            </div>
          </div>
          <ArrowRight className="w-4 h-4 text-brand-pink opacity-50 group-hover:opacity-100 group-hover:translate-x-1 transition" />
        </motion.div>
      )}

      {/* 1. Header Metrics Grid */}
      <div className="grid grid-cols-1 gap-4 mt-1">
        {/* Safety Score Widget */}
        <div
          className="glass p-5 rounded-[24px] flex flex-col justify-between transition-all duration-300"
        >
          <div>
            <p className="text-[10px] font-bold text-white/40 tracking-[0.2em] uppercase mb-2">Neighborhood Safety Score</p>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-emerald-600">
                85%
              </span>
              <span className="text-[10px] font-mono font-bold text-brand-lavender uppercase tracking-widest">Secure</span>
            </div>
          </div>
          <div className="mt-4 h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-green-400 to-emerald-600" style={{ width: '85%' }}></div>
          </div>
        </div>

        {/* Total Guardians Card */}
        <div
          onClick={() => navigate('/contacts')}
          className="glass p-5 rounded-[24px] flex flex-col justify-between cursor-pointer hover:border-white/20 hover:scale-[1.01] transition-all duration-300"
        >
          <div>
            <p className="text-[10px] font-bold text-white/40 tracking-[0.2em] uppercase mb-2">Trusted Guardians</p>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-brand-purple to-brand-pink">
                {contacts.length}
              </span>
              <span className="text-[10px] font-mono font-bold text-brand-lavender uppercase tracking-widest">Active</span>
            </div>
          </div>
          <div className="mt-4 h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-brand-purple to-brand-pink" style={{ width: `${Math.min(contacts.length * 25, 100)}%` }}></div>
          </div>
        </div>
      </div>

      {/* Live GPS Coordinates banner */}
      <div className="glass p-5 rounded-[24px] flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-brand-pink/10 rounded-2xl border border-white/5">
            <MapPin className="w-5 h-5 text-brand-pink animate-bounce" />
          </div>
          <div className="flex flex-col">
            <span className="text-[10px] font-bold text-white/40 tracking-[0.15em] uppercase">Live Coordinates</span>
            <span className={`text-xs font-mono mt-1 select-all ${locationError ? 'text-red-400' : 'text-white'}`}>
              {locationError ? locationError : (gpsLoading ? 'Acquiring satellites...' : addressLoading ? 'Locating...' : placeName ? placeName : currentLocation ? `${currentLocation.lat.toFixed(5)}, ${currentLocation.lng.toFixed(5)}` : 'No GPS Connection')}
            </span>
          </div>
        </div>
        <button
          onClick={shareLocation}
          className="w-10 h-10 bg-white/5 border border-white/10 hover:bg-white/10 text-brand-lavender hover:text-white rounded-xl flex items-center justify-center transition disabled:opacity-30"
          disabled={!currentLocation}
        >
          <Share2 className="w-4 h-4" />
        </button>
      </div>

      {/* 2. Main Animated SOS Button (Center of App) */}
      <div className="flex flex-col items-center justify-center py-6 select-none relative">
        <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowUnsafeModal(true)}
            className="mb-8 flex items-center gap-2 px-6 py-2 bg-red-500/10 border border-red-500/30 rounded-2xl text-red-400 font-bold text-xs uppercase tracking-widest transition-all z-10 cursor-pointer shadow-[0_0_20px_rgba(239,68,68,0.1)]"
        >
            <Skull className="w-4 h-4" />
            <span>I'm Unsafe</span>
        </motion.button>

        <div className="relative flex items-center justify-center">
          {/* Animated pulsing soundwave rings */}
          <div className="absolute w-72 h-72 bg-brand-pink/5 rounded-full blur-[60px] animate-pulse pointer-events-none" />
          <div className="absolute w-60 h-60 bg-red-500/10 rounded-full pulse-ring-element pointer-events-none" />
          <div className="absolute w-48 h-48 bg-red-500/15 rounded-full pulse-ring-element [animation-delay:0.7s] pointer-events-none" />

          {/* Core SOS Trigger Button with Tri-gradient border and glass center */}
          <button
            onClick={triggerSosImmediate}
            className="relative w-48 h-48 rounded-full bg-gradient-to-tr from-brand-purple via-brand-lavender to-brand-pink p-[3px] shadow-[0_0_50px_rgba(236,72,153,0.35)] hover:scale-105 active:scale-95 transition-all duration-300 z-10 cursor-pointer"
          >
            <div className="w-full h-full rounded-full bg-[#0B0617] flex flex-col items-center justify-center border-4 border-white/5">
              <span className="text-4xl font-black italic tracking-widest text-white mb-1">SOS</span>
              <span className="text-[9px] font-bold tracking-[0.3em] text-white/40 uppercase">EMERGENCY</span>
            </div>
          </button>
        </div>
        
        {/* I am Safe Quick Action Button */}
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={handleIAmSafe}
          className="mt-8 flex items-center gap-2 px-8 py-3 bg-green-500/10 hover:bg-green-500/20 border border-green-500/30 rounded-2xl text-green-400 font-bold text-sm uppercase tracking-widest transition-all z-10 cursor-pointer shadow-[0_0_20px_rgba(34,197,94,0.1)]"
        >
          <ShieldCheck className="w-4 h-4" />
          <span>I am Safe</span>
        </motion.button>

        <span className="text-[10px] font-bold text-white/40 tracking-[0.15em] uppercase mt-4">
          TAP SOS FOR INSTANT 60S COUNTDOWN ALARM
        </span>
      </div>

      {/* 3. Quick Actions row */}
      <div className="glass p-5 rounded-[24px] flex flex-col gap-4">
        <h3 className="text-[10px] font-bold uppercase tracking-[0.2em] text-white/40">
          Quick Emergency Response
        </h3>
        <div className="grid grid-cols-2 gap-3">
          {/* Call National helpline 112 */}
          <a
            href="tel:112"
            className="flex flex-col items-center justify-center p-3 bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 rounded-2xl transition"
          >
            <span className="text-xl font-black text-red-400">112</span>
            <span className="text-[8px] font-black uppercase text-red-400/60 tracking-widest mt-1">POLICE HELP</span>
          </a>

          {/* Call Women Helpline 1091 */}
          <a
            href="tel:1091"
            className="flex flex-col items-center justify-center p-3 bg-[#7C3AED]/10 hover:bg-[#7C3AED]/20 border border-purple-500/30 rounded-2xl transition"
          >
            <span className="text-xl font-black text-brand-lavender">1091</span>
            <span className="text-[8px] font-black uppercase text-brand-lavender/60 tracking-widest mt-1">WOMEN HELP</span>
          </a>

          {/* Silent SOS */}
          <button
            onClick={triggerSilentSos}
            className="flex items-center justify-center gap-2.5 p-3.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl text-xs font-bold text-white/80 uppercase tracking-wider transition cursor-pointer"
          >
            <AlertTriangle className="w-4 h-4 text-brand-pink" />
            <span>Silent SOS</span>
          </button>

          {/* Share coordinates */}
          <button
            onClick={shareLocation}
            className="flex items-center justify-center gap-2.5 p-3.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl text-xs font-bold text-white/80 uppercase tracking-wider transition cursor-pointer"
          >
            <Share2 className="w-4 h-4 text-[#22C55E]" />
            <span>Broadcast GPS</span>
          </button>
        </div>

        {/* Panic Siren Full-width Toggle */}
        <button
          onClick={toggleSiren}
          className={`relative group overflow-hidden flex items-center justify-center gap-3 p-4 rounded-2xl border transition-all active:scale-[0.98] cursor-pointer ${
            sirenActive 
              ? 'bg-red-500/20 border-red-500/40 shadow-[0_0_20px_rgba(239,68,68,0.2)]' 
              : 'bg-white/5 border-white/10 hover:border-brand-pink/40'
          }`}
        >
          <div className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all ${
            sirenActive ? 'bg-red-500 text-white animate-pulse' : 'bg-brand-pink/10 text-brand-pink'
          }`}>
            {sirenActive ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </div>
          <div className="flex flex-col items-start">
            <span className={`text-xs font-bold uppercase tracking-wider ${sirenActive ? 'text-red-400' : 'text-white'}`}>
              {sirenActive ? 'Siren Blasting' : 'Panic Siren Deterrent'}
            </span>
            <span className="text-[9px] text-gray-400 font-sans mt-0.5">
              {sirenActive ? 'Tap to silence immediately' : 'High-frequency oscillator alert'}
            </span>
          </div>

          {sirenActive && (
            <motion.div 
              animate={{ opacity: [0.1, 0.3, 0.1] }}
              transition={{ duration: 1, repeat: Infinity }}
              className="absolute inset-0 bg-red-500/10 pointer-events-none"
            />
          )}
        </button>
      </div>

      {/* 4. Voice Trigger Switch */}
      <div className="glass p-5 rounded-[24px] flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className={`p-3 rounded-2xl border transition duration-300 ${voiceTriggerActive ? 'bg-brand-pink/15 text-brand-pink border-brand-pink/30' : 'bg-white/5 text-white/30 border-white/5'}`}>
            {voiceTriggerActive ? <Volume2 className="w-5 h-5 animate-bounce" /> : <VolumeX className="w-5 h-5" />}
          </div>
          <div className="flex flex-col">
            <span className="text-xs font-bold text-white tracking-wide font-sans">Voice SOS Activation</span>
            <span className="text-[11px] text-white/40 mt-1">
              {voiceTriggerActive ? "Listening for 'Help Me'..." : "Voice triggers disabled"}
            </span>
          </div>
        </div>
        <button
          onClick={handleVoiceToggle}
          className={`w-12 h-6 rounded-full p-0.5 transition-colors duration-300 outline-none cursor-pointer ${
            voiceTriggerActive ? 'bg-brand-pink' : 'bg-white/10 border border-white/5'
          }`}
        >
          <div
            className={`w-5 h-5 bg-white rounded-full shadow-md transform duration-300 ${
              voiceTriggerActive ? 'translate-x-6' : 'translate-x-0'
            }`}
          />
        </button>
      </div>

      {/* 5. Feature Shortcuts Quicklinks row */}
      <div className="flex flex-col gap-3">
        <span className="text-[10px] font-bold font-mono text-white/40 uppercase tracking-[0.2em] pl-1">
          Feature Hub Shortcuts
        </span>
        <div className="grid grid-cols-4 gap-2.5 text-center">
          <button
            onClick={() => navigate('/tracker')}
            className="glass py-4 px-1 rounded-2xl flex flex-col items-center gap-2.5 cursor-pointer hover:bg-white/5 border border-white/5 text-white/70 hover:text-white transition-all duration-300"
          >
            <Compass className="w-5 h-5 text-brand-purple" />
            <span className="text-[9px] font-bold font-mono uppercase tracking-wider">Journey</span>
          </button>

          <button
            onClick={() => navigate('/legal')}
            className="glass py-4 px-1 rounded-2xl flex flex-col items-center gap-2.5 cursor-pointer hover:bg-white/5 border border-white/5 text-white/70 hover:text-white transition-all duration-300"
          >
            <Book className="w-5 h-5 text-brand-pink" />
            <span className="text-[9px] font-bold font-mono uppercase tracking-wider">Legal</span>
          </button>

          <button
            onClick={() => navigate('/cyber')}
            className="glass py-4 px-1 rounded-2xl flex flex-col items-center gap-2.5 cursor-pointer hover:bg-white/5 border border-white/5 text-white/70 hover:text-white transition-all duration-300"
          >
            <FileText className="w-5 h-5 text-yellow-500" />
            <span className="text-[9px] font-bold font-mono uppercase tracking-wider">Cyber</span>
          </button>

          <button
            onClick={() => navigate('/contacts')}
            className="glass py-4 px-1 rounded-2xl flex flex-col items-center gap-2.5 cursor-pointer hover:bg-white/5 border border-white/5 text-white/70 hover:text-white transition-all duration-300"
          >
            <UserCheck className="w-5 h-5 text-[#22C55E]" />
            <span className="text-[9px] font-bold font-mono uppercase tracking-wider">Guardians</span>
          </button>
        </div>
      </div>
      <FloatingBot />
      <UnsafeModal isOpen={showUnsafeModal} onClose={() => setShowUnsafeModal(false)} contacts={contacts} />
    </div>
  );
};

// Distance calculation helper (Haversine formula)
function getDistance(lat1: number, lon1: number, lat2: number, lon2: number) {
  const R = 6371000; // Radius of the earth in m
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  const d = R * c; // Distance in m
  return d;
}
