export interface SafetyData {
  percentage: number;
  status: 'Safe' | 'Moderate' | 'Risky' | 'Dangerous';
  color: string;
}

export function calculateSafetyScore(lat: number, lng: number): SafetyData {
  // Simulate safety score based on location
  const rawScore = (Math.abs(lat) * 111 + Math.abs(lng) * 77) % 100;
  
  let percentage = Math.round(rawScore);
  let status: SafetyData['status'] = 'Safe';
  let color = '#22C55E'; // Green

  if (percentage < 30) {
    status = 'Dangerous';
    color = '#EF4444'; // Red
  } else if (percentage < 60) {
    status = 'Risky';
    color = '#F59E0B'; // Orange
  } else if (percentage < 85) {
    status = 'Moderate';
    color = '#EAB308'; // Yellow
  } else {
    status = 'Safe';
    color = '#22C55E'; // Green
  }

  return { percentage, status, color };
}
