/**
 * Calculates the distance between two points in meters using the Haversine formula.
 */
export function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371e3; // Earth's radius in meters
  const phi1 = (lat1 * Math.PI) / 180;
  const phi2 = (lat2 * Math.PI) / 180;
  const deltaPhi = ((lat2 - lat1) * Math.PI) / 180;
  const deltaLambda = ((lon2 - lon1) * Math.PI) / 180;

  const a =
    Math.sin(deltaPhi / 2) * Math.sin(deltaPhi / 2) +
    Math.cos(phi1) * Math.cos(phi2) * Math.sin(deltaLambda / 2) * Math.sin(deltaLambda / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c; // in meters
}

/**
 * Calculates the perpendicular distance from a point to a line segment.
 * Used to measure route deviation from the planned path.
 */
export function calculatePointToLineDistance(
  pLat: number, pLng: number,
  startLat: number, startLng: number,
  endLat: number, endLng: number
): number {
  // If start and end are the same, just return distance to that single point
  if (startLat === endLat && startLng === endLng) {
    return calculateDistance(pLat, pLng, startLat, startLng);
  }

  // Simple projection onto line segment
  const dStart = calculateDistance(pLat, pLng, startLat, startLng);
  const dEnd = calculateDistance(pLat, pLng, endLat, endLng);
  const dSegment = calculateDistance(startLat, startLng, endLat, endLng);

  // Semiperimeter
  const s = (dStart + dEnd + dSegment) / 2;
  // Area using Heron's formula
  const area = Math.sqrt(Math.max(0, s * (s - dStart) * (s - dEnd) * (s - dSegment)));

  // Height = 2 * Area / Base
  const perpendicularDist = (2 * area) / dSegment;

  // If the projection is outside the line segment, return the closer end point distance
  const isObtuseStart = dEnd * dEnd > dStart * dStart + dSegment * dSegment;
  const isObtuseEnd = dStart * dStart > dEnd * dEnd + dSegment * dSegment;

  if (isObtuseStart) return dStart;
  if (isObtuseEnd) return dEnd;

  return perpendicularDist;
}
