import { calculateDistance } from './distance';
import { RoutePoint } from '../services/journeys';

export interface SafetyAssessment {
  score: number;
  riskLevel: 'low' | 'medium' | 'high';
  reasons: string[];
  explanation: string;
}

/**
 * Deterministic helper to simulate a neighborhood hazard factor
 * based on coordinates.
 */
function getNeighborhoodHazardFactor(lat: number, lng: number): number {
  // Deterministic "random" factor based on coordinates
  const hash = Math.abs(Math.sin(lat) * 1000 + Math.cos(lng) * 1000);
  // Penalty between 0 and 15
  return (hash % 15);
}

/**
 * HEURISTIC SAFETY ENGINE (Explicitly Non-Machine Learning Rules Engine)
 *
 * This utility uses simple, deterministic logic rules to evaluate safety metrics:
 * 1. Time of Day Risk (Multipliers/deductions for late-night hours).
 * 2. Neighborhood Hazard (Location-based pseudorandom assessment).
 * 3. Route Deviation (Compares distance of current point against start point / path direction).
 * 4. Long-stop Detection (Flags if the user has been stationary at the exact same point for too long).
 */
export function evaluateSafetyScore(
  route: RoutePoint[],
  destination: string,
  startTimeStr: string
): SafetyAssessment {
  let score = 100;
  const reasons: string[] = [];

  if (route.length === 0) {
    return {
      score: 100,
      riskLevel: 'low',
      reasons: ['Journey just started.'],
      explanation: 'Journey just initiated. Safety is normal.'
    };
  }

  const latestPoint = route[route.length - 1];
  const startTime = new Date(startTimeStr);
  const currentTime = new Date();

  // 1. Time-of-day risk assessment
  // Late night hours (10 PM to 5 AM) have a higher base risk factor
  const hour = currentTime.getHours();
  const isLateNight = hour >= 22 || hour < 5;
  if (isLateNight) {
    score -= 15;
    reasons.push('Late night travel active (10 PM - 5 AM).');
  }

  // 2. Neighborhood Hazard Assessment
  const hazardFactor = getNeighborhoodHazardFactor(latestPoint.lat, latestPoint.lng);
  score -= hazardFactor;
  if (hazardFactor > 5) {
      reasons.push('Neighborhood hazard alert: Increased risk area.');
  }

  // 3. Route deviation
  if (route.length > 1) {
    const startPoint = route[0];
    const totalPoints = route.length;

    // Check maximum jump between consecutive points to identify abnormal teleportation / jumps
    let maxConsecutiveDistance = 0;
    for (let i = 1; i < route.length; i++) {
      const dist = calculateDistance(
        route[i-1].lat, route[i-1].lng,
        route[i].lat, route[i].lng
      );
      if (dist > maxConsecutiveDistance) {
        maxConsecutiveDistance = dist;
      }
    }

    // Sudden jumps > 150m in 10s suggest GPS error or extreme velocity changes
    if (maxConsecutiveDistance > 150) {
      score -= 10;
      reasons.push('Abnormal sudden movement jump detected.');
    }
  }

  // 4. Long-stop / Immobility detection
  // If user is stationary for > 2 minutes (approx 12 points, sampled every 10s)
  if (route.length >= 12) {
    const last12Points = route.slice(-12);
    let maxDistanceInWindow = 0;
    const basePoint = last12Points[0];

    for (let i = 1; i < last12Points.length; i++) {
      const dist = calculateDistance(
        basePoint.lat, basePoint.lng,
        last12Points[i].lat, last12Points[i].lng
      );
      if (dist > maxDistanceInWindow) {
        maxDistanceInWindow = dist;
      }
    }

    // If movement in the last 2 minutes is less than 5 meters
    if (maxDistanceInWindow < 5) {
      score -= 20;
      reasons.push('Immobility: Stationed in the exact same spot for >2 mins.');
    }
  }

  // Clamp score
  score = Math.max(0, Math.min(100, score));

  // Risk levels based on score
  let riskLevel: 'low' | 'medium' | 'high' = 'low';
  if (score < 50) {
    riskLevel = 'high';
  } else if (score < 80) {
    riskLevel = 'medium';
  }

  // Build natural language summary
  let explanation = '';
  if (score >= 90) {
    explanation = 'Safety status is pristine. All tracking metrics are normal.';
  } else if (score >= 80) {
    explanation = 'Mild safety risk. Mainly influenced by time of day or neighborhood characteristics, but tracking remains solid.';
  } else if (score >= 50) {
    explanation = 'Moderate risk indicators. Noticeable stationary delay, neighborhood warnings, or minor routing alerts logged.';
  } else {
    explanation = 'High risk flagged! Proactive safety check advised. Please verify your surroundings.';
  }

  if (reasons.length > 0) {
    explanation += ` Flags: ${reasons.join(' ')}`;
  }

  return {
    score,
    riskLevel,
    reasons,
    explanation
  };
}
