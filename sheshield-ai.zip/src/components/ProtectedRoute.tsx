import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Header } from './Header';
import { BottomNav } from './BottomNav';

interface ProtectedRouteProps {
  children: React.ReactNode;
  showNavAndHeader?: boolean;
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({
  children,
  showNavAndHeader = true
}) => {
  const { currentUser, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    // Show splash / loading spinner while state initializes
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-[#0B0617]">
        <div className="relative flex items-center justify-center w-20 h-20">
          <div className="absolute w-16 h-16 border-4 border-brand-purple border-t-transparent rounded-full animate-spin" />
          <div className="absolute w-10 h-10 border-4 border-brand-pink border-b-transparent rounded-full animate-spin [animation-direction:reverse]" />
        </div>
        <p className="mt-6 text-sm font-medium tracking-wide text-brand-lavender font-mono animate-pulse">
          Authenticating...
        </p>
      </div>
    );
  }

  if (!currentUser) {
    // Save original path and redirect to login
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  const otpPending = localStorage.getItem('otp_pending') === 'true';
  if (otpPending && location.pathname !== '/otp-verification') {
    return <Navigate to="/otp-verification" replace />;
  }

  if (showNavAndHeader) {
    return (
      <div className="min-h-screen bg-[#0B0617] text-gray-100 flex flex-col pb-24 pt-20 relative overflow-hidden">
        {/* Ambient background glows for Frosted Glass theme */}
        <div className="absolute top-[-100px] right-[-100px] w-[500px] h-[500px] bg-[#7C3AED]/20 rounded-full blur-[120px] pointer-events-none z-0" />
        <div className="absolute bottom-[-100px] left-[-100px] w-[500px] h-[500px] bg-[#EC4899]/15 rounded-full blur-[120px] pointer-events-none z-0" />

        <Header />
        <main className="flex-grow px-4 overflow-y-auto relative z-10">
          {children}
        </main>
        <BottomNav />
      </div>
    );
  }

  return <>{children}</>;
};
