import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Home, MapPin, Scale, ShieldAlert, User } from 'lucide-react';

export const BottomNav: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const navItems = [
    { path: '/home', label: 'Home', icon: Home },
    { path: '/tracker', label: 'Tracker', icon: MapPin },
    { path: '/legal', label: 'Legal', icon: Scale },
    { path: '/cyber', label: 'Cyber', icon: ShieldAlert },
    { path: '/profile', label: 'Profile', icon: User },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-[#161122]/60 backdrop-blur-3xl border-t border-white/10 px-4 py-2.5 flex justify-around items-center rounded-t-[24px] pb-safe shadow-[0_-8px_32px_rgba(0,0,0,0.4)]">
      {navItems.map((item) => {
        const isActive = location.pathname === item.path;
        const Icon = item.icon;

        return (
          <button
            key={item.path}
            onClick={() => navigate(item.path)}
            className="flex flex-col items-center justify-center transition-all duration-300 group cursor-pointer"
          >
            <div className={`p-2 rounded-xl transition-all duration-300 ${
              isActive
                ? 'bg-gradient-to-tr from-brand-purple to-brand-pink shadow-lg shadow-brand-purple/30 text-white scale-110'
                : 'text-white/40 group-hover:text-white'
            }`}>
              <Icon className="w-4.5 h-4.5" />
            </div>
            <span className={`text-[8px] font-black font-mono tracking-wider mt-1 transition-colors duration-300 ${
              isActive ? 'text-brand-pink' : 'text-white/40 group-hover:text-white/70'
            }`}>
              {item.label.toUpperCase()}
            </span>
          </button>
        );
      })}
    </nav>
  );
};
