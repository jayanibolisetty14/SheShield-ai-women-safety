import React from 'react';
import { DownloadCloud, Info } from 'lucide-react';
import { motion } from 'motion/react';

export const OfflineBanner: React.FC = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="mb-6 p-4 rounded-2xl bg-brand-purple/10 border border-brand-purple/20 flex items-center gap-4"
    >
      <div className="w-10 h-10 rounded-xl bg-brand-purple/20 flex items-center justify-center shrink-0">
        <DownloadCloud className="w-5 h-5 text-brand-lavender" />
      </div>
      <div className="flex flex-col gap-0.5">
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-white uppercase tracking-wider">Saved for Offline</span>
          <div className="px-1.5 py-0.5 rounded-full bg-green-500/10 border border-green-500/20 text-[8px] font-bold text-green-400 uppercase">
            Active
          </div>
        </div>
        <p className="text-[10px] text-white/50 leading-relaxed">
          These resources are locally stored and accessible even without an internet connection.
        </p>
      </div>
    </motion.div>
  );
};
