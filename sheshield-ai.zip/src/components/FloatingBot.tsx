import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { Bot } from 'lucide-react';

export const FloatingBot: React.FC = () => {
  const navigate = useNavigate();

  return (
    <motion.button
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.9 }}
      onClick={() => navigate('/assistant')}
      className="fixed bottom-24 right-6 w-14 h-14 rounded-full bg-gradient-to-tr from-brand-purple to-brand-pink p-[2px] shadow-lg shadow-brand-pink/20 z-[9999]"
    >
      <div className="w-full h-full rounded-full bg-brand-dark flex items-center justify-center relative">
        <Bot className="w-6 h-6 text-white" />
      </div>
    </motion.button>
  );
};
