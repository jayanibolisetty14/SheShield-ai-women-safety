import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Bell, ShieldCheck, ShieldAlert, Radio } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { NetworkStatus } from './NetworkStatus';

export const Header: React.FC = () => {
  const { userProfile } = useAuth();
  const navigate = useNavigate();

  const getSafetyPill = () => {
    switch (userProfile?.safetyStatus) {
      case 'safe':
        return (
          <div className="flex items-center gap-2 px-3 py-1.5 bg-white/5 border border-white/10 backdrop-blur-md rounded-full text-[10px] font-bold tracking-wider text-white/80 uppercase">
            <span className="w-1.5 h-1.5 bg-[#22C55E] rounded-full animate-pulse" />
            <span>SECURED</span>
          </div>
        );
      case 'danger':
        return (
          <div className="flex items-center gap-2 px-3 py-1.5 bg-red-500/10 border border-red-500/30 backdrop-blur-md rounded-full text-[10px] font-bold tracking-wider text-[#EF4444] uppercase animate-pulse">
            <span className="w-1.5 h-1.5 bg-[#EF4444] rounded-full animate-ping" />
            <span>SOS ACTIVE</span>
          </div>
        );
      case 'tracking':
        return (
          <div className="flex items-center gap-2 px-3 py-1.5 bg-brand-purple/10 border border-brand-purple/30 backdrop-blur-md rounded-full text-[10px] font-bold tracking-wider text-brand-lavender uppercase">
            <span className="w-1.5 h-1.5 bg-brand-pink rounded-full animate-pulse" />
            <span>TRACKING</span>
          </div>
        );
      default:
        return (
          <div className="flex items-center gap-2 px-3 py-1.5 bg-white/5 border border-white/10 backdrop-blur-md rounded-full text-[10px] font-bold tracking-wider text-white/40 uppercase">
            <span>UNKNOWN</span>
          </div>
        );
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-[#161122]/60 backdrop-blur-2xl border-b border-white/10 px-4 py-3 flex items-center justify-between">
      {/* Left: User Avatar & Welcome */}
      <div className="flex items-center gap-3" onClick={() => navigate('/profile')}>
        <div className="w-11 h-11 rounded-full p-[2px] bg-gradient-to-tr from-brand-purple via-brand-lavender to-brand-pink shrink-0 cursor-pointer">
          <div className="w-full h-full rounded-full bg-[#161122] overflow-hidden flex items-center justify-center">
            <img
              src={userProfile?.photoURL || 'https://api.dicebear.com/7.x/adventurer/svg?seed=default'}
              alt="Avatar"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover hover:opacity-85 transition"
            />
          </div>
        </div>
        <div className="flex flex-col cursor-pointer">
          <span className="text-[10px] text-white/50 font-medium uppercase tracking-wider">Welcome back</span>
          <span className="text-sm font-bold text-white font-display line-clamp-1">
            {userProfile?.displayName || ''}
          </span>
        </div>
      </div>

      {/* Right: Safety Pill & Notification Bell */}
      <div className="flex items-center gap-3">
        <NetworkStatus />
        {getSafetyPill()}

        <button
          onClick={() => navigate('/notifications')}
          className="relative w-10 h-10 bg-white/5 border border-white/10 rounded-xl flex items-center justify-center transition text-brand-lavender hover:text-white"
        >
          <Bell className="w-4.5 h-4.5" />
          {userProfile?.safetyStatus === 'danger' && (
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full animate-ping" />
          )}
        </button>
      </div>
    </header>
  );
};
