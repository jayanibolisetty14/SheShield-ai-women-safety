import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle, MapPin, X, CheckCircle, Smartphone, Send } from 'lucide-react';
import { EmergencyContact } from '../services/contacts';

interface UnsafeModalProps {
  isOpen: boolean;
  onClose: () => void;
  contacts: EmergencyContact[];
}

export const UnsafeModal: React.FC<UnsafeModalProps> = ({ isOpen, onClose, contacts }) => {
  const [countdown, setCountdown] = useState(60);
  const [status, setStatus] = useState<'countdown' | 'triggered' | 'cancelled'>('countdown');

  useEffect(() => {
    if (!isOpen) {
      setCountdown(60);
      setStatus('countdown');
      return;
    }

    if (status !== 'countdown') return;

    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          triggerEmergency();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isOpen, status]);

  const triggerEmergency = async () => {
    setStatus('triggered');
    try {
      if (contacts.length === 0) {
        alert("No emergency contacts saved. Please add a guardian first.");
        return;
      }

      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject);
      });
      
      const { latitude, longitude } = position.coords;
      const mapsLink = `https://www.google.com/maps?q=${latitude},${longitude}`;
      const message = `🚨 EMERGENCY ALERT!\n\nI may be in danger and could not confirm my safety within 60 seconds.\n\nMy current location: ${mapsLink}\n\nPlease contact me immediately or inform emergency services.`;

      contacts.forEach(contact => {
        const phone = contact.phone.replace(/\D/g, '');
        // SMS
        const smsUrl = `sms:${phone}?body=${encodeURIComponent(message)}`;
        window.open(smsUrl, '_blank');
        
        // WhatsApp
        const waUrl = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
        window.open(waUrl, '_blank');
      });
      
      alert("Emergency messages prepared for all guardians.");

    } catch (err: any) {
      console.error(err);
      if (err.code === 1) alert("Location permission denied. Please enable GPS for emergency features.");
      else alert("Error preparing emergency alert. Please try again.");
    }
  };

  const handleCancel = () => {
    setStatus('cancelled');
    setTimeout(onClose, 2000);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
        >
          <motion.div
            initial={{ scale: 0.9 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0.9 }}
            className="w-full max-w-sm glass bg-[#130E20]/95 border border-brand-pink/30 p-6 rounded-3xl flex flex-col items-center text-center shadow-2xl"
          >
            {status === 'countdown' && (
              <>
                <AlertTriangle className="w-16 h-16 text-red-500 mb-4 animate-pulse" />
                <h2 className="text-xl font-bold text-white mb-2">Emergency Alert Pending</h2>
                <p className="text-sm text-gray-400 mb-6">
                  Emergency alert will be triggered in <span className="text-white font-bold">{countdown}</span> seconds. If you are safe, tap 'I'm Safe' to cancel.
                </p>
                <div className="text-5xl font-black text-transparent bg-clip-text bg-gradient-to-br from-red-500 to-orange-500 mb-8 font-mono">
                  {countdown}
                </div>
                <button
                  onClick={handleCancel}
                  className="w-full py-4 bg-green-500/20 border border-green-500/50 rounded-2xl text-green-400 font-bold hover:bg-green-500/30 transition"
                >
                  I'm Safe
                </button>
              </>
            )}
            
            {status === 'triggered' && (
              <>
                <Send className="w-16 h-16 text-brand-pink mb-4" />
                <h2 className="text-xl font-bold text-white mb-2">Emergency Triggered</h2>
                <p className="text-sm text-gray-400 mb-6">Opening SMS and WhatsApp for your guardians...</p>
                <button
                  onClick={onClose}
                  className="w-full py-4 bg-white/10 rounded-2xl text-white font-bold hover:bg-white/20 transition"
                >
                  Close
                </button>
              </>
            )}

            {status === 'cancelled' && (
              <>
                <CheckCircle className="w-16 h-16 text-green-500 mb-4" />
                <h2 className="text-xl font-bold text-white mb-2">Emergency Cancelled</h2>
                <p className="text-sm text-gray-400 mb-6">Stay safe!</p>
              </>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
