import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { auth, db } from '../services/firebase';
import { doc, onSnapshot } from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '../services/firestoreErrorHandler';
import {
  UserProfile,
  getUserDoc,
  loginWithEmail,
  registerWithEmail,
  loginWithGoogle,
  logoutUser,
  resetPassword,
  updateUserSafetyStatus,
  updateUserLastLocation
} from '../services/auth';

interface AuthContextType {
  currentUser: FirebaseUser | null;
  userProfile: UserProfile | null;
  loading: boolean;
  currentLocation: { lat: number; lng: number } | null;
  locationError: string | null;
  login: (email: string, pass: string) => Promise<UserProfile>;
  register: (email: string, pass: string, name: string) => Promise<UserProfile>;
  signInWithGoogle: () => Promise<UserProfile>;
  logout: () => Promise<void>;
  forgotPassword: (email: string) => Promise<void>;
  updateSafety: (status: 'safe' | 'danger' | 'tracking') => Promise<void>;
  updateLocation: (lat: number, lng: number) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentLocation, setCurrentLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [locationError, setLocationError] = useState<string | null>(null);

  // Central Geolocation Watcher
  useEffect(() => {
    if (!navigator.geolocation) {
      setLocationError("Geolocation is not supported by your browser.");
      return;
    }

    const watchId = navigator.geolocation.watchPosition(
      (pos) => {
        const coords = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        setCurrentLocation(coords);
        setLocationError(null);
        
        // Sync with server if logged in
        if (currentUser) {
          updateUserLastLocation(currentUser.uid, coords.lat, coords.lng).catch(console.error);
        }
      },
      (err) => {
        let msg = "Unable to retrieve your location.";
        if (err.code === 1) msg = "Location access denied. Please ensure geolocation is allowed for this application.";
        else if (err.code === 2) msg = "Location unavailable.";
        else if (err.code === 3) msg = "Location request timed out.";
        
        console.error("Geolocation error:", err.code, err.message);
        setLocationError(msg);
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );

    return () => navigator.geolocation.clearWatch(watchId);
  }, [currentUser?.uid]);

  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, async (user) => {
      if (user) {
        setCurrentUser(user);
        try {
          // Fetch user profile
          const profile = await getUserDoc(user.uid);
          setUserProfile(profile || {
            uid: user.uid,
            email: user.email,
            displayName: user.displayName || user.email?.split('@')[0] || '',
            photoURL: user.photoURL || `https://api.dicebear.com/7.x/adventurer/svg?seed=${user.uid}`,
            createdAt: new Date().toISOString(),
            safetyStatus: 'safe',
            lastLocation: null
          });

          // Listen to user profile real-time changes
          const userDocRef = doc(db, 'users', user.uid);
          const unsubscribeProfile = onSnapshot(userDocRef, (docSnap) => {
            if (docSnap.exists()) {
              setUserProfile(docSnap.data() as UserProfile);
            }
          }, (err) => {
            handleFirestoreError(err, OperationType.GET, `users/${user.uid}`);
          });

          return () => {
            unsubscribeProfile();
          };
        } catch (error) {
          console.error("Error fetching user profile:", error);
          setLoading(false);
        }
      } else {
        setCurrentUser(null);
        setUserProfile(null);
      }
      setLoading(false);
    });

    return () => {
      unsubscribeAuth();
    };
  }, []);



  const login = useCallback(async (email: string, pass: string) => {
    setLoading(true);
    try {
      const profile = await loginWithEmail(email, pass);
      setUserProfile(profile);
      return profile;
    } finally {
      setLoading(false);
    }
  }, []);

  const register = useCallback(async (email: string, pass: string, name: string) => {
    setLoading(true);
    try {
      const profile = await registerWithEmail(email, pass, name);
      setUserProfile(profile);
      return profile;
    } finally {
      setLoading(false);
    }
  }, []);

  const signInWithGoogle = useCallback(async () => {
    setLoading(true);
    try {
      const profile = await loginWithGoogle();
      setUserProfile(profile);
      return profile;
    } finally {
      setLoading(false);
    }
  }, []);

  const logout = useCallback(async () => {
    setLoading(true);
    try {
      await logoutUser();
      setCurrentUser(null);
      setUserProfile(null);
    } finally {
      setLoading(false);
    }
  }, []);

  const forgotPassword = useCallback(async (email: string) => {
    await resetPassword(email);
  }, []);

  const updateSafety = useCallback(async (status: 'safe' | 'danger' | 'tracking') => {
    if (currentUser) {
      await updateUserSafetyStatus(currentUser.uid, status);
    }
  }, [currentUser?.uid]);

  const updateLocation = useCallback(async (lat: number, lng: number) => {
    if (currentUser) {
      await updateUserLastLocation(currentUser.uid, lat, lng);
    }
  }, [currentUser?.uid]);

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        loading,
        currentLocation,
        locationError,
        login,
        register,
        signInWithGoogle,
        logout,
        forgotPassword,
        updateSafety,
        updateLocation
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
