import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";
import nodemailer from "nodemailer";

dotenv.config();

/**
 * SHE-SHIELD AI ASSISTANT SERVICE
 * 
 * This server proxies requests to the Gemini API to keep the API key secure.
 * 
 * Setup Instructions:
 * 1. Get a free Gemini API key at https://aistudio.google.com/apikey
 * 2. The platform automatically manages the GEMINI_API_KEY secret.
 * 3. In a local environment, create a .env file with: GEMINI_API_KEY=your_key_here
 */

const ai = new GoogleGenAI({ 
  apiKey: process.env.GEMINI_API_KEY || "",
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Request Logging
  app.use((req, res, next) => {
    if (req.path.startsWith('/api')) {
      console.log(`[API Request] ${req.method} ${req.path}`);
    }
    next();
  });

// AI Chat Endpoint
  app.post("/api/chat", async (req, res) => {
    const { message, history, language } = req.body;

    if (!process.env.GEMINI_API_KEY) {
      console.error("GEMINI_API_KEY is missing");
      return res.status(500).json({ 
        error: "GEMINI_API_KEY is not configured on the server. Please check the Secrets panel." 
      });
    }

    try {
      const contents = [
        ...(history || []),
        { role: 'user', parts: [{ text: message }] }
      ];

      const langInfo = language ? `The user's preferred language is ${language}. Please respond in that language.` : "";

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents,
        config: {
          systemInstruction: `You are SheShield AI, a supportive AI assistant inside a women's safety app called SheShield AI. 
          Help users with questions about personal safety, legal rights (like Zero FIR, harassment laws, domestic violence support, stalking laws), cyber safety, and how to use the app's features (SOS, journey tracking, trusted guardians, etc.). 
          Be warm, clear, and concise. ${langInfo}
          If a user describes being in immediate danger, prioritize telling them to use the app's SOS button or call local emergency numbers (112 for police, 1091 for women's helpline in India) over just chatting. 
          You are not a lawyer and should note that for serious legal matters they should consult one, but general legal awareness info is fine to share.`,
        },
      });

      if (!response || !response.text) {
        console.error("Gemini API Error: Empty or invalid response object", response);
        throw new Error("Empty response from Gemini API");
      }

      res.json({ text: response.text });
    } catch (error: any) {
      console.error("Gemini API Error Detail:", error);
      
      let statusCode = 500;
      if (typeof error?.status === 'number') {
        statusCode = error.status;
      } else if (error?.code && typeof error.code === 'number') {
        statusCode = error.code;
      }
      
      let message = "Failed to communicate with AI service.";
      
      if (statusCode === 503) {
        message = "The AI service is currently overloaded. Please try again in a few moments.";
      } else if (statusCode === 429) {
        message = "AI service quota exceeded (Rate limit reached). Please wait a minute and try again.";
      } else if (error?.message) {
        message = error.message;
      }
      
      res.status(statusCode).json({ error: message });
    }
  });

  // Emergency Alert Endpoint
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: parseInt(process.env.SMTP_PORT || '587'),
    secure: false, // true for 465, false for other ports
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  });

  app.post("/api/send-emergency-notification", async (req, res) => {
    const { contacts, message } = req.body;
    
    if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS) {
      console.error("SMTP configuration is missing");
      return res.status(500).json({ error: "Notification service not configured." });
    }

    try {
      const emailPromises = contacts.map((contact: any) => 
        transporter.sendMail({
          from: '"SheShield AI" <alerts@sheshield.ai>',
          to: contact.email,
          subject: '🚨 EMERGENCY ALERT - SheShield AI',
          text: message,
        })
      );
      await Promise.all(emailPromises);
      res.json({ success: true });
    } catch (error) {
      console.error('Email error:', error);
      res.status(500).json({ error: 'Failed to send notifications' });
    }
  });

  // Explicit 404 for API routes to prevent HTML response
  app.all("/api/*", (req, res) => {
    res.status(404).json({ error: "API route not found" });
  });

  // Global Error Handler
  app.use((err: any, req: any, res: any, next: any) => {
    console.error("Express App Error:", err);
    if (res.headersSent) {
      return next(err);
    }
    res.status(500).json({ error: "Internal Server Error" });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
